package cn.xdl.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter({"/index.jsp"})
public class LoginFilter implements Filter {
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		//���еĴ���
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		//1.	��ȡsession , �ж�session���Ƿ�����ʺ�
		HttpSession session = req.getSession();
		if(session.getAttribute("username") == null) {
			//δ�洢
			//�õ�cookies
			Cookie[] cookies = req.getCookies();
			if(cookies!=null) {
				//����
				for (Cookie cookie : cookies) {
					if(cookie.getName().equals("username")) {
						session.setAttribute("username", cookie.getValue());
					}else if(cookie.getName().equals("userflag")) {
						session.setAttribute("userflag", cookie.getValue());
					}
				}
			}
			if(session.getAttribute("username")== null) {
				//Cookie��û��
				resp.sendRedirect("login.jsp");
			}else {
				//cookie�е��ʺ� �� ��� �Ѿ��洢����session (�Զ���¼�����)
				chain.doFilter(request, response);
			}
			
		}else {
			//�Ѵ洢
			chain.doFilter(request, response);
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}

}
