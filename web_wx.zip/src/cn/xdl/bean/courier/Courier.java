package cn.xdl.bean.courier;

public class Courier {
	/**
	 * ���Ա���
	 */
	private int id;
	/**
	 * ���Ա����
	 */
	private String couName;
	/**
	 * ���Ա�绰
	 */
	private String couPhone;
	/**
	 * ���Ա����
	 */
	private String couPassword;
	
	public Courier() {
		super();
	}
	public Courier(int id, String couName, String couPhone, String couPassword) {
		super();
		this.id = id;
		this.couName = couName;
		this.couPhone = couPhone;
		this.couPassword = couPassword;
	}
	
	public Courier(String couName, String couPhone, String couPassword) {
		super();
		this.couName = couName;
		this.couPhone = couPhone;
		this.couPassword = couPassword;
	}
	/**
	 * @return���
	 */
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return���Ա����
	 */
	public String getCouName() {
		return couName;
	}
	public void setCouName(String couName) {
		this.couName = couName;
	}
	/**
	 * @return���Ա�绰
	 */
	public String getCouPhone() {
		return couPhone;
	}
	public void setCouPhone(String couPhone) {
		this.couPhone = couPhone;
	}
	/**
	 * @return���Ա����
	 */
	public String getCouPassword() {
		return couPassword;
	}
	public void setCouPassword(String couPassword) {
		this.couPassword = couPassword;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((couName == null) ? 0 : couName.hashCode());
		result = prime * result + ((couPassword == null) ? 0 : couPassword.hashCode());
		result = prime * result + ((couPhone == null) ? 0 : couPhone.hashCode());
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Courier other = (Courier) obj;
		if (couName == null) {
			if (other.couName != null)
				return false;
		} else if (!couName.equals(other.couName))
			return false;
		if (couPassword == null) {
			if (other.couPassword != null)
				return false;
		} else if (!couPassword.equals(other.couPassword))
			return false;
		if (couPhone == null) {
			if (other.couPhone != null)
				return false;
		} else if (!couPhone.equals(other.couPhone))
			return false;
		if (id != other.id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Courier [id=" + id + ", couName=" + couName + ", couPhone=" + couPhone + ", couPassword=" + couPassword
				+ "]";
	}
	
	
}
