package cn.xdl.bean;

import java.sql.Timestamp;

public class Express {
	/**
	 * ���
	 */
	private int id;
	/**
	 * ��ݹ�˾
	 */
	private String company;
	/**
	 * ��ݵ���
	 */
	private String eNumber;
	/**
	 * �ռ�������
	 */
	private String username;
	/**
	 * �ռ����ֻ���
	 */
	private String userPhone;
	/**
	 * ¼�����ֻ���
	 */
	private String sysPhone;
	/**
	 * ȡ����
	 */
	private	int code;
	/**
	 * ���ʱ��
	 */
	private Timestamp inTime;
	/**
	 * ȡ��ʱ��
	 */
	private Timestamp outTime;
	/**
	 * ���״̬, Ĭ��0��ʾδȡ��, 1��ʾ��ȡ��
	 */
	private int status;
	/**
	 * @return  ���
	 */
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return  ��ݹ�˾
	 */
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	/**
	 * @return  ��ݵ���
	 */
	public String geteNumber() {
		return eNumber;
	}
	public void seteNumber(String eNumber) {
		this.eNumber = eNumber;
	}
	/**
	 * @return  �ռ�������
	 */
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return  �ռ����ֻ���
	 */
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	/**
	 * @return  ¼�����ֻ���
	 */
	public String getSysPhone() {
		return sysPhone;
	}
	public void setSysPhone(String sysPhone) {
		this.sysPhone = sysPhone;
	}
	/**
	 * @return ȡ����
	 */
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	/**
	 * @return ���ʱ��
	 */
	public Timestamp getInTime() {
		return inTime;
	}
	public void setInTime(Timestamp inTime) {
		this.inTime = inTime;
	}
	/**
	 * @return ȡ��ʱ��
	 */
	public Timestamp getOutTime() {
		return outTime;
	}
	public void setOutTime(Timestamp outTime) {
		this.outTime = outTime;
	}
	/**
	 * 
	 * @return ���״̬, Ĭ��0��ʾδȡ��, 1��ʾ��ȡ��
	 */
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + code;
		result = prime * result + ((company == null) ? 0 : company.hashCode());
		result = prime * result + ((eNumber == null) ? 0 : eNumber.hashCode());
		result = prime * result + id;
		result = prime * result + ((inTime == null) ? 0 : inTime.hashCode());
		result = prime * result + ((outTime == null) ? 0 : outTime.hashCode());
		result = prime * result + status;
		result = prime * result + ((sysPhone == null) ? 0 : sysPhone.hashCode());
		result = prime * result + ((userPhone == null) ? 0 : userPhone.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Express other = (Express) obj;
		if (code != other.code)
			return false;
		if (company == null) {
			if (other.company != null)
				return false;
		} else if (!company.equals(other.company))
			return false;
		if (eNumber == null) {
			if (other.eNumber != null)
				return false;
		} else if (!eNumber.equals(other.eNumber))
			return false;
		if (id != other.id)
			return false;
		if (inTime == null) {
			if (other.inTime != null)
				return false;
		} else if (!inTime.equals(other.inTime))
			return false;
		if (outTime == null) {
			if (other.outTime != null)
				return false;
		} else if (!outTime.equals(other.outTime))
			return false;
		if (status != other.status)
			return false;
		if (sysPhone == null) {
			if (other.sysPhone != null)
				return false;
		} else if (!sysPhone.equals(other.sysPhone))
			return false;
		if (userPhone == null) {
			if (other.userPhone != null)
				return false;
		} else if (!userPhone.equals(other.userPhone))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
	public Express(int id, String company, String eNumber, String username, String userPhone, String sysPhone, int code,
			Timestamp inTime, Timestamp outTime, int status) {
		super();
		this.id = id;
		this.company = company;
		this.eNumber = eNumber;
		this.username = username;
		this.userPhone = userPhone;
		this.sysPhone = sysPhone;
		this.code = code;
		this.inTime = inTime;
		this.outTime = outTime;
		this.status = status;
	}
	public Express() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Express [id=" + id + ", company=" + company + ", eNumber=" + eNumber + ", username=" + username
				+ ", userPhone=" + userPhone + ", sysPhone=" + sysPhone + ", code=" + code + ", inTime=" + inTime
				+ ", outTime=" + outTime + ", status=" + status + "]";
	}
	public Express(String company, String eNumber, String username, String userPhone, String sysPhone) {
		super();
		this.company = company;
		this.eNumber = eNumber;
		this.username = username;
		this.userPhone = userPhone;
		this.sysPhone = sysPhone;
	}
	
	
}
