package cn.xdl.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.xdl.bean.Message;
import cn.xdl.user.service.UserService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/register.do")
public class RegisterServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/json;charset=utf-8");
		//1.	��ȡ����Ĳ���
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String usercode = request.getParameter("code");
		//2.	����service ,���ע��
		HttpSession session = request.getSession();
		String sesUsername = (String) session.getAttribute("phone");
		String sesCode = (String) session.getAttribute("code");
		Message msg = null;
		//�Ա��ֻ����Ƿ���ȷ  username��session�д��sesUsername�Ƿ����
		if(username!=null&&username.equals(sesUsername)) {
			//����service,���ע��
			if(usercode!=null&&usercode.equals(sesCode)) {
				int reg = UserService.register(username, password);
				if(reg==1) {
					msg=new Message(1,"ע��ɹ�!");
				}else {
					msg=new Message(-1,"ע��ʧ��!");
				}
			}else {
				msg=new Message(-2,"��֤������!");
			}
		}else {
			msg=new Message(-1,"ע��ʧ��(�ֻ��Ż���֤������)!");
		}
		
		response.getWriter().append(msg.toJSON());
	}

}


















