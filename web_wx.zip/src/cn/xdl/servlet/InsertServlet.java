package cn.xdl.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Express;
import cn.xdl.bean.Message;
import cn.xdl.service.ExpressService;
import cn.xdl.sms.aliyun.SmsUtil;


/**
 * Servlet implementation class InsertServlet
 */
@WebServlet("/express/insert.do")
public class InsertServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/json;charset=utf-8");
		//"eNumber="+eNumber+"&company="+company+"&username="+username+"&userphone="+userphone;
		//1.	���ղ���
		String eNumber = request.getParameter("eNumber");
		String company = request.getParameter("company");
		String username = request.getParameter("username");
		String userphone = request.getParameter("userphone");
		//2.	����service
		int code = ExpressService.insert(new Express(company, eNumber, username, userphone, "15140172269"));
		//3.	������
		Message msg = null;
		if(code!=-1 && code!=-2) {
			//����ɹ�
			boolean flag = SmsUtil.sendSms2(userphone, code+"");
			if(flag) {
				//���ŷ��ͳɹ�
				msg = new Message(1,"���¼��ɹ�");
			}else {
				//���ŷ���ʧ��
				msg = new Message(-1,"���¼��ɹ� , ���ŷ���ʧ��");
			}
		}else if(code ==-2){
			//-2����ʧ��
			msg = new Message(-2,"��������ظ�");
		}else {
			//-1
			msg = new Message(-2,"���¼��ʧ��");
		}
		//3.	��Ӧ
		//{"status":1,"msg":"���¼��ɹ�"}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
