package cn.xdl.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LogOutServlet
 */
@WebServlet("/logout.do")
public class LogOutServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.	����session
			request.getSession().invalidate();
		//2.	ɾ��cookie
			Cookie unameCookie = new Cookie("username", ""); 
			Cookie uflagCookkie = new Cookie("userflag", ""); 
			unameCookie.setPath("/");
			unameCookie.setMaxAge(0);
			uflagCookkie.setPath("/");
			uflagCookkie.setMaxAge(0);
			response.addCookie(unameCookie);
			response.addCookie(uflagCookkie);
		//3.	��ת����¼
			response.sendRedirect("login.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
