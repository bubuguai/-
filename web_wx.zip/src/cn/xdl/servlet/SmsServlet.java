package cn.xdl.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.xdl.bean.Message;
import cn.xdl.sms.aliyun.SmsUtil;

/**
 * �������Ͷ���
 */
@WebServlet("/sendSms.do")
public class SmsServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		String phone = request.getParameter("phone");
		int code = (int) (Math.random()*900000+100000);
		boolean sms2 = SmsUtil.sendSms2(phone, code+"");
		Message msg = null;
		if(sms2) {
			HttpSession session = request.getSession();
			session.setAttribute("phone", phone);
			session.setAttribute("code", code+"");
			msg=new Message(1);
		}else {
			msg=new Message(-1);
		}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
