package cn.xdl.dao.courier;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import cn.xdl.bean.courier.Courier;
import cn.xdl.service.courier.CourierService;

public class CourierDaoTest {
	/**
	 * ���Բ�����Ա�Ƿ�ɹ�
	 * @throws Exception
	 */
	@Test
	public void insert() throws Exception {
		CourierService.insert(new Courier("�γ���","13842073369","110923"));
	}
	
	
	/**
	 * �����޸Ŀ��Ա��Ϣ�Ƿ�ɹ�
	 * @throws Exception
	 */
	@Test
	public void update() throws Exception {
		boolean flag = CourierService.updateByIdOrCouPhone("13842073369", -1, new Courier("������", "15040114437", "123456"));
		System.out.println(flag);
	}
	
	
	/**
	 * ����ɾ�����Ա�Ƿ�ɹ�
	 * @throws Exception
	 */
	@Test
	public void delete() throws Exception {
		CourierService.deleteByIdOrCouPhone("15698991362", -1);
	}
	
	
	
	/**
	 * ���Բ���ȫ����Ա�Ƿ�ɹ�չʾ
	 * @throws Exception
	 */
	@Test
	public void find() throws Exception {
		List<Courier> list = CourierService.findAll();
		System.out.println(list);
	}
	
	@Test
	public void find2() throws Exception {
		Courier cc = CourierService.findByCouPhone("15040114437");
		System.out.println(cc);
	}
}




