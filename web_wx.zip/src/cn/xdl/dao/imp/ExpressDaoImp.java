package cn.xdl.dao.imp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import cn.xdl.bean.Express;
import cn.xdl.dao.BaseExpressDao;
import cn.xdl.util.DBCPUtil;

public class ExpressDaoImp implements BaseExpressDao {

	private static final String SQL_FIND_ALL = "SELECT * FROM WEB_EXPRESS";
	private static final String SQL_FIND_BY_ENUMBER = "SELECT * FROM WEB_EXPRESS WHERE ENUMBER=?";
	private static final String SQL_FIND_BY_USERPHONE = "SELECT * FROM WEB_EXPRESS WHERE USERPHONE=?";
	private static final String SQL_INSERT = "INSERT INTO WEB_EXPRESS(ID,COMPANY,ENUMBER,USERNAME,USERPHONE,SYSPHONE,CODE,INTIME) VALUES(SEQ_WEB_EXPRESS_ID.NEXTVAL,?,?,?,?,?,?,SYSDATE)";
	private static final String SQL_DELETE_BY_ID_OR_ENUMBER = "DELETE FROM WEB_EXPRESS WHERE ID=? OR ENUMBER=?";
	private static final String SQL_UPDATE_BY_ID_OR_ENUMBER = "UPDATE WEB_EXPRESS SET ENUMBER=?,COMPANY=?,USERNAME=?,USERPHONE=? WHERE ID=? OR ENUMBER=?";
	private static final String SQL_UPDATE_STATUS_BY_CODE = "UPDATE WEB_EXPRESS SET CODE=NULL,STATUS=1,OUTTIME=SYSDATE WHERE CODE=?";
	@Override
	public List<Express> findAll() {
		ArrayList<Express> data = new ArrayList<Express>();
		Connection conn = null;
		PreparedStatement state = null;
		ResultSet result = null;
		try {
			//1.	��ȡ����
			conn = DBCPUtil.getConnection();
			//2.	Ԥ����
			state = conn.prepareStatement(SQL_FIND_ALL);
			//3.	������
			//4	.	ִ�� , ���õ������
			result = state.executeQuery();
			//5.	��������� ȡ��ÿһ������ �洢��������
			while(result.next()) {
				int id = result.getInt("ID");
				String company = result.getString("COMPANY");
				String eNumber = result.getString("ENUMBER");
				String username = result.getString("USERNAME");
				String userPhone = result.getString("USERPHONE");
				String sysPhone = result.getString("SYSPHONE");
				int code = result.getInt("CODE");
				Timestamp inTime = result.getTimestamp("INTIME");
				Timestamp outTime = result.getTimestamp("OUTTIME");
				int status = result.getInt("STATUS");
				data.add(new Express(id, company, eNumber, username, userPhone, sysPhone, code, inTime, outTime, status));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(conn, state, result);
		}
		//6.	���ؼ���
		return data;
	}

	@Override
	public Express findByENumber(String eNumber) {
		Connection conn = null;
		PreparedStatement state = null;
		ResultSet result = null;
		try {
			//1.	��ȡ����
			conn = DBCPUtil.getConnection();
			//2.	Ԥ����
			state = conn.prepareStatement(SQL_FIND_BY_ENUMBER);
			//3.	������
			state.setString(1, eNumber);
			//4	.	ִ�� , ���õ������
			result = state.executeQuery();
			//5.	��������� ȡ��ÿһ������ �洢��������
			if(result.next()) {
				int id = result.getInt("ID");
				String company = result.getString("COMPANY");
				String username = result.getString("USERNAME");
				String userPhone = result.getString("USERPHONE");
				String sysPhone = result.getString("SYSPHONE");
				int code = result.getInt("CODE");
				Timestamp inTime = result.getTimestamp("INTIME");
				Timestamp outTime = result.getTimestamp("OUTTIME");
				int status = result.getInt("STATUS");
				Express e = new Express(id, company, eNumber, username, userPhone, sysPhone, code, inTime, outTime, status);
				return e;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(conn, state, result);
		}
		return null;
	}

	@Override
	public List<Express> findByUserPhone(String userPhone) {
		ArrayList<Express> data = new ArrayList<Express>();
		Connection conn = null;
		PreparedStatement state = null;
		ResultSet result = null;
		try {
			//1.	��ȡ����
			conn = DBCPUtil.getConnection();
			//2.	Ԥ����
			state = conn.prepareStatement(SQL_FIND_BY_USERPHONE);
			//3.	������
			state.setString(1, userPhone);
			//4	.	ִ�� , ���õ������
			result = state.executeQuery();
			//5.	��������� ȡ��ÿһ������ �洢��������
			while(result.next()) {
				int id = result.getInt("ID");
				String company = result.getString("COMPANY");
				String eNumber = result.getString("ENUMBER");
				String username = result.getString("USERNAME");
				String sysPhone = result.getString("SYSPHONE");
				int code = result.getInt("CODE");
				Timestamp inTime = result.getTimestamp("INTIME");
				Timestamp outTime = result.getTimestamp("OUTTIME");
				int status = result.getInt("STATUS");
				data.add(new Express(id, company, eNumber, username, userPhone, sysPhone, code, inTime, outTime, status));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			DBCPUtil.close(conn, state, result);
		}
		//6.	���ؼ���
		return data;
	}

	@Override
	public int insert(Express e) {
		Connection conn = null;
		PreparedStatement state = null;
		try {
			//1.	��ȡ���Ӷ���
			conn = DBCPUtil.getConnection();
			//2.	Ԥ����
			state = conn.prepareStatement(SQL_INSERT);	
			//3.	������
			//COMPANY,ENUMBER,USERNAME,USERPHONE,SYSPHONE,CODE,
			state.setString(1,  e.getCompany());
			state.setString(2,  e.geteNumber());
			state.setString(3,  e.getUsername());
			state.setString(4,  e.getUserPhone());
			state.setString(5,  e.getSysPhone());
			Random r = new Random();
			int code = r.nextInt(900000)+100000;
			state.setInt(6, code);
			//4.	ִ�� ,�����ؽ��
			if(state.executeUpdate()>0) {
				return code;
			}else {
				return -1;
			}
		} catch (SQLException e1) {
			if(e1.getMessage().contains("WEB_EXPRESS_ENUMBER_UK")) {
				//�����ظ�
				return -2;
			}else if(e1.getMessage().contains("SYSTEM.WEB_EXPRESS_CODE_UK")) {
				//ȡ�����ظ�
				return insert(e);
			}else {
				e1.printStackTrace();
			}
		}finally {
			DBCPUtil.close(conn, state, null);
		}
		return -1;
	}

	@Override
	public boolean deleteByIdOrENumber(String eNumber, int id) {
		Connection conn = null;
		PreparedStatement state = null;
		try {
			//1.	��ȡ���Ӷ���
			conn = DBCPUtil.getConnection();
			//2.	Ԥ����
			state = conn.prepareStatement(SQL_DELETE_BY_ID_OR_ENUMBER);	
			//3.	������
			state.setInt(1, id);
			state.setString(2, eNumber);
			//4.	ִ�� ,�����ؽ��
			return state.executeUpdate()>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBCPUtil.close(conn, state, null);
		}
		return false;
	}

	@Override
	public boolean updateByIdOrENumber(String eNumber, int id, Express newExpress) {
		Connection conn = null;
		PreparedStatement state = null;
		try {
			//1.	��ȡ���Ӷ���
			conn = DBCPUtil.getConnection();
			//2.	Ԥ����
			state = conn.prepareStatement(SQL_UPDATE_BY_ID_OR_ENUMBER);	
			//3.	������
			state.setString(1, newExpress.geteNumber());
			state.setString(2, newExpress.getCompany());
			state.setString(3, newExpress.getUsername());
			state.setString(4, newExpress.getUserPhone());
			state.setInt(5, id);
			state.setString(6, eNumber);
			//4.	ִ�� ,�����ؽ��
			return state.executeUpdate()>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBCPUtil.close(conn, state, null);
		}
		return false;
	}

	@Override
	public boolean updateStatusByCode(int code) {
		Connection conn = null;
		PreparedStatement state = null;
		try {
			//1.	��ȡ���Ӷ���
			conn = DBCPUtil.getConnection();
			//2.	Ԥ����
			state = conn.prepareStatement(SQL_UPDATE_STATUS_BY_CODE);	
			//3.	������
			state.setInt(1, code);
			//4.	ִ�� ,�����ؽ��
			int flag  = state.executeUpdate();
			if(flag == 1) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			DBCPUtil.close(conn, state, null);
		}
		return false;
	}

}
