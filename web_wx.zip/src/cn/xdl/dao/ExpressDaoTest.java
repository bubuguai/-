package cn.xdl.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import cn.xdl.bean.Express;
import cn.xdl.service.ExpressService;

public class ExpressDaoTest {

	@Test
	public void insert() throws Exception {
		int flag = ExpressService.insert(new Express("˳������", "123456789", "���2", "13843838437", "18516955565"));
		System.out.println(flag);
	}
	
	@Test
	public void update() throws Exception {
		boolean flag = ExpressService.updateByIdOrENumber("123456", -1, new Express("�ٺٿ��", "654321", "����", "1383843838", "18516955565"));
		System.out.println(flag);
	}
	@Test
	public void update2() throws Exception {
		boolean flag = ExpressService.updateStatusByCode(667665);
		System.out.println(flag);
	}
	@Test
	public void delete() throws Exception {
		boolean flag = ExpressService.deleteByIdOrENumber("654321", -1);
		System.out.println(flag);
	}
	@Test
	public void find1() throws Exception {
		List<Express> data = ExpressService.findAll();
		System.out.println(data);
	}
	@Test
	public void find2() throws Exception {
		List<Express> data = ExpressService.findByUserPhone("13843838437");
		System.out.println(data);
	}
	@Test
	public void find3() throws Exception {
		Express e = ExpressService.findByENumber("1234567");
		System.out.println(e);
	}
	
	
}
