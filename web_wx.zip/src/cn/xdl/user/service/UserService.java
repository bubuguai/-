package cn.xdl.user.service;

import cn.xdl.bean.courier.Courier;
import cn.xdl.bean.user.User;
import cn.xdl.dao.courier.BaseCourierDao;
import cn.xdl.dao.imp.courier.CourierDaoImp;
import cn.xdl.dao.imp.user.UserDaoImp;
import cn.xdl.dao.user.BaseUserDao;

public class UserService {

	private static BaseCourierDao bcd = new CourierDaoImp();
	private static BaseUserDao bud = new UserDaoImp();
	
	/**
	 *	�û���¼
	 * @param username	�ʺ�
	 * @param password	����
	 * @return	-1��ʾ��¼ʧ��, 1��ʾ���Ա�ɹ�, 2��ʾ�û���¼�ɹ�
	 */
	public static int login(String username, String password) {
		/*
		 * //���ÿ��Ա�����dao. ��ɵ�¼�ɹ� if("18888888888".equals(username) &&
		 * "123".equals(password)) { //���Ա��¼�ɹ� , return 1; }else
		 * if("18516955565".equals(username) && "123".equals(password)) { //�û���¼�ɹ�
		 * return 2; }
		 */
		Courier courier = bcd.findByCouPhone(username);
		User user = bud.findByUserPhone(username);
		if(courier==null && user!=null) {
			if(username.equals(user.getUserPhone()) && password.equals(user.getUserPassword())){
				return 2;
			}else {
				return -1;
			}
		}else if(user==null && courier!=null) {
			if(username.equals(courier.getCouPhone()) && password.equals(courier.getCouPassword())) {
				 return 1;
			}else {
				return -1;
			}
		}
		return -1;
	}
	
	/**
	 * ע�Ṧ��
	 */
	public static int register(String username,String password) {
		boolean flag = bud.insert(new User("�û�"+username,username,password));
		if(flag) {
			return 1;
		}else {
			return -1;
		}
	}

}








