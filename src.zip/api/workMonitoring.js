import request from '@/utils/request'
import { method } from 'lodash'

// 查询所有监控类型
export function selectMonitorType() {
  return request({
    url: 'api1/monitorType/selectMonitorType',
    method: 'post'

  })
}
// 查询所有算法接口
export function selectAlgorithm() {
  return request({
    url: 'api1/Camera/selectAlgorithm',
    method: 'post'
  })
}
// 查询所有报警规则接口
export function selectMonitorAlarmRule() {
  return request({
    url: 'api1/monitorRule/selectMonitorAlarmRule',
    method: 'post'
  })
}
// 查询所有报警等级接口
export function findAlarmPriority() {
  return request({
    url: 'api1/Camera/findAlarmPriority',
    method: 'post'
  })
}

// 查询监控类型（根据ID查询,可用于修改时回显数据）
export function selectJobMonitorAlgorithmInfo(param) {
  return request({
    url: 'api1/jobMonitorAlgorithm/selectJobMonitorAlgorithmInfo',
    method: 'post',
    params: param
  })
}

// 查询所有监控记录(分页查询)
export function selectJobMonitorAlgorithm(param) {
  return request({
    url: 'api1/jobMonitorAlgorithm/selectJobMonitorAlgorithm',
    method: 'post',
    params: param
  })
}
