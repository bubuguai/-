import request from '@/utils/request'

// 相机画面
export function getCameraVideoPath(param) {
  return request({
    url: 'api6/api/getCameraVideoPath',
    method: 'get',
    params: param
  })
}

// 获取用户最后一次打开的相机ID
export function getCameraId(accountId) {
  return request({
    url: 'api6/videoAlarmRecord/getCameraId',
    method: 'post',
    params: {
      accountId: accountId
    }
  })
}

export function selectVideoAlarmRecordToday(param) {
  return request({
    url: 'api1/videoAlarmRecord/selectVideoAlarmRecordToday',
    method: 'post',
    data: param
  })
}

// 销毁
export function shutdown(param) {
  return request({
    url: 'api6/api/shutdown',
    method: 'get',
    params: param
  })
}

// 当天安全指数
export function currentSafeNum(param) {
  return request({
    url: 'api1/videoAlarmRecord/currentSafeNum',
    method: 'post',
    data: param
  })
}
