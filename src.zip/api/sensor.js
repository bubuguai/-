import request from '@/utils/request'

export function selectSensor(param) {
  return request({
    url: 'api1/sensor/selectSensor',
    method: 'post',
    params: param
  })
}

export function addSensor(data) {
  return request({
    url: 'api1/sensor/addSensor',
    method: 'post',
    data: data
  })
}

export function deleteSensor(id) {
  return request({
    url: 'api1/sensor/deleteSensor',
    method: 'post',
    params: {
      sensorId: id
    }
  })
}

export function selectAllRpaId() {
  return request({
    url: 'api1/sensor/selectAllRpaId',
    method: 'post'
  })
}

export function selectAllDCS() {
  return request({
    url: 'api1/sensor/selectAllDCS',
    method: 'post'
  })
}

export function selectAllCamera() {
  return request({
    url: 'api1/sensor/selectAllCamera',
    method: 'post'
  })
}
