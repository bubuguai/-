import request from '@/utils/request'

// 数据上传设置
export function upDataConfig(param) {
  return request({
    url: 'api1/serverConfig/upDataConfig',
    method: 'post',
    data: param
  })
}

// 查询
export function selectDataConfig() {
  return request({
    url: 'api1/serverConfig/selectDataConfig',
    method: 'post'
  })
}
