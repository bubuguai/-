import request from '@/utils/request'

// 账号查询
export function selectAccount(param) {
  return request({
    url: 'api1/account/selectAccount',
    method: 'post',
    data: param
  })
}
// 账号修改
export function updateAccount(param) {
  return request({
    url: 'api1/account/updateAccount',
    method: 'post',
    data: param
  })
}
// 账号查删除
export function deleteAccount(id) {
  return request({
    url: 'api1/account/deleteAccount',
    method: 'post',
    params: {
      id: id
    }
  })
}
// 账号添加
export function addAccount(param) {
  return request({
    url: 'api1/account/addAccount',
    method: 'post',
    data: param
  })
}

// 修改密码
export function updatePassWord(param) {
  return request({
    url: 'api1/account/updatePassWord',
    method: 'post',
    params: param
  })
}

// 修改个人信息
export function updatePersonalData(param) {
  return request({
    url: 'api1/account/updatePersonalData',
    method: 'post',
    params: param
  })
}
