import request from '@/utils/request'

// 分页查询工厂
export function selectFactory(query) {
  return request({
    url: 'api1/factory/selectFactory',
    method: 'post',
    data: query
  })
}
// 工厂添加
export function addFactories(params) {
  return request({
    url: 'api1/factory/addFactories',
    method: 'post',
    data: params
  })
}
// 工厂修改
export function updateFactories(params) {
  return request({
    url: 'api1/factory/updateFactories',
    method: 'post',
    data: params
  })
}
// 工厂删除
export function deleteFactory(id) {
  return request({
    url: 'api1/factory/deleteFactory',
    method: 'post',
    params: {
      id: id
    }
  })
}
// 查询区域
export function selArea() {
  return request({
    url: 'api1/factory/selArea',
    method: 'post'
  })
}
