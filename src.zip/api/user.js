import request from '@/utils/request'

// export function login(data) {
//   return request({
//     url: '/user/login',
//     method: 'post',
//     data
//   })
// }
export function login(params) {
  return request({
    url: 'api1/login/account',
    method: 'post',
    params: params
  })
}

export function getInfo(token) {
  return request({
    url: 'api1/user/getInfo',
    method: 'post',
    params: { token }
  })
}

export function logout() {
  return request({
    url: 'api1/login/logOut',
    method: 'post'
  })
}

export function getVerify() {
  return request({
    url: 'api1/login/getVerify',
    method: 'post',
    responseType: 'arraybuffer'
  })
}
