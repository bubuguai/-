import request from '@/utils/request'

// 查询监控场景接口（分页条件查询）
export function selectTemporaryMonitor(param) {
  return request({
    url: 'api1/temporaryMonitor/selectTemporaryMonitor',
    method: 'post',
    data: param
  })
}
// 修改场景接口
export function onOffTemporaryMonitor(param) {
  return request({
    url: 'api1/temporaryMonitor/onOffTemporaryMonitor',
    method: 'post',
    data: param
  })
}
// 查询所有监控类型接口
export function selectMonitorType() {
  return request({
    url: 'api1/monitorType/selectMonitorType',
    method: 'post'
  })
}
// 新增监控场景接口
export function addTemporaryMonitor(param) {
  return request({
    url: 'api1/temporaryMonitor/addTemporaryMonitor',
    method: 'post',
    data: param
  })
}
// 查询所有可用相机接口
export function findUsableCameras() {
  return request({
    url: 'api1/Camera/findUsableCameras',
    method: 'post'
  })
}
