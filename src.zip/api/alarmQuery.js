import request from '@/utils/request'

// 分页报警查询
export function selectVideoAlarmRecord(query) {
  return request({
    url: 'api1/videoAlarmRecord/selectVideoAlarmRecord',
    method: 'post',
    data: query
  })
}
// 区域添加
// export function addArea(query) {
//   return request({
//     url: 'area/addArea',
//     method: 'post',
//     params: query
//   })
// }
// 区域修改
export function updateArea(query) {
  return request({
    url: '/area/updateArea',
    method: 'post',
    params: query
  })
}
// 区域删除
// export function deleteArea(id) {
//   return request({
//     url: 'area/deleteArea',
//     method: 'post',
//     params: {
//       areaId: id
//     }
//   })
// }
// 报警类型查询
export function selectVideoAlarmType() {
  return request({
    url: 'api1/videoAlarmRecord/selectVideoAlarmType',
    method: 'post'
  })
}
// 摄像机查询
export function selectCamera() {
  return request({
    url: 'api1/videoAlarmRecord/selectCamera',
    method: 'post'
  })
}
// 视频报警导出
export function videoAlarmExport(query) {
  return request({
    url: 'api1/videoAlarmRecord/videoAlarmExport',
    method: 'post',
    data: query,
    responseType: 'blob'
  })
}
// 下载单条数据
export function videoAlarmRecordDow(id) {
  return request({
    url: 'api1/videoAlarmRecord/videoAlarmRecordDow',
    method: 'post',
    params: {
      id: id
    }
  })
}
