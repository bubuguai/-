import request from '@/utils/request'

// 工厂首页安全系数
export function currentSafeNum(query) {
  return request({
    url: 'api1/factoryshouye/currentSafeNum',
    method: 'post',
    data: query
  })
}
// 工厂首页视频报警总数
export function countVideoAlarm(query) {
  return request({
    url: 'api1/factoryshouye/countVideoAlarm',
    method: 'post',
    data: query
  })
}
// 工厂首页dcs报警总数
export function countDcsAlarm(query) {
  return request({
    url: 'api1/factoryshouye/countDcsAlarm',
    method: 'post',
    data: query
  })
}
// 工厂首页安全系数折线图
export function selectAllSafeNum(query) {
  return request({
    url: 'api1/factoryshouye/selectAllSafeNum',
    method: 'post',
    data: query
  })
}
// 工厂首页查询主机
export function selectHostName() {
  return request({
    url: 'api1/factoryshouye/selectHostName',
    method: 'post'
  })
}
// 工厂首页视频报警（级别）饼图(主)
export function priorityVideoChartData(query) {
  return request({
    url: 'api1/factoryshouye/priorityVideoChartData',
    method: 'post',
    data: query
  })
}
// 视频报警（级别）饼图(子)
export function priorityVideoChartDataChild(query) {
  return request({
    url: 'api1/factoryshouye/priorityVideoChartDataChild',
    method: 'post',
    data: query
  })
}
// 视频报警（厂区）饼图(主)
export function plantVideoChartData(query) {
  return request({
    url: 'api1/factoryshouye/plantVideoChartData',
    method: 'post',
    data: query
  })
}
// 视频报警（厂区）饼图(子)
export function plantVideoChartDataChild(query) {
  return request({
    url: 'api1/factoryshouye/plantVideoChartDataChild',
    method: 'post',
    data: query
  })
}
// dcs报警（级别）饼图(主)
export function priorityDcsChartData(query) {
  return request({
    url: 'api1/factoryshouye/priorityDcsChartData',
    method: 'post',
    data: query
  })
}
// dcs报警（级别）饼图(zi)
export function priorityDcsChartDataChild(query) {
  return request({
    url: 'api1/factoryshouye/priorityDcsChartDataChild',
    method: 'post',
    data: query
  })
}
// dcs报警（主机）饼图（主）
export function hostNameDcsChartData(query) {
  return request({
    url: 'api1/factoryshouye/hostNameDcsChartData',
    method: 'post',
    data: query
  })
}
// dcs报警（主机）饼图（子）
export function hostNameDcsChartDataChild(query) {
  return request({
    url: 'api1/factoryshouye/hostNameDcsChartDataChild',
    method: 'post',
    data: query
  })
}
// 视频报警导出
export function videoAlarmExport(query) {
  return request({
    url: 'api1/factoryshouye/videoAlarmExport',
    method: 'post',
    data: query,
    responseType: 'blob'
  })
}
// Dcs视频报警导出
export function dcsAlarmExport(query) {
  return request({
    url: 'api1/factoryshouye/dcsAlarmExport',
    method: 'post',
    data: query,
    responseType: 'blob'
  })
}
// Dcs折线图
export function lineDcsChartData(query) {
  return request({
    url: 'api1/factoryshouye/lineDcsChartData',
    method: 'post',
    data: query
  })
}
// 视频折线图
export function lineVideoChartData(query) {
  return request({
    url: 'api1/factoryshouye/lineVideoChartData',
    method: 'post',
    data: query
  })
}
