import request from '@/utils/request'

// 服务器设置查询
export function selectServerConfig() {
  return request({
    url: 'api1/serverConfig/selectServerConfig',
    method: 'post'
  })
}
// 邮箱服务器设置
export function updateServerConfig(params) {
  return request({
    url: 'api1/serverConfig/updateServerConfig',
    method: 'post',
    data: params
  })
}
// 时间服务器设置
export function updateTimeServer(params) {
  return request({
    url: 'api1/serverConfig/updateTimeServer',
    method: 'post',
    data: params
  })
}
// 测试发送邮件
export function sendMail(params) {
  return request({
    url: 'api1/serverConfig/sendMail',
    method: 'post',
    data: params
  })
}
// 更新服务器
export function syncTime(params) {
  return request({
    url: 'api1/serverConfig/syncTime',
    method: 'post',
    params: params
  })
}
