import request from '@/utils/request'

// 分页DCS列表
export function selectDcs(query) {
  return request({
    url: 'api1/DCS/selectDcs',
    method: 'post',
    params: query
  })
}
// DCS添加
export function addDCS(param) {
  return request({
    url: 'api1/DCS/addDCS',
    method: 'post',
    params: param
  })
}
// DCS修改
export function updateDCS(param) {
  return request({
    url: 'api1/DCS/updateDCS',
    method: 'post',
    data: param
  })
}
// DCS删除
export function deleteDcs(id) {
  return request({
    url: 'api1/DCS/deleteDcs',
    method: 'post',
    params: {
      id: id
    }
  })
}
