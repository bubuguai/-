import request from '@/utils/request'

// 报警模板查询
export function selectTemplate(query) {
  return request({
    url: 'api1/alarmTemplate/selectTemplate',
    method: 'post',
    data: query
  })
}

// 报警模板删除
export function deleteTemplate(id) {
  return request({
    url: 'api1/alarmTemplate/deleteTemplate',
    method: 'post',
    params: {
      id: id
    }
  })
}

// 报警模板添加
export function addTemplate(param) {
  return request({
    url: 'api1/alarmTemplate/addTemplate',
    method: 'post',
    data: param
  })
}

// 报警模板修改
export function updateTemplate(param) {
  return request({
    url: 'api1/alarmTemplate/updateTemplate',
    method: 'post',
    data: param
  })
}
