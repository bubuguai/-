import request from '@/utils/request'

// 分页报警提单查询
export function selectRpaLoadBill(query) {
  return request({
    url: 'api1/rpaLoadBill/selectRpaLoadBill',
    method: 'post',
    data: query
  })
}
// 报警提单导出
export function RpaLoadBillExport(query) {
  return request({
    url: 'api1/rpaLoadBill/RpaLoadBillExport',
    method: 'post',
    data: query,
    responseType: 'blob'
  })
}
