import request from '@/utils/request'

// 分页相机查询
export function selectCamera(query) {
  return request({
    url: 'api1/Camera/selectCamera',
    method: 'post',
    data: query
  })
}
// 相机添加
export function addCamera(params) {
  return request({
    url: 'api1/Camera/addCamera',
    method: 'post',
    data: params
  })
}
// NVR/DVR相机添加
export function addCameraByNVRDVR(params) {
  return request({
    url: 'api1/Camera/addCameraByNVRDVR',
    method: 'post',
    data: params
  })
}
// 相机修改
export function updateCamera(params) {
  return request({
    url: 'api1/Camera/updateCamera',
    method: 'post',
    data: params
  })
}
// 相机删除
export function deleteCamera(id) {
  return request({
    url: 'api1/Camera/deleteCamera',
    method: 'post',
    params: {
      id: id
    }
  })
}
// 查询算法
export function selectAlgorithm() {
  return request({
    url: 'api1/Camera/selectAlgorithm',
    method: 'post'
  })
}
// 相机布控
export function deployCamera(param) {
  return request({
    url: 'api1/Camera/deployCamera',
    method: 'post',
    data: param
  })
}
// 获取相机算法
export function getAllAlgorithmByCameraId(id) {
  return request({
    url: 'api1/Camera/getAllAlgorithmByCameraId',
    method: 'post',
    params: { cameraId: id }
  })
}
