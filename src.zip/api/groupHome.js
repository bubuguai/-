import request from '@/utils/request'

// 首页区域选择
export function blocAreas() {
  return request({
    url: 'api1/dcsAlarmRecord/blocAreas',
    method: 'post'
  })
}
// 首页视频报警饼状图数据
export function selectVideoChartData(query) {
  return request({
    url: 'api1/videoAlarmRecord/selectVideoChartData',
    method: 'post',
    data: query
  })
}
// 首页DCS饼状图数据
export function selectDcsChartData(query) {
  return request({
    url: 'api1/dcsAlarmRecord/selectDcsChartData',
    method: 'post',
    data: query
  })
}
// 首页视频报警柱状图数据
export function videoBarChartData(query) {
  return request({
    url: 'api1/videoAlarmRecord/videoBarChartData',
    method: 'post',
    data: query
  })
}
// 首页DCS报警柱状图数据
export function barChartData(query) {
  return request({
    url: 'api1/dcsAlarmRecord/barChartData',
    method: 'post',
    data: query
  })
}
// 首页视频报警嵌套饼状图数据
export function childVideoChartData(query) {
  return request({
    url: 'api1/videoAlarmRecord/childVideoChartData',
    method: 'post',
    data: query
  })
}
// 首页Dcs报警嵌套饼状图数据
export function selectDcsChartDataChild(query) {
  return request({
    url: 'api1/dcsAlarmRecord/selectDcsChartDataChild',
    method: 'post',
    data: query
  })
}
// 首页安全系数
export function currentSafeNumOfGroup(query) {
  return request({
    url: 'api1/videoAlarmRecord/currentSafeNumOfGroup',
    method: 'post',
    data: query
  })
}
// 首页视频报警总数
export function countVideoAlarm(query) {
  return request({
    url: 'api1/videoAlarmRecord/countVideoAlarm',
    method: 'post',
    data: query
  })
}
// 首页dcs报警总数
export function countDcsAlarm(query) {
  return request({
    url: 'api1/dcsAlarmRecord/countDcsAlarm',
    method: 'post',
    data: query
  })
}
// 视频报警导出
export function blocVideoAlarmExport(query) {
  return request({
    url: 'api1/videoAlarmRecord/blocVideoAlarmExport',
    method: 'post',
    data: query,
    responseType: 'blob'
  })
}
// Dcs视频报警导出
export function blocDcsAlarmExport(query) {
  return request({
    url: 'api1/dcsAlarmRecord/blocDcsAlarmExport',
    method: 'post',
    data: query,
    responseType: 'blob'
  })
}
// 首页折线图
export function selectAllSafeNum(query) {
  return request({
    url: 'api1/videoAlarmRecord/selectAllSafeNum',
    method: 'post',
    data: query
  })
}
