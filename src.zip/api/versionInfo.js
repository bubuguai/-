import request from '@/utils/request'

// 授权信息
export function authorizationMsg() {
  return request({
    url: 'api1/license/authorizationMsg',
    method: 'get'
  })
}
