import request from '@/utils/request'

// 主机列表接口的获取
export function hostList() {
  return request({
    url: '/api1/DcsWin/safeNum',
    methods: 'post'
  })
}

// 报警列表接口的获取
export function alarmList(param) {
  return request({
    url: '/api1/DcsWin/allDcsAlarm',
    // url:'/api1/DcsWin/allDcsAlarm',
    methods: 'post',
    data: param
  })
}

// 修改状态的接口
export function changeStatu(param) {
  return request({
    url: '/api1/dcsAlarmRecord/updateStateByID',
    methods: 'post',
    data: param
  })
}

// 启动Robot
export function RpaStart(param) {
  return request({
    url: '/api1/mq/RpaStart',
    methods: 'post',
    data: param
  })
}

// 停止Robot
export function RpaStop(param) {
  return request({
    url: '/api1/mq/RpaStop',
    methods: 'post',
    data: param
  })
}
