import request from '@/utils/request'

// 分页DCS报警查询
export function selectDcsAlarmRecord(query) {
  return request({
    url: 'api1/dcsAlarmRecord/selectDcsAlarmRecord',
    method: 'post',
    data: query
  })
}

// DCS视频报警导出
export function dcsAlarmRecordExport(query) {
  return request({
    url: 'api1/dcsAlarmRecord/dcsAlarmRecordExport',
    method: 'post',
    data: query,
    responseType: 'blob'
  })
}
// 下载单条数据
export function dcsAlarmRecordDown(id) {
  return request({
    url: 'api1/dcsAlarmRecord/dcsAlarmRecordDown',
    method: 'post',
    params: {
      id: id
    }
  })
}
// 下载单条数据
export function selectDcsAlarmType() {
  return request({
    url: 'api1/dcsAlarmRecord/selectDcsAlarmType',
    method: 'post'
  })
}
