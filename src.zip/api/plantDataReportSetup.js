import request from '@/utils/request'

// 工厂数据上报设置
export function uploadSettings(videoAlarm, dcsAlarm) {
  return request({
    url: 'api1/factoryData/uploadSettings',
    method: 'post',
    params: {
      videoAlarm: videoAlarm,
      dcsAlarm: dcsAlarm
    }
  })
}
// 工厂数据上报查询
export function settings() {
  return request({
    url: 'api1/factoryData/Settings',
    method: 'post'
  })
}
