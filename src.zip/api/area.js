import request from '@/utils/request'

// 分页查询区域
export function selectArea(query) {
  return request({
    url: 'api1/area/selectArea',
    method: 'post',
    params: query
  })
}
// 区域添加
export function addArea(params) {
  return request({
    url: 'api1/area/addArea',
    method: 'post',
    data: params
  })
}
// 区域修改
export function updateArea(params) {
  return request({
    url: 'api1/area/updateArea',
    method: 'post',
    data: params
  })
}
// 区域删除
export function deleteArea(id) {
  return request({
    url: 'api1/area/deleteArea',
    method: 'post',
    params: {
      id: id
    }
  })
}
// 查询所有上级区域
export function allArea() {
  return request({
    url: 'api1/area/allArea',
    method: 'post'
  })
}
// 查询所有上级区域(修改时)
export function partArea() {
  return request({
    url: 'api1/area/partArea',
    method: 'post'
  })
}

// 可查看区域
export function treeArea() {
  return request({
    url: 'api1/area/treeArea',
    method: 'post'
  })
}
