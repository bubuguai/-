import request from '@/utils/request'

// 查询用户行为日志列表
export function selectAccount(data) {
  return request({
    url: 'api1/logAccount/selectAccount',
    method: 'post',
    params: data
  })
}
// 用户行为日志导出
export function logAccountExport() {
  return request({
    url: 'api1/logAccount/logAccountExport',
    method: 'post',
    responseType: 'blob'
  })
}
