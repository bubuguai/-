import request from '@/utils/request'

// ai服务器查询
export function selectAi(param) {
  return request({
    url: 'api1/ai/selectAi',
    method: 'post',
    params: param
  })
}
// ai服务器添加
export function addAi(param) {
  return request({
    url: 'api1/ai/addAi',
    method: 'post',
    params: param
  })
}

// ai服务器修改
export function updateAi(param) {
  return request({
    url: 'api1/ai/updateAi',
    method: 'post',
    params: param
  })
}
// ai服务器查询
export function deleteAi(id) {
  return request({
    url: 'api1/ai/deleteAi',
    method: 'post',
    params: {
      ai_id: id
    }
  })
}
