import request from '@/utils/request'

// robot请求
export function robotRequest(param) {
  return request({
    url: 'api1/robotRequest/request',
    method: 'post',
    data: param
  })
}
