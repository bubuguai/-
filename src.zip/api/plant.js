import request from '@/utils/request'

// 分页查询厂区
export function selectPlant(query) {
  return request({
    url: 'api1/plant/selectPlant',
    method: 'post',
    data: query
  })
}
// 厂区添加
export function addPlant(params) {
  return request({
    url: 'api1/plant/addPlant',
    method: 'post',
    data: params
  })
}
// 厂区修改
export function updatePlant(params) {
  return request({
    url: 'api1/plant/updatePlant',
    method: 'post',
    data: params
  })
}
// 厂区删除
export function deletePlant(id) {
  return request({
    url: 'api1/plant/deletePlant',
    method: 'post',
    params: {
      id: id
    }
  })
}
// 查询所有上级厂区
export function allPlant() {
  return request({
    url: 'api1/plant/allPlant',
    method: 'post'
  })
}

// 查询所有上级厂区(修改时)
export function partPlant() {
  return request({
    url: 'api1/plant/partPlant',
    method: 'post'
  })
}
