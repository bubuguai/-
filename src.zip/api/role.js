import request from '@/utils/request'

export function selectRole(data) {
  return request({
    url: 'api1/role/selectRole',
    method: 'post',
    params: data
  })
}

export function addRole(data) {
  return request({
    url: 'api1/role/addRole',
    method: 'post',
    data: data
  })
}

export function updateRole(data) {
  return request({
    url: 'api1/role/updateRole',
    method: 'post',
    data: data
  })
}

export function deleteRole(id) {
  return request({
    url: 'api1/role/deleteRole',
    method: 'post',
    params: {
      id: id
    }
  })
}

export function accredit(data) {
  return request({
    url: 'api1/role/accredit',
    method: 'post',
    data: data
  })
}

export function selectaccredit(id) {
  return request({
    url: 'api1/role/selectaccredit',
    method: 'post',
    params: {
      roleId: id
    }
  })
}
// 集团角色查询
export function selectpdRole(data) {
  return request({
    url: 'api1/pdrole/selectRole',
    method: 'post',
    params: data
  })
}

// 集团角色添加
export function addpdRole(data) {
  return request({
    url: 'api1/pdrole/addRole',
    method: 'post',
    data: data
  })
}
// 集团角色修改
export function updatepdRole(data) {
  return request({
    url: 'api1/pdrole/updateRole',
    method: 'post',
    data: data
  })
}
// 集团角色删除
export function deletepdRole(id) {
  return request({
    url: 'api1/pdrole/deleteRole',
    method: 'post',
    params: {
      id: id
    }
  })
}
