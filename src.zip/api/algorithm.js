import request from '@/utils/request'

// 相机查询
export function initCamera(param) {
  return request({
    url: 'api1/algorithmConfig/initCamera',
    method: 'post',
    data: param
  })
}
// 算法查询
export function initAlgorithm(id) {
  return request({
    url: 'api1/algorithmConfig/initAlgorithm',
    method: 'post',
    params: {
      cameraId: id
    }
  })
}
// 获取相机抓怕图
export function refresh(id, algId) {
  return request({
    url: 'api1/algorithmConfig/refresh',
    method: 'post',
    params: {
      cameraId: id,
      algorithmId: algId
    }
  })
}

// 导出
export function outImg() {
  return request({
    url: 'api1/algorithmConfig/out',
    method: 'post',
    responseType: 'blob'
  })
}

// 清除缓存
export function clearCache() {
  return request({
    url: 'api1/algorithmConfig/clearCache',
    method: 'post'
  })
}
// 保存
export function addAlgorithmConfig(param) {
  return request({
    url: 'api1/algorithmConfig/addAlgorithmConfig',
    method: 'post',
    params: param
  })
}

