<template>
  <div>
    <el-button
      v-if="isEn === 'en'"
      type="text"
      style="color: #fff;height:50px;"
      @click="handleSetLanguage('en')"
    >EN</el-button>
    <el-button
      v-if="isEn === 'zh'"
      type="text"
      style="color: #fff;height:50px;"
      @click="handleSetLanguage('zh')"
    >中文</el-button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isEn: 'en'
    }
  },
  computed: {
    language() {
      return this.$store.getters.language
    }
  },
  methods: {
    handleSetLanguage(lang) {
      if (lang === 'zh') {
        this.isEn = 'en'
      } else {
        this.isEn = 'zh'
      }
      this.$i18n.locale = lang
      this.$store.dispatch('app/setLanguage', lang)
      this.$message({
        message: 'Switch Language Success',
        type: 'success'
      })
    }
  }
}
</script>
