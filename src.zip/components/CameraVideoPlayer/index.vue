<template>
  <video ref="player" class="video-player vjs-custom-skin" controls muted width="100%" height="100%" />
</template>

<script>
// 2.组件内引用
import { videoPlayer } from 'vue-video-player'
import 'videojs-flash'
import 'video.js/dist/video-js.css'
// import flvjs from "./flv.min.js";

export default {
  name: 'Flvjs',
  components: {
    videoPlayer
  },
  props: {
    csrc: {
      type: String,
      default: ''
    }
  },
  /**
   * @returns {{player: flvjs.Player}}
   */
  data() {
    return {
      player: null
    }
  },
  mounted() {
    if (flvjs.isSupported()) {
      const video = this.$refs.player
      if (video) {
        console.log('Video Path: ' + this.csrc)
        this.player = flvjs.createPlayer({
          type: 'flv',
          isLive: true,
          url: this.csrc
        }, {
          enableWorker: false,
          enableStashBuffer: false,
          // stashInitialSize: 1,
          lazyLoad: false,
          lazyLoadMaxDuration: 10,
          lazyLoadRecoverDuration: 5,
          // deferLoadAfterSourceOpen: false,
          autoCleanupMaxBackwardDuration: 10,
          autoCleanupMinBackwardDuration: 5,
          statisticsInfoReportInterval: 100,
          fixAudioTimestampGap: false
        })
        this.player.attachMediaElement(video)
        try {
          this.player.load()
          this.player.play()
        } catch (error) {
          console.log(error)
        }
      }
    }
  },
  beforeDestroy() {
    this.player.destory()
  }
}
</script>

<style>
.vjs-resolution-button .vjs-icon-placeholder:before {
  content: '\f110';
  font-family: VideoJS;
  font-weight: normal;
  font-style: normal;
  font-size: 1.8em;
  line-height: 1.67em;
}

.vjs-resolution-button .vjs-resolution-button-label {
  font-size: 1em;
  line-height: 3em;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  text-align: center;
  box-sizing: inherit;
}

.vjs-resolution-button .vjs-menu .vjs-menu-content {
  width: 4em;
  left: 50%;
  /* Center the menu, in it's parent */
  margin-left: -2em;
  /* half of width, to center */
}

.vjs-resolution-button .vjs-menu li {
  text-transform: none;
  font-size: 1em;
}
.theme-message,
.theme-picker-dropdown {
  z-index: 99999 !important;
}

.theme-picker .el-color-picker__trigger {
  height: 26px !important;
  width: 26px !important;
  padding: 2px;
}

.theme-picker-dropdown .el-color-dropdown__link-btn {
  display: none;
}
</style>
