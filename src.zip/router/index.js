import Vue from "vue";
import Router from "vue-router";

Vue.use(Router);
import Layout from "@/layout";
export const constantRoutes = [
  {
    path: "/redirect",
    component: Layout,
    hidden: true,
    children: [
      {
        path: "/redirect/:path*",
        component: () => import("@/views/redirect/index")
      }
    ]
  },
  {
    path: "/login",
    component: () => import("@/views/login/index"),
    // component: () => import('@/views/firstList/index1'),
    name: "login",
    hidden: true
  },
  {
    path: "/auth-redirect",
    component: () => import("@/views/login/auth-redirect"),
    hidden: true
  },
  {
    path: "",
    hidden: true,
    component: () => import("@/views/redirect/redirect")
  }
];
export const asyncRoutes = [
  {
    path: "/",
    component: Layout,
    redirect: "/alarmRecord/list",
    children: [
      {
        path: "/alarmRecord/list",
        component: () => import("@/views/alarmRecordList/List"),
        name: "alarmRecordList",
        meta: {
          title: "报警查看",
          icon: "menu",
          noCache: true,
          affix: true
          // pages: ["groupHomePage"]
        }
      }
    ]
  },

  {
    path: "/monitoringArea",
    component: Layout,
    redirect: "/monitoringArea/list",
    children: [
      {
        path: "list",
        component: () => import("@/views/monitoringArea/List"),
        name: "groupHomePage",
        meta: {
          title: "监控区域",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      }
    ]
  },

  {
    path: "/staffDeploy",
    meta: { title: "人员配置", icon: "menu" },
    component: Layout,
    redirect: "/staffDeploy/deptList",
    children: [
      {
        path: "/deptList",
        component: () => import("@/views/staffDeploy/DeptList"),
        name: "groupHomePage",
        meta: {
          title: "部门",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/PositionList",
        component: () => import("@/views/staffDeploy/PositionList"),
        name: "groupHomePage",
        meta: {
          title: "职位",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/StaffList",
        component: () => import("@/views/staffDeploy/StaffList"),
        name: "groupHomePage",
        meta: {
          title: "人员",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      }
    ]
  },
  {
    path: "/monitorDeploy",
    meta: { title: "监控配置", icon: "menu" },
    component: Layout,
    redirect: "/monitorDeploy/nvrList",
    children: [
      {
        path: "/nvrList",
        component: () => import("@/views/monitorDeploy/NvrList"),
        name: "groupHomePage",
        meta: {
          title: "NVR",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/cameraList",
        component: () => import("@/views/monitorDeploy/CameraList"),
        name: "groupHomePage",
        meta: {
          title: "摄像机",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      }
    ]
  },
  {
    path: "/equipDeploy",
    meta: { title: "设备配置", icon: "menu" },
    component: Layout,
    redirect: "/equipDeploy/serialList",
    children: [
      {
        path: "/serialList",
        component: () => import("@/views/equipDeploy/serialService/SerialList"),
        name: "groupHomePage",
        meta: {
          title: "串口服务器",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/hostList",
        component: () => import("@/views/equipDeploy/equipHost/HostList"),
        name: "groupHomePage",
        meta: {
          title: "设备主机",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/pointList",
        component: () => import("@/views/equipDeploy/alarmPoint/PointList"),
        name: "groupHomePage",
        meta: {
          title: "报警点",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/pointTypeList",
        component: () => import("@/views/equipDeploy/alarmPointType/PointTypeList"),
        name: "groupHomePage",
        meta: {
          title: "报警点类型",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      }
    ]
  },
  {
    path: "/alarm",
    component: Layout,
    redirect: "/alarmList/index",
    children: [
      {
        path: "index",
        component: () => import("@/views/alarmList/index"),
        name: "groupHomePage",
        meta: {
          title: "alarmList",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      }
    ]
  },
  {
    path: "/alarmDeploy",
    meta: { title: "报警配置", icon: "menu" },
    component: Layout,
    redirect: "/alarmDeploy/index",
    children: [
      {
        path: "/AlarmLevelList",
        component: () => import("@/views/alarmDeploy/AlarmLevelList"),
        name: "groupHomePage",
        meta: {
          title: "报警等级",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/AlarmTypeList",
        component: () => import("@/views/alarmDeploy/AlarmTypeList"),
        name: "groupHomePage",
        meta: {
          title: "报警类型",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/AlarmRecordsStatusList",
        component: () => import("@/views/alarmDeploy/AlarmRecordsStatusList"),
        name: "groupHomePage",
        meta: {
          title: "报警记录状态",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      },
      {
        path: "/ReportInformList",
        component: () => import("@/views/alarmDeploy/ReportInformList"),
        name: "groupHomePage",
        meta: {
          title: "记录填报人员",
          icon: "menu",
          noCache: true,
          affix: true,
          pages: ["groupHomePage"]
        }
      }
    ]
  }
];

const createRouter = () =>
  new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes
  });
const router = createRouter();
export function resetRouter() {
  const newRouter = createRouter();
  router.matcher = newRouter.matcher; // reset router
}
export default router;
