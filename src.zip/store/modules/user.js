import { login, logout, getInfo } from '@/api/user'
import { getToken, setToken, removeToken } from '@/utils/auth'
import router, { resetRouter } from '@/router'

const state = {
  token: getToken(),
  name: '',
  avatar: '',
  introduction: '',
  roles: [],
  pages: [],
  user: {}
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_INTRODUCTION: (state, introduction) => {
    state.introduction = introduction
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  },
  SET_ROLES: (state, roles) => {
    state.roles = roles
  },
  SET_PAGES: (state, pages) => {
    state.pages = pages
  },
  SET_USER: (state, user) => {
    state.user = user
  }
}

const actions = {
  // user login
  Login({ commit }, userInfo) {
    // const { username, password } = userInfo
    return new Promise((resolve, reject) => {
      login({ userName: userInfo.userName.trim(), passWord: userInfo.passWord, remember: userInfo.remember }).then(response => {
        const { data } = response.data
        commit('SET_TOKEN', data.Token)
        setToken(data.Token)
        // commit('SET_PAGES', data.page)
        // commit('SET_USER', data.user)
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // get user info
  getInfo({ commit, state }) {
    return new Promise((resolve, reject) => {
      // FIXME:
      getInfo(state.token).then(response => {
        const { data } = response.data
        // const data = data.pages
        // const data = state.pages
        // const data = {
        //   roles: ['admin'],
        //   name: 'admin',
        //   avatar: 'admin',
        //   introduction: 'admin'
        // }
        if (!data) {
          // reject('Verification failed, please Login again.')
          reject('验证失败，请重新登陆！')
        }
        // const { roles, name, avatar, introduction } = data
        // const user = data.user
        commit('SET_PAGES', data.page)
        commit('SET_USER', data.user)
        commit('SET_ROLES', [data.user.roleName])
        // roles must be a non-empty array
        // if (!data || data.length <= 0) {
        //   reject('getInfo: roles must be a non-null array!')
        // }

        commit('SET_NAME', data.user.accountName)
        // commit('SET_AVATAR', avatar)
        // commit('SET_INTRODUCTION', introduction)
        resolve({ pages: data.page })
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout({ commit, state }) {
    return new Promise((resolve, reject) => {
      logout(state.token).then(() => {
        commit('SET_TOKEN', '')
        commit('SET_ROLES', [])
        removeToken()
        resetRouter()
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // remove token
  resetToken({ commit }) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      commit('SET_ROLES', [])
      removeToken()
      resolve()
    })
  },

  // dynamically modify permissions
  changeRoles({ commit, dispatch }, role) {
    return new Promise(async resolve => {
      const token = role + '-token'

      commit('SET_TOKEN', token)
      setToken(token)

      const { roles } = await dispatch('getInfo')

      resetRouter()

      // generate accessible routes map based on roles
      const accessRoutes = await dispatch('permission/generateRoutes', roles, { root: true })

      // dynamically add accessible routes
      router.addRoutes(accessRoutes)

      // reset visited views and cached views
      dispatch('tagsView/delAllViews', null, { root: true })

      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
