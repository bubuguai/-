import { asyncRoutes, constantRoutes } from '@/router'

/**
 * Use meta.role to determine if the current user has permission
 * @param pages
 * @param route
 */
function hasPermission(pages, route) {
  if (route.meta && route.meta.pages) {
    return pages.some(page => route.meta.pages.includes(page.pageName))
  } else {
    return true
  }
}

/**
 * Filter asynchronous routing tables by recursion
 * @param routes asyncRoutes
 * @param pages
 */
export function filterAsyncRoutes(routes, pages) {
  const res = []

  routes.forEach(route => {
    const tmp = { ...route }
    if (hasPermission(pages, tmp)) {
      if (tmp.children) {
        tmp.children = filterAsyncRoutes(tmp.children, pages)

        if (tmp.children && tmp.children.length > 0) {
          res.push(tmp)
        }
      } else {
        res.push(tmp)
      }
    }
  })

  return res
}

const state = {
  routes: [],
  addRoutes: []
}

const mutations = {
  SET_ROUTES: (state, routes) => {
    state.addRoutes = routes
    console.log(constantRoutes)
    state.routes = constantRoutes.concat(routes)
  }
}

const actions = {
  generateRoutes({ commit }, pages) {
    return new Promise(resolve => {
      let accessedRoutes
      if (pages.includes('admin')) {
        accessedRoutes = asyncRoutes || []
      } else {
        accessedRoutes = filterAsyncRoutes(asyncRoutes, pages)
      }
      commit('SET_ROUTES', accessedRoutes)
      resolve(accessedRoutes)
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
