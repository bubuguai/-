<template>
  <div :class="{ 'has-logo': showLogo }">
    <logo v-if="showLogo" :collapse="isCollapse" />
    <el-scrollbar wrap-class="scrollbar-wrapper">
      <el-menu
        :default-active="activeMenu"
        :collapse="isCollapse"
        :background-color="variables.menuBg"
        :text-color="variables.menuText"
        :unique-opened="true"
        :active-text-color="variables.subMenuActiveText"
        :collapse-transition="false"
        mode="vertical"
      >
        <sidebar-item
          v-for="route in permission_routes"
          :key="route.path"
          :item="route"
          :base-path="route.path"
        />
      </el-menu>
    </el-scrollbar>
    <!-- <footer v-if="sidebar.opened && !isViedoAlarm">
      <img class="pic-sidebar__bottom" src="@/assets/images/footerLogo.png" alt />
    </footer>
    <footer v-if="isViedoAlarm && sidebar.opened">
      <img class="pic-sidebar__bottom" src="@/assets/images/footLogo-e.png" alt />
    </footer>
    <footer v-if="!sidebar.opened">
      <img class="pic-sidebar__bottom2" src="@/assets/images/footerLogos.png" alt />
    </footer> -->
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Logo from './Logo'
import SidebarItem from './SidebarItem'
import variables from '@/styles/variables.scss'
import Cookies from 'js-cookie'

export default {
  components: { SidebarItem, Logo },
  data() {
    return {
      isViedoAlarm: false
    }
  },
  computed: {
    ...mapGetters(['permission_routes', 'sidebar']),
    activeMenu() {
      this.isViedoAlarm = false
      const route = this.$route
      const { meta, path } = route
      // if set path, the sidebar will highlight the path you set
      if (meta.activeMenu) {
        return meta.activeMenu
      }
      if (path === '/videoAlarm/index') {
        this.isViedoAlarm = true
      }
      return path
    },
    showLogo() {
      return this.$store.state.settings.sidebarLogo
    },
    variables() {
      return variables
    },
    isCollapse() {
      return !this.sidebar.opened
    }
  }
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
footer {
  height: 100px;
  display: flex;
  margin: 0 auto;
  align-items: center;
  // .imgs {

  // }
  .pic-sidebar__bottom {
    margin: auto;
    width: 172px;
    height: 68px;
  }
  .pic-sidebar__bottom2 {
    margin: auto;
  }
  img.collapse {
    width: 20px;
    height: auto;
  }
}
</style>
