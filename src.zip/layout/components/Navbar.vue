<template>
  <div class="navbar">
    <el-row>
      <el-col :md="{ span: 1 }" :xs="{ span: 1 }">
        <hamburger
          id="hamburger-container"
          :is-active="sidebar.opened"
          class="hamburger-container"
          @toggleClick="toggleSideBar"
        />
      </el-col>
      <el-col :md="{ span: 18 }" :xs="{ span: 18 }" style="text-align: left;">
        <!-- <span class="title-contant">{{ $t("title.mainTitle") }}</span> -->
        <span class="title-contant">安全生产监测平台</span>
      </el-col>
      <el-col :md="{ span: 5 }" :xs="{ span: 5 }">
        <div class="right-menu">
          <el-row>
            <!-- <el-col :md="{ span: 8 }" :xs="{ span: 8 }">
              <lang-select
                class="right-menu-item hover-effect"
                style="text-align:right;"
              />
            </el-col> -->
            <el-col :md="{ span: 4 }" :xs="{ span: 4 }">
              <i
                class="el-icon-search"
                style="color: white; text-align:right; position: relative; top: 25px;"
              />
            </el-col>
            <el-col :md="{ span: 4 }" :xs="{ span: 4 }">
              <i
                class="el-icon-stopwatch"
                style="color: white; text-align:right; position: relative; top: 25px;"
              />
            </el-col>
            <el-col :md="{ span: 5 }" :xs="{ span: 5 }">
              <i
                class="el-icon-bell"
                style="color: white; text-align:right; position: relative; top: 25px;"
              />
            </el-col>
            <el-col :md="{ span: 3 }" :xs="{ span: 3 }">
              <el-dropdown class="avatar-container" trigger="click">
                <el-row class="avatar-wrapper">
                  <!-- <i class="el-icon-user" /> -->
                  <el-avatar
                    style="position: relative;size: 10px;"
                    src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
                  />
                  <!-- <i
                    class="el-icon-arrow-down"
                    style="color:#fff;margin-top:5px;"
                  /> -->
                </el-row>
                <el-dropdown-menu slot="dropdown">
                  <router-link :to="{ name: 'PersonalCenter' }">
                    <el-dropdown-item @click.native="toggleSideBars">
                      {{ $t("navbar.profile") }}
                    </el-dropdown-item>
                  </router-link>
                  <router-link :to="{ name: 'ChangePassword' }">
                    <el-dropdown-item @click.native="toggleSideBars">
                      {{ $t("navbar.changePassword") }}
                    </el-dropdown-item>
                  </router-link>
                  <router-link :to="{ name: 'VersionInfo' }">
                    <el-dropdown-item @click.native="toggleSideBars">
                      {{ $t("navbar.versionInformation") }}
                    </el-dropdown-item>
                  </router-link>
                  <el-dropdown-item divided>
                    <span style="display:block;" @click="logout">
                      {{ $t("navbar.logOut") }}
                    </span>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </el-col>
            <el-col :md="{ span: 4 }" :xs="{ span: 4 }">
              <span
                class="user_name"
                style="color:#fff;font-size:14px;cursor:pointer;position: relative;top:25px;"
              >{{ userName }}</span>
            </el-col>
            <el-col :md="{ span: 4 }" :xs="{ span: 4 }">
              <i
                class="el-icon-basketball"
                style="color: white; text-align:right; position: relative; top: 25px;"
              />
            </el-col>
          </el-row>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
// import Breadcrumb from '@/components/Breadcrumb'
import Hamburger from '@/components/Hamburger'
import Cookies from 'js-cookie'
// import ErrorLog from '@/components/ErrorLog'
// import Screenfull from '@/components/Screenfull'
// import SizeSelect from '@/components/SizeSelect'
import LangSelect from '@/components/LangSelect'

export default {
  components: {
    // Breadcrumb,
    Hamburger,
    // ErrorLog,
    // Screenfull,
    // SizeSelect,
    LangSelect
  },
  data() {
    return {
      userName: ''
    }
  },
  computed: {
    ...mapGetters(['sidebar', 'avatar', 'devcie', 'user', 'app'])
  },
  created() {
    this.userName = this.user.accountName
    // this.userName = this.sidebar.opened;
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch('app/toggleSideBar')
    },
    toggleSideBars() {
      this.$store.dispatch('app/closeSideBar', { withoutAnimation: false })
    },
    async logout() {
      await this.$store.dispatch('user/logout')
      // this.$router.push(`/login?redirect=${this.$route.fullPath}`)
      this.$router.push('/login')
      location.reload()
    }
  }
}
</script>

<style lang="scss" scoped>
.navbar {
  height: 70px;
  overflow: hidden;
  position: relative;
  background:#001529;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);

  .hamburger-container {
    line-height: 70px;
    height: 100%;
    float: left;
    cursor: pointer;
    transition: background 0.3s;
    -webkit-tap-highlight-color: transparent;
    &:hover {
      background: rgba(0, 0, 0, 0.025);
    }
  }
  .breadcrumb-container {
    float: left;
  }
  .errLog-container {
    display: inline-block;
    vertical-align: top;
  }
  .title-contant {
    color: #fff;
    position: relative;
    top: 24px;
    font-size: 20px;
    text-align: center;
  }
  .right-menu {
    // float: right;
    text-align: center;
    height: 100%;

    &:focus {
      outline: none;
    }

    .right-menu-item {
      // display: inline-block;
      // padding: 0 8px;
      // height: 100%;
      // font-size: 18px;
      // color: #5a5e66;
      // vertical-align: text-bottom;

      &.hover-effect {
        cursor: pointer;
        // transition: background .3s;

        &:hover {
          background: rgba(0, 0, 0, 0.025);
        }
      }
    }

    .avatar-container {
      margin-right: 30px;

      .avatar-wrapper {
        margin-top: 18px;
        position: relative;

        .el-icon-user {
          cursor: pointer;
          font-size: 20px;
          color: #fff;
        }

        .el-icon-arrow-down {
          cursor: pointer;
          position: absolute;
          right: -20px;
        }

        // .avatar-small {
        //   // position: absolute;
        //   size: small;
        // }
      }
    }
  }
}
</style>
