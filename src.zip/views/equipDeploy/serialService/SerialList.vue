<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-col :span="8">
            <el-form-item label="串口服务器名称：">
              <el-input
                v-model="formCondition.hostName"
                class="input-form"
              />
            </el-form-item>
          </el-col>

          <el-col :span="10">
            <el-form-item label="状态:">
              <el-select
                v-model="formCondition.dcsAlarmState"
                class="input-form"
                clearable
              >
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                type="primary"
                size="mini"
                @click="handleFilter"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
                @click="handleExport"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-form-item>
          </el-col>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <!-- 2.此div是数据表格 -->
    <div class="table-container">
      <el-col :span="15">
        <h3>串口服务器列表</h3>
      </el-col>
      <el-col 
        :span="3"
        :offset="6"
      >
        <el-button
          type="primary"
          @click="edit()"
        >
          + 新增串口服务器
        </el-button>
      </el-col>
      <el-table
        v-loading="listLoading"
        :data="list"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(col, index) in dataColumns"
          :key="index"
          :label="col.label"
          :width="col.width"
          height="100px"
          sortable="custom"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="col.value == 'hostName'"
              class="font-color-blue"
            >
              {{
                scope.row[col.value]
              }}</span>
            <span v-if="col.value != 'hostName'">{{
              scope.row[col.value]
            }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="center"
          width="230px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageable.page"
        :limit.sync="pageable.size"
        @pagination="getList"
      />
    </div>
    <serialDrawer
      ref="serialDrawer"
      :visible="drawerVisible"
      :form-data="formData"
    />
  </div>
</template>
<script>
import { selectDcsAlarmRecord, selectDcsAlarmType } from "@/api/DCSAlarmQuery";
import serialDrawer from "./SerialDrawer";
import { serialColumns } from "../tableList";
import Pagination from "@/components/Pagination";
export default {
  name: "SerialQuery",
  components: { Pagination, serialDrawer }, // Drawer
  data() {
    return {
      drawerVisible: false,
      activeName: 'form',
      listLoading: true,
      list: null, // 报警记录列表:data值
      dataColumns: serialColumns,
      total: 0, // 分页总数
      alarmTypeOptions: [],
      downloadLoading: false, // 导出表格加载按钮
      formData: {},
      pageable: {
        page: 1,
        size: 10,
      },
      formCondition: {
        // 查询列表
        hostName: "", // 报警点名称
        dcsAlarmTypeId: "", // 报警类型
        dcsAlarmState: "", // 报警记录状态
        sortRule: 2,
        region: "", // 区域的下拉框绑定数据
        alarm: "", // 报警类型下拉框绑定数据
        alarmName: "", // 报警点名称绑定值
        alarmStatu: "", // 报警记录状态下拉框绑定数据
      },
      options: [],
      tableKey: 0, // table列表:key值
    }
  },
   mounted() {
    this.getList();
    this.getAlarmType();
    this.getQueryOptions();
  },
  methods: {
    // 下拉框获取数据
    getQueryOptions() {
      this.options.push(
        {
          value: "选项1",
          label: "区域1",
        },
        {
          value: "选项2",
          label: "区域2",
        },
        {
          value: "选项3",
          label: "区域3",
        }
      );
    },
    edit(rowData) {
        if(rowData){
          this.$refs.serialDrawer.title = '编辑串口服务器'
          this.$refs.serialDrawer.form = rowData;
        } else {
          this.$refs.serialDrawer.title = '新增串口服务器'
          this.$refs.serialDrawer.form = {};
        }
        this.$refs.serialDrawer.visible = true
    },
    getList() {
      const param = this.formCondition;
      this.listLoading = true;
      selectDcsAlarmRecord({
        page: param.page - 1,
        size: param.size,
        hostName: param.hostName,
        dcsAlarmTypeId: param.dcsAlarmTypeId,
        dcsAlarmState: param.dcsAlarmState,
        alarmLever: param.alarmLever,
        startTime: param.startTime,
        endTime: param.endTime,
        sortRule: param.sortRule,
        sortField: param.sortField,
      }).then((res) => {
        if (res.data.result === "success") {
          this.list = res.data.data.list;
          this.total = res.data.data.totalNum;
          this.listLoading = false;
        } else {
          this.listLoading = false;
        }
      });
    },
    getAlarmType() {
      selectDcsAlarmType().then((res) => {
        if (res.data.result === "success") {
          this.alarmTypeOptions = res.data.data.dcsAlarmTypeList;
        }
      });
    },
    handleFilter() {
      this.list = [];
      this.total = 0;
      this.pageable.page = 1;
      this.getList();
    },
    sortChange(data) {
      if (data.order === "ascending") {
        this.formCondition.sortRule = 1;
      } else {
        this.formCondition.sortRule = 2;
      }
      this.formCondition.sortField = data.prop;
      this.getList();
    },
    handleExport() {}, // 导出表格的方法
  },
}
</script>
<style lang="scss" scoped>
</style>