<template>
  <el-drawer
    :title="title"
    :before-close="handleClose"
    :visible.sync="visible"
    direction="rtl"
    size="40%"
    custom-class="demo-drawer"
  >
    <!-- {{this.formData}} -->
    <el-divider class="divider" />
    <el-form
      :model="form"
      class="el-form"
    >
      <el-form-item
        label="设备主机名称"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.hostName"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
      <el-form-item
        label="设备厂商名称"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.firmName"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        label="通讯协议名称"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.communication"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        label="串口服务器名称"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.serialService"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        label="地址码"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.addressNum"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
      <el-form-item
        label="功能码"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.functionNum"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
      <el-form-item
        label="起始地址"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.startAddress"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
    </el-form>
    <el-divider class="divider-foot" />
    <div class="drawer-footer">
      <el-button @click="cancelForm">
        取 消
      </el-button>
      <el-button
        type="primary"
        :loading="loading"
        @click="save()"
      >
        {{ loading ? "提交中 ..." : "保 存" }}
      </el-button>
    </div>
  </el-drawer>
</template>
<script>
export default {
  name: 'EditDrawer',
  data() {
    return {
      title: '',
      form: {
        // 抽屉表单
        hostName: '',
        firmName: '',
        communication: '',
        serialService: '',
        addressNum: '',
        functionNum: '',
        startAddress: ''
      },
      alarmStatus: '',
      visible: false,
      loading: false,
      timer: null,
      formLabelWidth: '150px',
    }
  },
  mounted() {
    this.selectData()
  },
  methods: {
    // 下拉框获取数据
    selectData() {
      this.alarmStatus = []
      this.alarmStatus.push(
        {
          value: '气体探头报警',
          label: '可燃气体探头报警',
        },
        {
          value: '液体探头报警',
          label: '可燃液体探头报警',
        }
      )
    },
    handleClose(done) {
      if (this.loading) {
        return
      }
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          this.timer = setTimeout(() => {
            done()
            // 动画关闭需要一定的时间
            setTimeout(() => {
              this.loading = false
              this.closeDialog()
            }, 400)
          }, 500)
        })
        .catch(() => {
          setTimeout(() => {
            this.loading = false
            this.closeDialog()
          }, 400)
        })
    },
    closeDialog() {
      this.visible = false
    },
    cancelForm() {
      this.$confirm('确认取消保存数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '已取消!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '未取消',
          })
          this.closeDialog()
        })
    },
    save() {
      this.$confirm('确认保存此数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
          this.closeDialog()
        })
    },
  },
}
</script>
<style lang="scss" scoped>
.form-item-drawer {
  width: 75%;
}
.el-form {
  margin-top: 8%;
  margin-left: 5%;
}
</style>