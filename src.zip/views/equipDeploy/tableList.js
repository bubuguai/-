export const serialColumns = [
  // table表格数据
  {
    label: "串口服务器名称",
    value: "hostName",
    width: "230px"
  },
  {
    label: "串口服务器编号",
    value: "sensorid",
    width: "200px"
  },
  {
    label: "串口数量",
    value: "dcsAlarmTypeId",
    width: "200px"
  },
  {
    label: "状态",
    value: "dcsAlarmState",
    width: "200px"
  },
  {
    label: "描述",
    value: "dcsAlarmDesc"
  }
];
export const hostColumns = [
  // table表格数据
  {
    label: "设备主机名称",
    value: "hostName",
    width: "200px"
  },
  {
    label: "设备厂商名称",
    value: "firmName",
    width: "200px"
  },
  {
    label: "通讯协议名称",
    value: "communication",
    width: "200px"
  },
  {
    label: "串口服务器名称",
    value: "serialService",
    width: "200px"
  },
  {
    label: "地址码",
    value: "addressNum",
    width: "150px"
  },
  {
    label: "功能码",
    value: "functionNum",
    width: "150px"
  },
  {
    label: "起始地址",
    value: "startAddress",
    width: "200px"
  },
  {
    label: "状态",
    value: "hostState",
    width: "200px"
  }
];
export const alarmPointColumns = [
  // table表格数据
  {
    label: "报警点名称",
    value: "alarmPointName"
    // width: "200px"
  },
  {
    label: "设备主机名称",
    value: "hostName"
    // width: "200px"
  },
  {
    label: "监控区域",
    value: "monitoringArea"
    // width: "200px"
  },
  {
    label: "报警点类型",
    value: "alarmPointType"
    // width: "200px"
  },
  {
    label: "报警编码",
    value: "alarmNum"
    // width: "150px"
  },
  {
    label: "状态",
    value: "state"
    // width: "150px"
  },
  {
    label: "主监控摄像机",
    value: "mainMonitorCamera"
    // width: "200px"
  },
  {
    label: "安装位置",
    value: "installPosition"
    // width: "200px"
  }
];
export const alarmPointTypeColumns = [
  // table表格数据
  {
    label: "报警点类型名称",
    value: "alarmPointTypeName"
    // width: "200px"
  },
  {
    label: "报警点类型描述",
    value: "alarmPointTypeDescribe"
    // width: "200px"
  }
];
