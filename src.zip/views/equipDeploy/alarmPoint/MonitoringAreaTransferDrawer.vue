<template>
  <el-drawer
    :title="title"
    :before-close="handleClose"
    :visible.sync="visible"
    direction="ltr"
    size="40%"
    custom-class="demo-drawer"
  >
    <el-divider class="divider" />
    <div style="text-align: center">
      <el-transfer
        v-model="value4"
        style="text-align: left; display: inline-block"
        filterable
        :titles="['摄像机列表', '已选择摄像机']"
        :button-texts="['移除选中', '选择摄像机']"
        :props="{
          key: 'num',
          label: 'camera'
        }"
        :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}'
        }"
        :data="list"
      >
        <span slot-scope="{ option }">{{ option.num }} - {{ option.camera }}</span>
      </el-transfer>
      <el-divider class="divider-foot" />
      <div class="drawer-footer">
        <el-button @click="cancelForm">
          取 消
        </el-button>
        <el-button
          type="primary"
          :loading="loading"
          @click="save()"
        >
          {{ loading ? "提交中 ..." : "保 存" }}
        </el-button>
      </div>
    </div>
  </el-drawer>
</template>
<script>
export default {
  data() {
    return {
      loading: false,
      title: '选择附近监控',
      visible: false,
      list: [],
      value4: [],
    }
  },
  mounted() {
    this.getStaff()
  },
  methods: {
    closeDialog() {
      this.visible = false
    },
    cancelForm() {
      this.$confirm('确认取消保存数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '已取消!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '未取消',
          })
          this.closeDialog()
        })
    },
    save() {
      this.$confirm('确认保存此数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
          this.closeDialog()
        })
    },
    handleClose(done) {
      if (this.loading) {
        return
      }
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          this.timer = setTimeout(() => {
            done()
            // 动画关闭需要一定的时间
            setTimeout(() => {
              this.loading = false
              this.closeDialog()
            }, 400)
          }, 500)
        })
        .catch(() => {
          setTimeout(() => {
            this.loading = false
            this.closeDialog()
          }, 400)
        })
    },
    getStaff() {
      this.list = [
        // { name: '张三', department: '项目部', position: '工程师1' },
        // { name: '李四', department: '设计部', position: '工程师2' },
        // { name: '王五', department: '人事部', position: '工程师2' },
        // { name: '赵六', department: '施工部', position: '工程师3' },
        { num: '1', camera: 'C1210.34.23.57' },
        { num: '2', camera: 'C1227.58.23.42' },
        { num: '3', camera: 'C1219.27.13.39' },
        { num: '4', camera: 'C1210.24.13.17' },
        { num: '5', camera: 'C1212.14.13.657' },
        { num: '6', camera: 'C1239.18.13.42' },
        { num: '7', camera: 'C1239.27.53.39' },
        { num: '8', camera: 'C1210.24.33.17' },
      ]
    },
  },
}
</script>
<style scoped>
.transfer-footer {
  margin-left: 20px;
  padding: 6px 5px;
}
</style>