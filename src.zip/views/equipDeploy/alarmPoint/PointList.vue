<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <!-- 1.1以表单的形式展示输入框 -->
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-row :gutter="30">
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item label="报警点名称:">
                <el-input
                  v-model="formCondition.alarmPointName"
                  placeholder="请选择"
                  class="input-form"
                />
              </el-form-item>
              <el-form-item
                label="监控区域:"
                size="large"
              >
                <el-select
                  v-model="formCondition.monitoringArea"
                  clearable
                  placeholder="请选择"
                  class="form-item-region"
                >
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item
                label="设备主机名称:"
                size="large"
              >
                <el-input
                  v-model="formCondition.hostName"
                  placeholder="请选择"
                  class="input-form"
                />
              </el-form-item>
              <el-form-item
                label="报警点类型:"
                size="large"
              >
                <el-select
                  v-model="formCondition.alarmPointType"
                  clearable
                  placeholder="请选择"
                  class="input-alarmType"
                >
                  <el-option
                    v-for="ala in options"
                    :key="ala.value"
                    :label="ala.label"
                    :value="ala.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item
                label="设备厂商名称："
                size="large"
              >
                <el-select
                  v-model="formCondition.firmName"
                  clearable
                  placeholder="请选择"
                  class="input-form"
                >
                  <el-option
                    v-for="ala in options"
                    :key="ala.value"
                    :label="ala.label"
                    :value="ala.value"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                label="状态:"
                size="large"
              >
                <el-select
                  v-model="formCondition.state"
                  clearable
                  placeholder="请选择"
                  class="input-alarmState"
                >
                  <el-option
                    v-for="sta in options"
                    :key="sta.value"
                    :label="sta.label"
                    :value="sta.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :span="6"
              :offset="18"
            >
              <el-button
                type="primary"
                size="mini"
                @click="handleFilter"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>

              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
                @click="handleExport"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-col>
          </el-row>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <!-- 2.此div是数据表格 -->
    <div class="table-container">
      <el-col :span="22">
        <h3>报警点列表</h3>
      </el-col>
      <el-col :span="2">
        <el-button
          type="primary"
          @click="edit()"
        >
          + 新增报警点
        </el-button>
      </el-col>
      <!-- alarmPointColumns -->
      <el-table
        v-loading="listLoading"
        :data="alarmPointList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
      >
        <el-table-column
          v-for="(col, index) in dataColumns"
          :key="index"
          :label="col.label"
          :width="col.width"
          height="100px"
          sortable="custom"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="col.value == 'alarmPointName'"
              class="font-color-blue"
            >
              {{
                scope.row[col.value]
              }}</span>
            <span v-if="col.value != 'alarmPointName'">{{
              scope.row[col.value]
            }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="center"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageable.page"
        :limit.sync="pageable.size"
        @pagination="getList"
      />
    </div>
    <alarmPointDrawer
      ref="alarmPointDrawer"
      @selectPeople="selectPeople"
      @selectMonitor="selectMonitor"
      @selectCoordinate="selectCoordinate"
    />
    <monitoringAreaTransferDrawer ref="monitoringAreaTransferDrawer" />
    <!-- <peopleTransferDrawer ref="peopleTransferDrawer" /> -->
    <informDrawer ref="informDrawer" />
    <coordinateDrawer ref="coordinateDrawer" />
  </div>
</template>
<script>
import Pagination from '@/components/Pagination'
import alarmPointDrawer from './AlarmPointDrawer'
import { alarmPointColumns } from '../tableList'
import monitoringAreaTransferDrawer from './MonitoringAreaTransferDrawer'
import informDrawer from '@/components/TransferDrawer/InformDrawer'
import coordinateDrawer from '../../monitorDeploy/CoordinateDrawer'
export default {
  name: 'PositionQuery',
  components: {
    Pagination,
    alarmPointDrawer,
    monitoringAreaTransferDrawer,
    informDrawer,
    coordinateDrawer
  }, // Drawer
  data() {
    return {
      activeName: 'form',
      alarmPointList: [],
      listLoading: true, // 列表加载
      drawerrVisible: false,
      dataColumns: alarmPointColumns,
      pageable: {
        page: 1,
        size: 10,
      },
      formCondition: {
        // 查询列表
        alarmPointName: '',
        hostName: '',
        monitoringArea: '',
        alarmPointType: '',
        alarmNum: '',
        state: '',
        mainMonitorCamera: '',
        installPosition: '',
        firmName: '',
      },
      options: [],
      total: 0, // 分页总数
      downloadLoading: false, // 导出表格加载按钮
      formData: {},
    }
  },
  mounted() {
    this.getList()
    this.getQueryOptions()
  },
  methods: {
    handleFilter() {},
    selectPeople() {
      //  this.$refs.peopleTransferDrawer.form = rowData
      this.$refs.informDrawer.visible = true
      this.$refs.informDrawer.drawerTitle = '添加报警通知人员'
    },
    selectCoordinate() {
      this.$refs.coordinateDrawer.visible = true
    },
    selectMonitor() {
      // this.$refs.monitoringAreaTransferDrawer.form = rowData
      this.$refs.monitoringAreaTransferDrawer.visible = true
    },
    // 下拉框获取数据
    getQueryOptions() {
      this.options.push(
        {
          value: '选项1',
          label: '区域1',
        },
        {
          value: '选项2',
          label: '区域2',
        },
        {
          value: '选项3',
          label: '区域3',
        }
      )
    },
    edit(rowData) {
      if (rowData) {
        this.$refs.alarmPointDrawer.title = '编辑报警点'
        this.$refs.alarmPointDrawer.form = rowData
      } else {
        this.$refs.alarmPointDrawer.title = '新增报警点'
        this.$refs.alarmPointDrawer.form = {}
      }
      this.$refs.alarmPointDrawer.visible = true
    },
    getList() {
      this.listLoading = true
      ;(this.alarmPointList = [
        {
          alarmPointName: '报警点1',
          hostName: '设备主机1',
          monitoringArea: '监控区域1',
          alarmPointType: '气体报警',
          alarmNum: '9198',
          state: '正常连接',
          mainMonitorCamera: '监控摄像机1',
          installPosition: '位置1',
        },
        {
          alarmPointName: '报警点1',
          hostName: '设备主机1',
          monitoringArea: '监控区域1',
          alarmPointType: '气体报警',
          alarmNum: '9198',
          state: '正常连接',
          mainMonitorCamera: '监控摄像机1',
          installPosition: '位置1',
        },
      ]),
        (this.listLoading = false)
    },
    handleExport() {}, // 导出表格的方法
  },
}
</script>
<style lang="scss" scoped>
.start-time-end {
  width: 300px;
}
.form-item-region {
  left: 5%;
  width: 300px;
  height: 40px;
}
.input-alarmState {
  left: 22%;
  width: 300px;
  height: 40px;
}
.input-alarmType {
  left: 5%;
  width: 300px;
  height: 40px;
}
</style>