<template>
  <el-drawer
    :title="title"
    :before-close="handleClose"
    :visible.sync="visible"
    direction="rtl"
    size="40%"
    custom-class="demo-drawer"
  >
    <el-divider class="divider" />
    <el-form
      :model="form"
      class="el-form"
    >
      <el-form-item
        label="报警点名称"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.alarmPointName"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
      <el-form-item
        label="报警编码"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.alarmNum"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        label="设备主机名称"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.hostName"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        label="报警点类型"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.alarmPointType"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        label="主监控摄像机"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.mainMonitorCamera"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-row>
        <el-col :span="20">
          <el-form-item
            label="附近监控"
            :label-width="formLabelWidth"
          >
            <el-input
              v-model="form.nearMonitor"
              class="form-item-people"
              placeholder="请输入"
            />
          </el-form-item>
        </el-col>
        <el-col :span="2">
          <el-button
            type="info"
            plain
            @click="selectMonitor"
          >
            选择监控
          </el-button>
        </el-col>
      </el-row>
      <el-form-item
        label="报警通知模板"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.alarmNoticeTemplate"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-row>
        <el-col :span="20">
          <el-form-item
            label="报警通知人员"
            :label-width="formLabelWidth"
          >
            <el-input
              v-model="form.alarmNoticePeople"
              class="form-item-people"
              placeholder="请输入"
            />
          </el-form-item>
        </el-col>
        <el-col :span="2">
          <el-button
            type="info"
            plain
            @click="selectPeople"
          >
            选择人员
          </el-button>
        </el-col>
      </el-row>
      <el-form-item
        label="区域"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.monitoringArea"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="alarmSta in alarmStatus"
            :key="alarmSta.value"
            :label="alarmSta.label"
            :value="alarmSta.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        :label-width="formLabelWidth"
        label="区域中的坐标"
      >
        <el-col :span="10">
          <el-form-item label="X">
            <el-input
              v-model="form.coordinateX"
              size="small"
              class="input-position"
            />
          </el-form-item>
        </el-col>
        <el-col :span="9">
          <el-form-item label="Y">
            <el-input
              v-model="form.coordinateY"
              class="input-position"
            />
          </el-form-item>
        </el-col>
        <el-col :span="2">
          <el-button
            type="info"
            plain
            @click="selectCoordinate()"
          >
            选择坐标
          </el-button>
        </el-col>
      </el-form-item>
      <el-form-item
        label="安装位置"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.installPosition"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
    </el-form>
    <el-divider class="divider-foot" />
    <div class="drawer-footer">
      <el-button @click="cancelForm">
        取 消
      </el-button>
      <el-button
        type="primary"
        :loading="loading"
        @click="save()"
      >
        {{ loading ? "提交中 ..." : "保 存" }}
      </el-button>
    </div>
  </el-drawer>
</template>
<script>
// import monitoringAreaTransferDrawer from './MonitoringAreaTransferDrawer'
// import peopleTransferDrawer from './PeopleTransferDrawer'
export default {
  name: 'EditDrawer',
  components: {}, // Drawer
  data() {
    return {
      title: '',
      form: {
        // 抽屉表单
        alarmPointName: '',
        hostName: '',
        monitoringArea: '',
        alarmPointType: '',
        alarmNum: '',
        state: '',
        mainMonitorCamera: '',
        installPosition: '',
        nearMonitor: '',
        alarmNoticeTemplate: '',
        alarmNoticePeople: '',
        coordinateX: '',
        coordinateY: '',
      },
      alarmStatus: '',
      visible: false,
      loading: false,
      timer: null,
      formLabelWidth: '150px',
    }
  },
  mounted() {
    this.selectData()
  },
  methods: {
    selectCoordinate() {
      this.$emit('selectCoordinate')
    },
    selectPeople() {
      this.$emit('selectPeople')
    },
    selectMonitor() {
      this.$emit('selectMonitor')
    },
    // 下拉框获取数据
    selectData() {
      this.alarmStatus = []
      this.alarmStatus.push(
        {
          value: '气体探头报警',
          label: '可燃气体探头报警',
        },
        {
          value: '液体探头报警',
          label: '可燃液体探头报警',
        }
      )
    },
    handleClose(done) {
      if (this.loading) {
        return
      }
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          this.timer = setTimeout(() => {
            done()
            // 动画关闭需要一定的时间
            setTimeout(() => {
              this.loading = false
              this.closeDialog()
            }, 400)
          }, 500)
        })
        .catch(() => {
          setTimeout(() => {
            this.loading = false
            this.closeDialog()
          }, 400)
        })
    },
    closeDialog() {
      this.visible = false
    },
    cancelForm() {
      this.$confirm('确认取消保存数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '已取消!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '未取消',
          })
          this.closeDialog()
        })
    },
    save() {
      this.$confirm('确认保存此数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
          this.closeDialog()
        })
    },
  },
}
</script>
<style lang="scss" scoped>
.form-item-drawer {
  width: 75%;
}
.el-form {
  margin-top: 8%;
  margin-left: 5%;
}
.input-position {
  width: 180px;
}
.form-item-people {
  width: 95%;
}
</style>