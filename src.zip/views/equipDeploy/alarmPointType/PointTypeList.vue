<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-col :span="18">
            <el-form-item label="报警点类型名称：">
              <el-input
                v-model="formCondition.alarmPointTypeName"
                class="input-form"
              />
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                type="primary"
                size="mini"
                @click="handleFilter"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
                @click="handleExport"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-form-item>
          </el-col>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <div class="table-container">
      <el-col :span="22">
        <h3>报警点类型列表</h3>
      </el-col>
      <el-col :span="2">
        <el-button
          type="primary"
          @click="edit()"
        >
          + 新增报警点类型
        </el-button>
      </el-col>
      <!-- alarmPointColumns -->
      <el-table
        v-loading="listLoading"
        :data="alarmPointTypeList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
      >
        <el-table-column
          v-for="(col, index) in dataColumns"
          :key="index"
          :label="col.label"
          :width="col.width"
          height="100px"
          sortable="custom"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="col.value == 'alarmPointName'"
              class="font-color-blue"
            >
              {{
                scope.row[col.value]
              }}</span>
            <span v-if="col.value != 'alarmPointName'">{{
              scope.row[col.value]
            }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="center"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageable.page"
        :limit.sync="pageable.size"
        @pagination="getList"
      />
    </div>
    <pointTypeDrawer
      ref="pointTypeDrawer"
      :visible="drawerVisible"
      :form-data="formData"
    />
  </div>
</template>
<script>
import Pagination from '@/components/Pagination'
import pointTypeDrawer from './PointTypeDrawer'
import { alarmPointTypeColumns } from '../tableList'
export default {
  name: 'PointTypeQuery',
  components: { Pagination, pointTypeDrawer },
  data() {
    return {
      drawerVisible: false,
      activeName: 'form',
      alarmPointTypeList: [],
      listLoading: true, // 列表加载
      drawerrVisible: false,
      dataColumns: alarmPointTypeColumns,
      pageable: {
        page: 1,
        size: 10,
      },
      formCondition: {
        // 查询列表
        alarmPointTypeName: '',
        alarmPointTypeDescribe: '',
      },
      options: [],
      total: 0, // 分页总数
      downloadLoading: false, // 导出表格加载按钮
      formData: {},
    }
  },
  mounted() {
    this.getList()
    this.getQueryOptions()
  },
  methods: {
    // 查询方法
    handleFilter() {},
    // 下拉框获取数据
    getQueryOptions() {
      this.options.push(
        {
          value: '选项1',
          label: '区域1',
        },
        {
          value: '选项2',
          label: '区域2',
        },
        {
          value: '选项3',
          label: '区域3',
        }
      )
    },
    edit(rowData) {
      if (rowData) {
        this.$refs.pointTypeDrawer.title = '编辑报警点类型'
        this.$refs.pointTypeDrawer.form = rowData
      } else {
        this.$refs.pointTypeDrawer.title = '新增报警点类型'
        this.$refs.pointTypeDrawer.form = {}
      }
      this.$refs.pointTypeDrawer.visible = true
    },
    getList() {
      this.listLoading = true
      ;(this.alarmPointTypeList = [
        {
          alarmPointTypeName: '名称1',
          alarmPointTypeDescribe: '这个报警点类型很好',
        },
        {
          alarmPointTypeName: '名称2',
          alarmPointTypeDescribe: '这个报警点类型很好',
        },
      ]),
        (this.listLoading = false)
    },
    handleExport() {}, // 导出表格的方法
  },
}
</script>
<style lang="scss" scoped>
</style>