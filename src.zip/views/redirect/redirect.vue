<script>
import { mapGetters } from 'vuex'
export default {
  created() {
    // const { params, query } = this.$route
    // const { path } = params
    // this.$router.replace({ path: '/' + path, query })
    console.log('pages', this.pages)
    console.log('pageName', this.pages[0].pageName)
    this.$router.replace({ name: this.pages[0].pageName })
  },
  computed: {
    ...mapGetters(['pages'])
  },
  render: function(h) {
    return h() // avoid warning message
  }
}
</script>
