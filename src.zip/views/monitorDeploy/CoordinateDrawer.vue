<template>
  <el-drawer
    :title="drawerTitle"
    :visible.sync="visible"
    direction="ltr"
    size="40%"
    custom-class="demo-drawer"
  >
    <el-divider class="divider" />
    <el-form
      :model="form"
      class="el-form"
    >
      <el-form-item>
        <el-col
          :span="3"
          :offset="4"
        >
          <span>区域坐标</span>
        </el-col>
        <el-col :span="4">
          <el-form-item label="X">
            <el-input
              v-model="form.coordinateX"
              size="small"
              class="input-position"
            />
          </el-form-item>
        </el-col>
        <el-col :span="4">
          <el-form-item label="Y">
            <el-input
              v-model="form.coordinateY"
              class="input-position"
            />
          </el-form-item>
        </el-col>
      </el-form-item>
    </el-form>
    <el-divider class="divider-foot" />
    <div class="drawer-footer">
      <el-button @click="cancelForm">
        取 消
      </el-button>
      <el-button
        type="primary"
        :loading="loading"
        @click="save()"
      >
        {{ loading ? "提交中 ..." : "保 存" }}
      </el-button>
    </div>
  </el-drawer>
</template>
<script>
export default {
  name: 'EditDrawer',
  data() {
    return {
      drawerTitle: '选择坐标',
      form: {
        coordinateX: '',
        coordinateY: ''
      },
      visible: false,
      loading: false,
    }
  },
  methods: {
    closeDialog() {
      this.visible = false
    },
    cancelForm() {
      this.$confirm('确认取消保存数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '已取消!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '未取消',
          })
          this.closeDialog()
        })
    },
    save() {
      this.$confirm('确认保存此数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
          this.closeDialog()
        })
    },
  },
}
</script>
<style scoped>
  .input-position {
  width: 70px;
}
</style>