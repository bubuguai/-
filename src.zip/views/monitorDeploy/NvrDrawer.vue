<template>
  <el-drawer
    :title="drawerTitle"
    :before-close="handleClose"
    :visible.sync="visible"
    direction="rtl"
    size="40%"
    custom-class="demo-drawer"
  >
    <!-- {{this.formData}} -->
    <el-divider class="divider" />
    <el-form
      ref="form"
      :model="form"
      class="el-form"
      :rules="rules"
    >
      <el-form-item
        label="名称"
        prop="hostName"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.hostName"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
      <el-form-item
        label="IP"
        prop="sensorid"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="form.sensorid"
          clearable
          class="form-item-drawer"
        >
          <el-option
            v-for="op in options"
            :key="op.value"
            :label="op.label"
            :value="op.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        label="登录名"
        prop="dcsAlarmTypeName"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.dcsAlarmTypeName"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
      <el-form-item
        label="密码"
        prop="id"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="form.id"
          class="form-item-drawer"
          placeholder="请输入"
        />
      </el-form-item>
    </el-form>
    <el-divider class="divider-foot" />
    <div class="drawer-footer">
      <el-button @click="cancelForm">
        取 消
      </el-button>
      <el-button
        type="primary"
        :loading="loading"
        @click="save()"
      >
        {{ loading ? "提交中 ..." : "保 存" }}
      </el-button>
    </div>
  </el-drawer>
</template>
<script>
export default {
  name: 'EditDrawer',
  data() {
    return {
      drawerTitle: '',
      form: {
        // 抽屉表单
        dcsAlarmTypeName: '', // 模拟登录名数据
        id: '',
        sensorid: '', // 模拟IP数据
        hostName: '', // 模拟NVR名称数据
      },
      rules: {
        hostName: [
          { required: true, message: '请输入NVR名称', trigger: 'blur' }
          // { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
        ],
        sensorid: [
          { required: true, message: '请选择IP', trigger: 'change' }
        ],
        dcsAlarmTypeName: [
          { required: true, message: '请输入登录名', trigger: 'blur' }
        ],
        id: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ]
      },
      options: [],
      visible: false,
      loading: false,
      timer: null,
      formLabelWidth: '150px',
    }
  },
  mounted() {
    this.getQueryOptions();
  },
  methods: {
    // 下拉框获取数据
    getQueryOptions() {
      this.options.push(
        {
          value: '气体探头报警',
          label: '可燃气体探头报警',
        },
        {
          value: '液体探头报警',
          label: '可燃液体探头报警',
        }
      )
    },
    handleClose(done) {
      if (this.loading) {
        return
      }
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          this.timer = setTimeout(() => {
            done()
            // 动画关闭需要一定的时间
            setTimeout(() => {
              this.loading = false
              this.closeDialog()
            }, 400)
          }, 500)
        })
        .catch(() => {
          setTimeout(() => {
            this.loading = false
            this.closeDialog()
          }, 400)
        })
    },
    closeDialog() {
      this.visible = false
    },
    cancelForm() {
      this.$confirm('确认取消保存数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '已取消!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '未取消',
          })
          this.closeDialog()
        })
    },
    save() {
      this.$confirm('确认保存此数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
          this.closeDialog()
        })
    },
  },
}
</script>
<style lang="scss" scoped>
.form-item-drawer {
  width: 75%;
}
.el-form {
  margin-top: 8%;
  margin-left: 5%;
}
</style>