<template>
  <div class="app-container">
    <!-- 1.第一行是各种搜索框和筛选、导出按钮 -->
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-row>
            <el-col :span="8">
              <el-form-item label="NVR名称：">
                <el-input
                  v-model="formCondition.hostName"
                  class="input-form"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="NVR地址：">
                <el-input
                  v-model="formCondition.hostName"
                  class="input-form"
                />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="NVR状态:">
                <el-select
                  v-model="formCondition.dcsAlarmState"
                  class="input-form"
                  clearable
                >
                  <el-option
                    v-for="op in options"
                    :key="op.value"
                    :label="op.label"
                    :value="op.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          
            <el-col
              :span="2"
              :offset="18"
            >
              <el-form-item>
                <el-button
                  type="primary"
                  size="mini"
                  @click="handleFilter"
                >
                  <svg-icon icon-class="screen-l" />
                  查询
                </el-button>
              </el-form-item>
            </el-col>
            <el-col :span="2">
              <el-form-item>
                <el-button
                  class="query-button"
                  :loading="downloadLoading"
                  type="default"
                  size="mini"
                  @click="handleExport"
                >
                  <svg-icon icon-class="export" />
                  导出表格
                </el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <!-- 1.ending -->
    <!-- 2.此div是数据表格 -->
    <div class="table-container">
      <el-col :span="22">
        <h3>NVR列表</h3>
      </el-col>
      <el-col :span="2">
        <el-button
          type="primary"
          @click="edit()"
        >
          + 新增NVR
        </el-button>
      </el-col>
      <el-table
        v-loading="listLoading"
        :data="list"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(col, index) in dataColumns"
          :key="index"
          :label="col.label"
          :width="col.width"
          height="100px"
          sortable="custom"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="col.value == 'hostName'"
              class="font-color-blue"
            >
              {{
                scope.row[col.value]
              }}</span>
            <span v-if="col.value != 'hostName'">{{
              scope.row[col.value]
            }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="center"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageable.page"
        :limit.sync="pageable.size"
        @pagination="getList"
      />
    </div>
    <!-- 新增和编辑NVR -->
    <nvrDrawer
      ref="nvrDrawer"
      :visible="drawerVisible"
      :form-data="formData"
    />
  </div>
</template>
<script>
import { selectDcsAlarmRecord, selectDcsAlarmType } from '@/api/DCSAlarmQuery'
import Pagination from '@/components/Pagination'
import nvrDrawer from './NvrDrawer'
import { nvrColumns } from './tableList'
export default {
  name: 'NVRQuery',
  components: { Pagination, nvrDrawer },
  data() {
    return {
      activeName: 'form',
      dataColumns: nvrColumns,
      pageable: {
        page: 1,
        size: 10,
      },
      nvrTittle: '',
      IP: '',
      //   区域的下拉框测试数据
      options: [],
      //   区域的下拉框测试数据
      value: '',
      list: null,
      total: 0,
      listLoading: true,
      formCondition: {
        hostName: '',
        sensorid: '',
        dcsAlarmState: '',
        sortRule: 2,
        id: ''
      },
      downloadLoading: false,
      formData: {},
      drawerVisible: false,
    }
  },
  mounted() {
    this.getList()
    this.getAlarmType()
    this.getQueryOptions()
  },
  methods: {
    // 下拉框获取数据
    getQueryOptions() {
      this.options.push(
        {
          value: '选项1',
          label: '区域1',
        },
        {
          value: '选项2',
          label: '区域2',
        },
        {
          value: '选项3',
          label: '区域3',
        }
      )
    },
    edit(rowData) {
      if (rowData) {
        this.$refs.nvrDrawer.drawerTitle = '编辑NVR'
        this.$refs.nvrDrawer.form = rowData
      } else {
        this.$refs.nvrDrawer.drawerTitle = '新增NVR'
        this.$refs.nvrDrawer.form = {}
      }
      this.$refs.nvrDrawer.visible = true
    },
    getList() {
      const param = this.formCondition
      this.listLoading = true
      selectDcsAlarmRecord({
        page: param.page - 1,
        size: param.size,
        hostName: param.hostName,
        id: param.id,
        dcsAlarmState: param.dcsAlarmState,
        sortRule: param.sortRule,
      }).then((res) => {
        if (res.data.result === 'success') {
          this.list = res.data.data.list
          this.total = res.data.data.totalNum
          this.listLoading = false
        } else {
          this.listLoading = false
        }
      })
    },
    getAlarmType() {
      selectDcsAlarmType().then((res) => {
        if (res.data.result === 'success') {
          this.alarmTypeOptions = res.data.data.dcsAlarmTypeList
        }
      })
    },
    handleFilter() {
      this.list = []
      this.total = 0
      this.pageable.page = 1
      this.getList()
    },
    sortChange(data) {
      if (data.order === 'ascending') {
        this.formCondition.sortRule = 1
      } else {
        this.formCondition.sortRule = 2
      }
      this.formCondition.sortField = data.prop
      this.getList()
    },
    handleExport() {},
  },
}
</script>
<style lang="scss" scoped>
.imgicon {
  text-align: center;
  margin: 260px auto;
  font-size: 30px;
  cursor: pointer;
}
.el-form-item--mini.el-form-item {
  margin-bottom: 0;
}
.DCS_tab {
  margin-left: 1%;
  width: 98%;
  line-height: 22px;
  /* height: 550px; */
  .sco {
    color: #1890ff;
    font-family: SFProText-Regular;
    font-size: 14px;
  }
  .btncor {
    color: #096dd9;
  }
}
.table-lg {
  margin-left: 2%;
  margin-top: 2%;
}
.list {
  margin-top: 0.4%;
  margin-left: 1%;
  margin-bottom: 2%;
  margin-right: 1.5%;
  opacity: 0.85;
  font-family: PingFangSC-Medium;
  font-size: 16px;
  color: #000000;
  line-height: 24px;
}
.dialog-el {
  width: 60%;
  top: 20%;
  left: 23%;
}
.dialog-peo {
  width: 60%;
  top: 30%;
  left: 21%;
}
.formItem {
  width: 97%;
}
.selectEl {
  width: 100%;
}
.selectPeople {
  width: 36%;
}
.query-button {
  margin-left: 20%;
}
/deep/ .el-icon-close:before {
  color: #001529 !important;
}
</style>
