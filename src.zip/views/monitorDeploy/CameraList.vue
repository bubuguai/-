<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <!-- 1.1以表单的形式展示输入框 -->
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-row :gutter="30">
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item
                label="摄像机名称："
                size="large"
              >
                <el-input
                  v-model="formCondition.name"
                  placeholder="请输入"
                  class="input-form"
                />
              </el-form-item>
              <el-form-item
                label="摄像机状态:"
                size="large"
              >
                <el-select
                  v-model="formCondition.state"
                  clearable
                  :disabled="true"
                  placeholder="请选择"
                  class="input-camerastate"
                >
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item
                label="区域:"
                size="large"
              >
                <el-select
                  v-model="formCondition.region"
                  clearable
                  placeholder="请选择"
                  class="input-region"
                >
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
              <el-form-item
                label="滚动显示:"
                size="large"
              >
                <el-select
                  v-model="formCondition.scrolling"
                  clearable
                  :disabled="true"
                  placeholder="请选择"
                  class="input-form"
                >
                  <el-option
                    v-for="ala in options"
                    :key="ala.value"
                    :label="ala.label"
                    :value="ala.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item
                label="NVR："
                size="large"
              >
                <el-input
                  v-model="formCondition.nvr"
                  placeholder="请输入"
                  class="input-nvr"
                />
              </el-form-item>
              <el-form-item
                label="具体安置帮位置："
                size="large"
              >
                <el-input
                  v-model="formCondition.location"
                  placeholder="请输入"
                  class="input-form"
                />
              </el-form-item>
            </el-col>
            <el-col
              :span="6"
              :offset="18"
            >
              <el-button
                type="primary"
                size="mini"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>

              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-col>
          </el-row>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <!-- 2.此div是数据表格 -->
    <div class="table-container">
      <el-col :span="22">
        <h3>摄像机列表</h3>
      </el-col>
      <el-col :span="2">
        <el-button
          type="primary"
          @click="edit()"
        >
          + 新增摄像机
        </el-button>
      </el-col>
      <el-table
        v-loading="listLoading"
        :data="cameraList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
      >
        <el-table-column
          v-for="(col, index) in dataColumns"
          :key="index"
          :label="col.label"
          :width="col.width"
          height="100px"
          sortable="custom"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="col.value == 'name'"
              class="font-color-blue"
            >
              {{
                scope.row[col.value]
              }}</span>
            <span v-if="col.value != 'name'">{{
              scope.row[col.value]
            }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="视频查看"
          align="center"
          class-name="small-padding fixed-width"
        >
          <el-link target="_blank">
            监控
          </el-link>
          <el-divider direction="vertical" />
          <el-link target="_blank">
            录像
          </el-link>
        </el-table-column>
        <el-table-column
          label="操作"
          align="center"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageable.page"
        :limit.sync="pageable.size"
        @pagination="getList"
      />
    </div>
    <!-- 2.ending -->
    <cameraDrawer
      ref="cameraDrawer"
      :visible="drawerVisible"
      :form-data="formData"
    />
  </div>
</template>
<script>
import Pagination from "@/components/Pagination";
import cameraDrawer from "./CameraDrawer";
import { cameraColumns } from "./tableList";
export default {
  name: "CameraQuery",
  components: { Pagination, cameraDrawer }, // Drawer
  data() {
    return {
      drawerVisible: false,
      activeName: "form",
      dataColumns: cameraColumns,
      pageable: {
        page: 1,
        size: 10,
      },
      cameraList: null, // 记录摄像机列表的数据
      formCondition: {
        // 查询列表
        name: '',
        ip: '',
        state: '',
        nvr: '',
        passNum: '',
        region: '',
        scrolling: '',
        location: ''
      },
      options: [],
      total: 0, // 分页总数
      listLoading: true, // 列表加载
      alarmTypeOptions: [],
      downloadLoading: false, // 导出表格加载按钮
      formData: {},
    };
  },
  mounted() {
    this.getList();
    this.getQueryOptions();
  },
  methods: {
    // 下拉框获取数据
    getQueryOptions() {
      this.options.push(
        {
          value: "选项1",
          label: "区域1",
        },
        {
          value: "选项2",
          label: "区域2",
        },
        {
          value: "选项3",
          label: "区域3",
        }
      );
    },
    edit(rowData) {
        if(rowData){
          this.$refs.cameraDrawer.drawerTitle = '编辑摄像机'
          this.$refs.cameraDrawer.form = rowData;
        } else {
          this.$refs.cameraDrawer.drawerTitle = '新增摄像机'
          this.$refs.cameraDrawer.form = {};
        }
        this.$refs.cameraDrawer.visible = true
    },
    getList() {
      this.listLoading = true;
      this.cameraList = [
          {
            name: '上海摄像机',
            ip: '192.168.17.1',
            state: '正常连接',
            nvr: '789987',
            passNum: '1',
            region: 'C11-1F',
            scrolling: '是',
            location: '东南角'
          },
          {
            name: '北京摄像机',
            ip: '192.168.18.2',
            state: '正常连接',
            nvr: '456654',
            passNum: '1',
            region: 'C11-2F',
            scrolling: '是',
            location: '西南角'
          },
          {
            name: '广州摄像机',
            ip: '192.168.19.3',
            state: '连接中断',
            nvr: '123321',
            passNum: '2',
            region: 'C11-3F',
            scrolling: '是',
            location: '东北角'
          }
      ],
      this.listLoading = false;
    },
    handleExport() {}, // 导出表格的方法
  },
};
</script>
<style lang="scss" scoped>
.input-camerastate {
  left: 4%;
  width: 300px;
  height: 40px;
}
.input-region {
  left: 9%;
  width: 300px;
  height: 40px;
}
.input-nvr {
  left: 22%;
  width: 300px;
  height: 40px;
}
.query-button {
  margin-left: 15%;
}
.start-time-end {
  width: 300px;
}
</style>
