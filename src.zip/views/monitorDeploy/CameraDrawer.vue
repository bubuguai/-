<template>
  <div>
    <el-drawer
      :title="drawerTitle"
      :before-close="handleClose"
      :visible.sync="visible"
      direction="rtl"
      size="40%"
      custom-class="demo-drawer"
    >
      <el-divider class="divider" />
      <el-form
        :model="form"
        class="el-form"
        :rules="rules"
      >
        <el-form-item
          prop="name"
          label="摄像机名称"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="form.name"
            class="form-item-drawer"
            placeholder="请输入"
          />
        </el-form-item>
        <el-form-item
          prop="ip"
          label="IP"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="form.ip"
            class="form-item-drawer"
            placeholder="请输入"
          />
        </el-form-item>
        <el-form-item
          prop="nvr"
          label="NVR"
          :label-width="formLabelWidth"
        >
          <el-select
            v-model="form.nvr"
            clearable
            class="form-item-drawer"
          >
            <el-option
              v-for="alarmSta in alarmStatus"
              :key="alarmSta.value"
              :label="alarmSta.label"
              :value="alarmSta.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          prop="passNum"
          label="通道号"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="form.passNum"
            class="form-item-drawer"
            placeholder="请输入"
          />
        </el-form-item>
        <el-form-item
          prop="loginName"
          label="登录名"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="form.loginName"
            class="form-item-drawer"
            placeholder="请输入"
          />
        </el-form-item>
        <el-form-item
          prop="password"
          label="密码"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="form.password"
            class="form-item-drawer"
            placeholder="请输入"
          />
        </el-form-item>
        <el-form-item
          prop="nvrSelect"
          label="通过NVR连接"
          :label-width="formLabelWidth"
        >
          <el-select
            v-model="form.nvrSelect"
            clearable
            :disabled="true"
            class="form-item-drawer"
          >
            <el-option
              v-for="alarmSta in alarmStatus"
              :key="alarmSta.value"
              :label="alarmSta.label"
              :value="alarmSta.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          prop="scrolling"
          label="滚动显示"
          :label-width="formLabelWidth"
        >
          <el-select
            v-model="form.scrolling"
            clearable
            :disabled="true"
            class="form-item-drawer"
            placeholder="请选择"
          >
            <el-option
              v-for="alarmSta in alarmStatus"
              :key="alarmSta.value"
              :label="alarmSta.label"
              :value="alarmSta.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          prop="region"
          label="区域"
          :label-width="formLabelWidth"
        >
          <el-select
            v-model="form.region"
            clearable
            class="form-item-drawer"
            placeholder="请选择"
          >
            <el-option
              v-for="alarmSta in alarmStatus"
              :key="alarmSta.value"
              :label="alarmSta.label"
              :value="alarmSta.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          prop="location"
          label="具体安装位置"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="form.location"
            class="form-item-drawer"
            placeholder="请输入"
          />
        </el-form-item>
        <el-form-item
          :label-width="formLabelWidth"
          label="在区域中的坐标"
        >
          <el-col :span="5">
            <el-form-item label="X">
              <el-input
                v-model="form.coordinateX"
                size="small"
                class="input-position"
              />
            </el-form-item>
          </el-col>
          <el-col :span="5">
            <el-form-item label="Y">
              <el-input
                v-model="form.coordinateY"
                class="input-position"
              />
            </el-form-item>
          </el-col>
          <el-col
            :span="4"
            :offset="4"
          >
            <el-button
              type="primary"
              @click="selectPosition()"
            >
              选择坐标
            </el-button>
          </el-col>
        </el-form-item>
      </el-form>
      <el-upload
        class="upload-pic"
        drag
        action="https://jsonplaceholder.typicode.com/posts/"
        multiple
      >
        <i class="el-icon-upload" />
        <div class="el-upload__text">
          将文件拖到此处，或<em>点击上传</em>
        </div>
        <div
          slot="tip"
          class="el-upload__tip"
        >
          只能上传jpg/png文件，且不超过500kb
        </div>
      </el-upload>
      <el-divider class="divider-foot" />
      <div class="drawer-footer">
        <el-button @click="cancelForm">
          取 消
        </el-button>
        <el-button
          type="primary"
          :loading="loading"
          @click="save()"
        >
          {{ loading ? "提交中 ..." : "保 存" }}
        </el-button>
      </div>
    </el-drawer>
    <coordinateDrawer
      ref="coordinateDrawer"
      :visible="drawerVisible"
      :form-data="formData"
    />
  </div>
</template>
<script>
import coordinateDrawer from "./CoordinateDrawer";
export default {
  name: 'EditDrawer',
  components: { coordinateDrawer }, // Drawer
  data() {
    return {
      drawerVisible: false,
      drawerTitle: '',
      formData: {},
      form: {
        // 抽屉表单
        name: '',
        ip: '',
        state: '',
        nvr: '',
        passNum: '',
        region: '',
        scrolling: '',
        location: '',
        loginName: '',
        password: '',
        nvrSelect: '',
        coordinateX: '',
        coordinateY: ''
      },
      alarmStatus: '',
      visible: false,
      loading: false,
      timer: null,
      formLabelWidth: '150px',
      rules: {
        name: [
          { required: true, message: '请输入摄像机名称', trigger: 'blur' }
        ],
        ip: [
          { required: true, message: '请输入IP', trigger: 'blur' }
        ],
        state: [
          { required: true, message: '请输入状态', trigger: 'blur' }
        ],
        nvr: [
          { required: true, message: '请选择NVR', trigger: 'change' }
        ],
        passNum: [
          { required: true, message: '请输入通道号', trigger: 'blur' }
        ],
        region: [
          { required: true, message: '请选择区域', trigger: 'change' }
        ],
        scrolling: [
          { required: true, message: '请选择是否滚动显示', trigger: 'change' }
        ],
        location: [
          { required: true, message: '请输入具体安装位置', trigger: 'blur' }
        ],
        loginName: [
          { required: true, message: '请输入登录名', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' }
        ],
        nvrSelect: [
          { required: true, message: '请选择是否连接', trigger: 'change' }
        ]
      }
    }
  },
  mounted() {
    this.selectData()
  },
  methods: {
    // 下拉框获取数据
    selectData() {
      this.alarmStatus = []
      this.alarmStatus.push(
        {
          value: '气体探头报警',
          label: '可燃气体探头报警',
        },
        {
          value: '液体探头报警',
          label: '可燃液体探头报警',
        }
      )
    },
    selectPosition() {
      this.$refs.coordinateDrawer.visible = true
    },
    handleClose(done) {
      if (this.loading) {
        return
      }
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          this.timer = setTimeout(() => {
            done()
            // 动画关闭需要一定的时间
            setTimeout(() => {
              this.loading = false
              this.closeDialog()
            }, 400)
          }, 500)
        })
        .catch(() => {
          setTimeout(() => {
            this.loading = false
            this.closeDialog()
          }, 400)
        })
    },
    closeDialog() {
      this.visible = false
    },
    cancelForm() {
      this.$confirm('确认取消保存数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '已取消!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '未取消',
          })
          this.closeDialog()
        })
    },
    save() {
      this.$confirm('确认保存此数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
          this.closeDialog()
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
          this.closeDialog()
        })
    },
  },
}
</script>
<style lang="scss" scoped>
.form-item-drawer {
  width: 75%;
}
.el-form {
  margin-top: 8%;
  margin-left: 5%;
}
.input-position {
  width: 70px;
}
.upload-pic {
  text-align: center;
}
</style>