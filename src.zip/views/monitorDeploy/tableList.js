export const nvrColumns = [
  // table表格数据
  {
    label: "NVR名称",
    value: "hostName",
    width: "280px"
  },
  {
    label: "IP",
    value: "sensorid",
    width: "280px"
  },
  {
    label: "状态",
    value: "dcsAlarmState",
    width: "250px"
  },
  {
    label: "登录名",
    value: "dcsAlarmTypeName",
    width: "300px"
  },
  {
    label: "密码",
    value: "id",
    width: "300px"
  }
];

export const cameraColumns = [
  // table表格数据
  {
    label: "名称",
    value: "name",
    width: "170px"
  },
  {
    label: "IP",
    value: "ip",
    width: "170px"
  },
  {
    label: "状态",
    value: "state",
    width: "170px"
  },
  {
    label: "NVR",
    value: "nvr",
    width: "150px"
  },
  {
    label: "通道号",
    value: "passNum",
    width: "120px"
  },
  {
    label: "区域",
    value: "region",
    width: "150px"
  },
  {
    label: "滚动显示",
    value: "scrolling",
    width: "150px"
  },
  {
    label: "具体位置",
    value: "location"
  }
];
