<template>
  <div class="app-container">
    <!-- 1.第一行是各种搜索框和筛选、导出按钮 -->
    <el-row v-show="divshow" class="search-bar">
      <!-- 1.1以表单的形式展示输入框 -->
      <el-form
        :inline="true"
        style="width: 1703px; height: 50px"
        class="table-lg"
        size="small"
      >
        <!--<el-link
              @click="show1"
              style="margin-top: 8px; color: steelblue"
              >收起<i
                class="el-icon-arrow-up el-icon--right"
                style="color: steelblue"
              ></i>
            </el-link>-->

        <!-- 第一行，包括报警点名称、区域、主机、报警点类型、报警点状态 -->
        <el-row>
          <!-- 报警点名称input -->
          <el-col :span="2">
            <el-form-item
              label="报警点名称："
              size="small"
              label-width="100px"
            >
              <el-input
                v-model="alarmName"
                placeholder="请选择"
                style="width: 170px; height: 27px"
              />
            </el-form-item>
          </el-col>

          <!-- 区域select -->
          <el-col :span="2" :offset="1">
            <el-form-item label="区域:" size="small" label-width="50px">
              <el-select
                v-model="value"
                clearable
                placeholder="请选择"
                style="width: 170px; height: 27px"
                @change="select2"
              >
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <!-- 主机 select -->
          <el-col :span="2" :offset="1">
            <el-form-item label="主机:" size="small" label-width="50px">
              <el-select
                v-model="select.host"
                clearable
                placeholder="请选择"
                style="width: 170px; height: 27px"
                @change="select2"
              >
                <el-option
                  v-for="hos in hosts"
                  :key="hos.value"
                  :label="hos.label"
                  :value="hos.value"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <!-- 报警点类型select -->
          <el-col :span="2" :offset="1">
            <el-form-item label="报警点类型:" size="small" label-width="90px">
              <el-select
                v-model="select.alarmType"
                clearable
                placeholder="请选择"
                style="width: 170px; height: 27px"
                @change="select2"
              >
                <el-option
                  v-for="alt in alarmTypes"
                  :key="alt.value"
                  :label="alt.label"
                  :value="alt.value"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <!-- 报警点状态select -->
          <el-col :span="2" :offset="1">
            <el-form-item label="报警点状态:" size="small" label-width="95px">
              <el-select
                v-model="select.alarmStatu"
                clearable
                placeholder="请选择"
                style="width: 170px; height: 27px"
                @change="select2"
              >
                <el-option
                  v-for="alarm in alarmStatus"
                  :key="alarm.value"
                  :label="alarm.label"
                  :value="alarm.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <!-- 查询按钮 -->
          <el-col :span="2" :offset="5">
            <div v-if="isbuttonmoves === false">
              <el-button
                plain
                type="primary"
                size="mini"
                style="margin-top:30px"
                @click="handleFilter"
              >
                <svg-icon
                  icon-class="screen-l"
                  style="width: 20px; height: 14px"
                />
                查询
              </el-button>
            </div>
          </el-col>
          <!-- 导出表格按钮 -->
          <el-col :span="2">
            <div>
              <el-button
                :loading="downloadLoading"
                plain
                type="primary"
                size="mini"
                style="margin-top:30px"
                @click="handleExport"
              >
                <svg-icon
                  icon-class="export"
                  style="margin-right: 3px; width: 14px; height: 14px"
                />
                导出表格
              </el-button>
            </div>
          </el-col>
          <!-- 收起  文字按钮
          <el-col :span="2">
            <el-link
                    @click="show1"
                    style="margin-top: 8px; color: steelblue"
                    >收起<i
                      class="el-icon-arrow-up el-icon--right"
                      style="color: steelblue"
                    ></i>
                  </el-link>
          </el-col>
          -->
        </el-row>

      </el-form>
    </el-row>
    <!-- 1.ending -->
    <!-- 2.此div是数据表格 -->
    <div class="table-container" style="height: 81vh">
      <div class="list">
        报警点列表
        <!-- <el-link
          v-if="!divshow"
          @click="show1"
          style="margin-top: 8px; color: steelblue"
          >显示<i
            class="el-icon-arrow-up el-icon--right"
            style="color: steelblue"
          ></i>
        </el-link> -->
        <el-button type="primary" style="float: right;" @click="dialogFormVisible = true">+新增报警点</el-button>
      </div>
      <el-table
        :key="tableKey"
        v-loading="listLoading"
        header-row-style="height:58px"
        row-style="height:58px"
        class="DCS_tab"
        :data="list"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <!-- <el-table-column
          label="ID"
          prop="id"
          sortable="custom"
          align="center"
          type="index"
          width="100px"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.id }}</span>
          </template>
        </el-table-column> -->
        <!-- <el-table-column
          label="时间"
          prop="alarmTime"
          sortable="custom"
          align="left"
          width="210px"
          height="100px"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ scope.row.alarmTime }}</span>
          </template>
        </el-table-column> -->
        <el-table-column
          label="名称"
          prop="hostName"
          width="180px"
          align="center"
          sortable="custom"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ scope.row.hostName }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="区域"
          prop="hostName"
          width="180px"
          align="center"
          sortable="custom"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ scope.row.hostName }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="主机"
          prop="sensorid"
          width="180px"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span class="sco">{{ scope.row.sensorid }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="类型"
          prop="dcsAlarmTypeId"
          align="center"
          width="180px"
          sortable="custom"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ scope.row.dcsAlarmTypeName }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="状态"
          prop="sensorid"
          width="180px"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ scope.row.sensorid }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="主监控摄像机"
          prop="hostName"
          width="180px"
          align="center"
          sortable="custom"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ scope.row.hostName }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="短信通知模板"
          prop="dcsAlarmTypeId"
          align="center"
          width="180px"
          sortable="custom"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span>{{ scope.row.dcsAlarmTypeName }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="短信通知人员"
          prop="dcsAlarmState"
          align="center"
          width="180px"
          sortable="custom"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span v-if="scope.row.dcsAlarmState === 1" style="color: red">{{
              $t("select.untreated")
            }}</span>
            <span v-else>{{ $t("select.processed") }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="center"
          width="180px"
          class-name="small-padding fixed-width"
        >
          <!-- slot-scope="scope" -->
          <template>
            <!-- <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              style="color:steelblue"

            >编辑</el-button> -->
            <!-- @click="handleDownload(scope.row, scope.$index)" -->
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="dialogFormVisible2 = true"
            >编辑</el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
              @click="open"
            >删除</el-button>
            <!-- @click="dialog1(scope.row.hostName,scope.row.dcsAlarmState,scope.row.id)" -->
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="listQuery.page"
        :limit.sync="listQuery.size"
        @pagination="getList"
      />
    </div>
    <!-- 2.ending -->
    <!-- 编辑报警点 -->
    <el-dialog
      class="dialog-el"
      show-close:true
      title="编辑报警点"
      :visible.sync="dialogFormVisible2"
    >
      <el-form :model="form">
        <el-row :gutter="10">
          <el-col :span="9" :offset="1">
            <el-form-item label="名称" :label-width="formLabelWidth">
              <el-input
                v-model="alarmPointName"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="类型" :label-width="formLabelWidth">
              <el-select
                v-model="form.type"
                class="formItem"
                style="width:187px;"
                placeholder="请选择"
              >
                <el-option label="类型一" value="类型1" />
                <el-option label="类型二" value="类型2" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="9" :offset="1">
            <el-form-item label="主机" :label-width="formLabelWidth">
              <el-select
                v-model="form.host"
                class="formItem"
                style="width:192px;"
                placeholder="请选择"
              >
                <el-option label="主机一" value="host1" />
                <el-option label="主机二" value="host2" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="主监控摄像机" :label-width="formLabelWidth">
              <el-select
                v-model="form.monitorCamera"
                class="formItem"
                style="width:187px;"
                placeholder="请选择"
              >
                <el-option label="摄像机一" value="camera1" />
                <el-option label="摄像机二" value="camera2" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="9" :offset="1">
            <el-form-item label="报警编码" :label-width="formLabelWidth">
              <el-input
                v-model="alarmCode"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="短信通知模板" :label-width="formLabelWidth">
              <el-select
                v-model="form.shortLetter"
                class="formItem"
                style="width:187px;"
                placeholder="请选择"
              >
                <el-option label="通知模板一" value="letter1" />
                <el-option label="通知模板二" value="letter2" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="9" :offset="1">
            <el-form-item label="低报浓度" :label-width="formLabelWidth">
              <el-input
                v-model="lowPotency"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="高报浓度" :label-width="formLabelWidth">
              <el-input
                v-model="highPotency"
                style="width:187px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9" :offset="1">
            <el-form-item label="附近监控点" :label-width="formLabelWidth">
              <el-input
                v-model="monitoringPoint"
                type="textarea"
                :rows="4"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="短信通知人员" :label-width="formLabelWidth">
              <el-input
                v-model="messagePeople"
                type="textarea"
                :rows="4"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="3" :offset="4">
            <el-button type="primary">添加</el-button>
          </el-col>
          <el-col :span="3" :offset="1">
            <el-button type="danger" plain>删除</el-button>
          </el-col>
          <el-col :span="3" :offset="5">
            <el-button type="primary">添加</el-button>
          </el-col>
          <el-col :span="3" :offset="1">
            <el-button type="danger" plain>删除</el-button>
          </el-col>
        </el-row>
        <el-row :gutter="10" style="margin-top:17px">
          <el-col :span="9" :offset="1">
            <el-form-item label="区域" :label-width="formLabelWidth">
              <el-select
                v-model="form.region"
                class="formItem"
                style="width:192px;"
                placeholder="请选择"
              >
                <el-option label="区域一" value="shanghai" />
                <el-option label="区域二" value="beijing" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="具体安装位置" :label-width="formLabelWidth">
              <el-input
                v-model="installPosition"
                style="width:188px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="4" :offset="1">
            <span style="height:10px;line-height:36px">在区域中的坐标</span>
          </el-col>
          <el-col :span="3">
            <el-form-item label="X" :label-width="formLabelWidth2" style="margin-left:-2px">
              <el-input
                v-model="coordinateX"
                size="small"
                style="width:60px;"
              />
            </el-form-item>
          </el-col>
          <el-col :span="3">
            <el-form-item label="Y" :label-width="formLabelWidth2" style="margin-left:-14px">
              <el-input
                v-model="coordinateY"
                size="small"
                style="width:60px;"
              />
            </el-form-item>
          </el-col>

          <el-col :span="3" :offset="10" style="margin-left:170px">
            <el-button type="primary" @click="selectNum">选择坐标</el-button>
          </el-col>
        </el-row>
        <el-row>
          <img style="width:700px;height:150px" src="../../assets/404_images/404.png">
        </el-row>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button
          type="primary"
          @click="dialogFormVisible2 = false"
        >保 存</el-button>
        <el-button @click="dialogFormVisible2 = false">取 消</el-button>
      </div>
    </el-dialog>
    <!-- 3.弹出的对话框 -->
    <el-dialog
      class="dialog-el"
      show-close:true
      title="编辑报警点"
      :visible.sync="dialogFormVisible"
    >
      <el-form :model="form">
        <el-row :gutter="10">
          <el-col :span="9" :offset="1">
            <el-form-item label="名称" :label-width="formLabelWidth">
              <el-input
                v-model="alarmPointName"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="类型" :label-width="formLabelWidth">
              <el-select
                v-model="form.type"
                class="formItem"
                style="width:187px;"
                placeholder="请选择"
              >
                <el-option label="类型一" value="类型1" />
                <el-option label="类型二" value="类型2" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="9" :offset="1">
            <el-form-item label="主机" :label-width="formLabelWidth">
              <el-select
                v-model="form.host"
                class="formItem"
                style="width:192px;"
                placeholder="请选择"
              >
                <el-option label="主机一" value="host1" />
                <el-option label="主机二" value="host2" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="主监控摄像机" :label-width="formLabelWidth">
              <el-select
                v-model="form.monitorCamera"
                class="formItem"
                style="width:187px;"
                placeholder="请选择"
              >
                <el-option label="摄像机一" value="camera1" />
                <el-option label="摄像机二" value="camera2" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="9" :offset="1">
            <el-form-item label="报警编码" :label-width="formLabelWidth">
              <el-input
                v-model="alarmCode"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="短信通知模板" :label-width="formLabelWidth">
              <el-select
                v-model="form.shortLetter"
                class="formItem"
                style="width:187px;"
                placeholder="请选择"
              >
                <el-option label="通知模板一" value="letter1" />
                <el-option label="通知模板二" value="letter2" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col :span="9" :offset="1">
            <el-form-item label="低报浓度" :label-width="formLabelWidth">
              <el-input
                v-model="lowPotency"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="高报浓度" :label-width="formLabelWidth">
              <el-input
                v-model="highPotency"
                style="width:187px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="9" :offset="1">
            <el-form-item label="附近监控点" :label-width="formLabelWidth">
              <el-input
                v-model="monitoringPoint"
                type="textarea"
                :rows="4"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="短信通知人员" :label-width="formLabelWidth">
              <el-input
                v-model="messagePeople"
                type="textarea"
                :rows="4"
                style="width:192px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="3" :offset="4">
            <el-button type="primary">添加</el-button>
          </el-col>
          <el-col :span="3" :offset="1">
            <el-button type="danger" plain>删除</el-button>
          </el-col>
          <el-col :span="3" :offset="5">
            <el-button type="primary">添加</el-button>
          </el-col>
          <el-col :span="3" :offset="1">
            <el-button type="danger" plain>删除</el-button>
          </el-col>
        </el-row>
        <el-row :gutter="10" style="margin-top:17px">
          <el-col :span="9" :offset="1">
            <el-form-item label="区域" :label-width="formLabelWidth">
              <el-select
                v-model="form.region"
                class="formItem"
                style="width:192px;"
                placeholder="请选择"
              >
                <el-option label="区域一" value="shanghai" />
                <el-option label="区域二" value="beijing" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="11" :offset="3">
            <el-form-item label="具体安装位置" :label-width="formLabelWidth">
              <el-input
                v-model="installPosition"
                style="width:188px;"
                placeholder="请输入"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="4" :offset="1">
            <span style="height:10px;line-height:36px">在区域中的坐标</span>
          </el-col>
          <el-col :span="3">
            <el-form-item label="X" :label-width="formLabelWidth2" style="margin-left:-2px">
              <el-input
                v-model="coordinateX"
                size="small"
                style="width:60px;"
              />
            </el-form-item>
          </el-col>
          <el-col :span="3">
            <el-form-item label="Y" :label-width="formLabelWidth2" style="margin-left:-14px">
              <el-input
                v-model="coordinateY"
                size="small"
                style="width:60px;"
              />
            </el-form-item>
          </el-col>

          <el-col :span="3" :offset="10" style="margin-left:170px">
            <el-button type="primary" @click="selectNum">选择坐标</el-button>
          </el-col>
        </el-row>
        <el-row>
          <img style="width:700px;height:150px" src="../../assets/404_images/404.png">
        </el-row>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button
          type="primary"
          @click="dialogFormVisible = false"
        >保 存</el-button>
        <el-button @click="dialogFormVisible = false">取 消</el-button>
      </div>
    </el-dialog>
    <!-- 选择坐标 -->
    <el-dialog
      class="dialog-select"
      show-close:true
      title="选择坐标"
      :visible.sync="selectPoint"
    >
      <el-form :model="form">
        <el-row>
          <el-col :span="4" :offset="1">
            <span style="height:10px;line-height:36px">区域坐标</span>
          </el-col>
          <el-col :span="3">
            <el-form-item label="X" :label-width="formLabelWidth2" style="margin-left:-2px">
              <el-input
                v-model="coordinateX"
                size="small"
                style="width:60px;"
              />
            </el-form-item>
          </el-col>
          <el-col :span="3">
            <el-form-item label="Y" :label-width="formLabelWidth2" style="margin-left:-14px">
              <el-input
                v-model="coordinateY"
                size="small"
                style="width:60px;"
              />
            </el-form-item>
          </el-col>
          <div>
            <el-col :span="3" :offset="1">
              <el-button
                type="primary"
                @click="selectPoint = false"
              >确 定</el-button>
            </el-col>
            <el-col :span="3" :offset="1">
              <el-button @click="selectPoint = false">取 消</el-button>
            </el-col>
          </div>
        </el-row>
        <el-row>
          <!-- 查看图片放大组件 -->
          <div>
            <!-- 图片展示区 -->
            <div class="look-image-content" style="width:700px;height:200px;">
              <div
                class="show-image"
                style="overflow: auto;"
                :style="imgstyle"
                @mousedown="mousedown"
                @mousemove="mousemove"
                @mouseup="mouseup"
                @Mouseleave="Mouseleave"
              >
                <img ref="img" style="width:700px;height:200px;position: relative; " :src="imgSrc" :style="styleObj" @mousedown="start" @mouseup="stop" @mousemove="move">
                <canvas id="mycanvas" ref="table" style="width:700px;height:200px;position: absolute;left:0px; top: 0px; " :style="canvasstyle" />
                <!-- :width="canvasWidth" :height="canvasHeight" -->
              </div>
            </div>
            <div style="width:665px;z-index:inherit;text-align:right;margin:10px 0 0 0">
              <span slot="footer" class="dialog-footer">
                <el-button @click="customClose">取消</el-button>
                <el-button type="primary" @click="customQuery">确定</el-button>
              </span>
            </div>
            <!-- 底部按钮操作区 -->
            <div class="look-image-footer">
              <el-row :gutter="20">
                <el-col :span="6">
                  <div class="enlargement" @click="magnify">
                    <i class="" />
                    <el-button type="primary">放大</el-button>
                  </div>
                </el-col>
                <el-col :span="6">
                  <div class="shrink" @click="shrink">
                    <i class="" />
                    <el-button type="primary">缩小</el-button>
                  </div>
                </el-col>
                <el-col :span="6">
                  <div class="rotate" @click="rotate">
                    <i class="" />
                    <el-button type="primary">旋转</el-button>
                  </div>
                </el-col>
                <el-col :span="6">
                  <div class="close">
                    <i class="" />
                    <el-button type="primary" @click="selectPoint = false">关闭</el-button>
                  </div>
                </el-col>
              </el-row>
              <!-- <div class="enlargement" @click="magnify">
                <i class=""></i>
                <el-button type="primary">放大</el-button>
              </div>
              <div class="shrink" @click="shrink">
                <i class=""></i>
                <el-button type="primary">缩小</el-button>
              </div>
              <div class="rotate" @click="rotate">
                <i class=""></i>
                <el-button type="primary">旋转</el-button>
              </div>
              <div class="close">
                <i class=""></i>
                <el-button type="primary" @click="selectPoint = false">关闭</el-button>
              </div> -->
            </div>
          </div>
        </el-row>
      </el-form>
    </el-dialog>

    <!-- <el-dialog title="添加短信通知人员" :visible.sync="dialogFormPeopleVisible" center class="dialog-peo">
      <el-form :model="form">
        <el-row>
          <el-form-item label="已选择人员" :label-width="formLabelWidth">
            <el-input
              style="width:400px;"
              v-model="input"
              placeholder="请输入"
            ></el-input>
          </el-form-item>
        </el-row>
        <el-row>
          <el-col span="10">
            <el-form-item label="人员名称" :label-width="formLabelWidth">
              <el-input
                style="width:160px;"
                v-model="input"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
          <el-col span="13" :offset="1">
            <el-form-item label="部门名称" :label-width="formLabelWidth">
              <el-input
                style="width:160px;"
                v-model="input"
                placeholder="请输入"
              ></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-form-item label="职位名称" :label-width="formLabelWidth">
            <el-input
              style="width:180px;"
              v-model="input"
              placeholder="请输入"
            ></el-input>
          </el-form-item>
        </el-row>
        <el-row></el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
      </div>
    </el-dialog> -->
    <!-- 3.ending -->
  </div>
</template>
<script>
import vue from 'vue'
import {
  selectDcsAlarmRecord,
  dcsAlarmRecordExport,
  selectDcsAlarmType
  // dcsAlarmRecordDown
} from '@/api/DCSAlarmQuery'
// import { selectVideoAlarmType } from '@/api/alarmQuery'
import { selectPlant } from '@/api/plant'
import Pagination from '@/components/Pagination' // secondary package based on el-pagination
export default {
  // name: "AlarmQuery",
  name: 'LookImage',
  components: { Pagination },
  filters: {},
  props: ['imgSrc'],
  props: {
    url: { // 图片链接
      type: String,
      default: ''
    },
    visible: { // 控制组件的显示与隐藏
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      imgSrc: require('../../assets/404_images/404.png'),
      startX2: '', // 画画开始的X坐标
      startY2: '', // 画画开始的Y坐标
      endX2: '', // 画画结束的X坐标
      endY2: '', // 画画结束的Y坐标
      isMouseDownInCanvas: '', // 鼠标是否按下
      customcxt: '', // cxt
      customRwidth: '', // 原图与展示图片的宽度比
      customRheight: '', // 原图与展示图片的高度比
      imgstyle: '', // 根据图片大小自适应样式
      canvasstyle: '', // 根据图片大小canvas自适应样式 居中显示
      canvasWidth: '', // 根据图片大小自适应canvas宽
      canvasHeight: '', // 根据图片大小自适应canvas高
      DivWidth: 560, // 最大宽度
      DivHeight: 680, // 最大高度
      multiples: 1, // 放大或者缩小
      deg: 0, // 旋转的角度
      styleObj: null, // 拖拽时修改图片的样式
      isDrag: false, // 是否开始拖拽
      startX: 0, // 鼠标的点击x轴
      startY: 0, // 鼠标的点击y轴
      moveX: 0, // 鼠标移动的x轴
      moveY: 0, // 鼠标移动的y轴
      endX: 0,
      endY: 0,
      select: {
        host: '',
        alarmType: '',
        alarmStatu: ''
      },
      alarmName: '',
      alarmPointName: '',
      monitoringPoint: '',
      messagePeople: '',
      highPotency: '',
      lowPotency: '',
      alarmCode: '',
      installPosition: '',
      cameraName: '',
      IP: '',
      ChannelNumber: '',
      loginName: '',
      password: '',
      coordinateX: '',
      coordinateY: '',
      input: '',
      dialogFormPeopleVisible: false,
      centerDialogVisible: false,
      selectPoint: false,
      // 显示div
      divshow: true,
      //   区域的下拉框测试数据
      options: [
        {
          value: '选项1',
          label: '工厂1'
        },
        {
          value: '选项2',
          label: '工厂2'
        },
        {
          value: '选项3',
          label: '工厂3'
        }
      ],
      hosts: [
        {
          value: '选项1',
          label: '主机1'
        },
        {
          value: '选项2',
          label: '主机2'
        },
        {
          value: '选项3',
          label: '主机3'
        }
      ],
      alarmTypes: [
        {
          value: '选项1',
          label: '类型1'
        },
        {
          value: '选项2',
          label: '类型2'
        },
        {
          value: '选项3',
          label: '类型3'
        }
      ],
      alarmStatus: [
        {
          value: '选项1',
          label: '状态1'
        },
        {
          value: '选项2',
          label: '状态2'
        },
        {
          value: '选项3',
          label: '状态3'
        }
      ],
      //   区域的下拉框测试数据
      value: '',
      tableKey: 0,
      list: null,
      total: 0,
      listLoading: true,
      listQuery: {
        page: 1,
        size: 10,
        option: '',
        hostName: '',
        dcsAlarmTypeId: '',
        dcsAlarmState: '',
        alarmLever: '',
        startTime: '',
        endTime: '',
        sortRule: 2,
        sortField: 'alarmTime'
      },
      imageSrc: '',
      imgIndex: '',
      imgZoom: 1,
      dialogFormVisible: false,
      dialogFormVisible2: false,
      showReviewer: false,
      isbuttonmove: false,
      isbuttonmoves: false,
      alarmAreaOptions: [],
      alarmTypeOptions: [],
      downloadLoading: false,
      dialogFormVisible: false,
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: '',
        host: '',
        monitorCamera: '',
        shortLetter: ''
      },
      formLabelWidth: '100px',
      formLabelWidth2: '20px'
    }
  },
  watch: {
    'imgSrc': function() {
      this.show()
    }
  },
  mounted() {
    this.show()
  },
  created() {
    this.getList()
    this.getAlarmType()
  },
  methods: {
    selectNum() {
      debugger
      this.selectPoint = true
      this.show()
    },
    // 取消时返回组件调用处所需的数据
    customClose() {
      this.customcxt.clearRect(0, 0, this.DivWidth, this.DivHeight)
      this.$emit('custom', { 'type': 1, 'data': '' })
    },
    // 确定时返回组件调用处所需的数据
    customQuery() {
      this.customcxt.clearRect(0, 0, this.DivWidth, this.DivHeight)
      // 根据绘制进行图片裁剪

      // 获取矩形框Left,Width'
      let cLeft = 0
      let cWidth = 0
      if (this.startX2 > this.endX2) {
        cLeft = this.endX2
        cWidth = this.startX2 - this.endX2
      } else {
        cLeft = this.startX2
        cWidth = this.endX2 - this.startX2
      }
      // 获取矩形框Top,Height
      let cTop = 0
      let cHeight = 0
      if (this.startY2 > this.endY2) {
        cTop = this.endY2
        cHeight = this.startY2 - this.endY2
      } else {
        cTop = this.startY2
        cHeight = this.endY2 - this.startY2
      }
      var oMark = []
      oMark['offsetLeft'] = parseInt(cLeft / this.customRwidth)
      oMark['offsetTop'] = parseInt(cTop / this.customRheight)
      oMark['offsetWidth'] = parseInt(cWidth / this.customRwidth)
      oMark['offsetHeight'] = parseInt(cHeight / this.customRheight)
      this.$emit('custom', { 'type': 2, 'data': oMark })
    },

    // dialog展示自定义矩形框画板
    // 计算img与canvas标签自适应图片的大小
    show() {
      debugger
      vue.nextTick(_ => {
        debugger
        var canvas = document.getElementById('mycanvas')
        var context = canvas.getContext('2d')
        // let customCanvas = this.$refs.table;// canvas显示层
        this.customcxt = canvas.getContext('2d')

        const img = new Image()
        img.src = this.imgSrc
        const that = this
        img.onload = function() {
          let canvasleft = 0
          let canvastop = 0
          const WrH = img.width / img.height // 图片宽高比
          const RWrH = that.DivWidth / that.DivHeight // 放置图片DIV的宽高比
          let aa = 0
          // 根据宽高比大小判断确定自适应的宽和高
          if (RWrH > WrH) {
            aa = that.DivHeight / img.height
            that.canvasHeight = that.DivHeight
            that.canvasWidth = img.width * aa
            canvasleft = (that.DivWidth - that.canvasWidth) / 2
          } else {
            aa = that.DivWidth / img.width
            that.canvasHeight = img.height * aa
            that.canvasWidth = that.DivWidth
            canvastop = (that.DivHeight - that.canvasHeight) / 2
          }
          that.imgstyle = ' position: relative;  width:' + that.canvasWidth +
                        ' px; height:' + that.canvasHeight + 'px' // img浮动定位居中显示
          that.customRwidth = that.canvasWidth / img.width // 原图与展示图片的宽高比
          that.customRheight = that.canvasHeight / img.height
          // that.canvasstyle = 'position: absolute;left: ' + canvasleft
          //                 + '; top: ' + canvastop + ';' //canvas浮动定位
        }
      })
    },
    // 鼠标按下时执行
    mousedown(e) {
      this.isMouseDownInCanvas = true
      // 鼠标按下时开始位置与结束位置相同
      // 防止鼠标在画完矩形后 点击图画形成第二个图形
      this.endX2 = e.offsetX * 3 / 7
      this.endY2 = e.offsetY * 3 / 4
      this.startX2 = e.offsetX * 3 / 7
      this.startY2 = e.offsetY * 3 / 4
      this.mousemove(e)
    },
    // 鼠标移动式时执行
    mousemove(e) {
      if (this.isMouseDownInCanvas) { // 当鼠标有按下操作时执行
        this.endX2 = e.offsetX * 3 / 7
        this.endY2 = e.offsetY * 3 / 4
        const wwidth = this.endX2 - this.startX2
        const wheigth = this.endY2 - this.startY2
        // 清除指定区域的所有像素
        this.customcxt.clearRect(0, 0, this.DivWidth, this.DivHeight)
        this.customcxt.strokeStyle = '#00ff00' // 矩形框颜色
        this.customcxt.lineWidth = '2' // 矩形框宽度
        console.log(this.startX2 + ', ' + this.startY2 + ', ' + wwidth + ', ' + wheigth)

        this.customcxt.strokeRect(this.startX2, this.startY2, wwidth, wheigth) // 绘制矩形
      }
    },
    // 鼠标松开时执行
    mouseup(e) {
      this.isMouseDownInCanvas = false
    },
    Mouseleave(e) {
      this.isMouseDownInCanvas = false
    },
    // 图片放大缩小旋转拖拽方法
    // 放大
    magnify() {
      if (this.multiples >= 10) {
        return
      }
      this.multiples += 0.25
      this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);margin-left:${(700 * this.multiples - 700) / 2}px;margin-top:${200 * (this.multiples - 1) / 2}px`
      this.canvasstyle = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);margin-left:${(700 * this.multiples - 700) / 2}px;margin-top:${200 * (this.multiples - 1) / 2}px`
      // if(this.multiples > 1){
      //   this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);margin-left:${(700 * this.multiples - 700) / 2}px;margin-top:${200 * (this.multiples - 1) / 2}px`;
      // } else {
      //   this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);`;
      // }
    },
    // 缩小
    shrink() {
      if (this.multiples <= 0) {
        return
      }
      this.multiples -= 0.25
      // this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);left:${this.endX}px;top:${this.endY}px`;
      this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);margin-left:${(700 * this.multiples - 700) / 2}px;margin-top:${200 * (this.multiples - 1) / 2}px`
      // this.canvasstyle = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);left:${this.endX}px;top:${this.endY}px`;
      this.canvasstyle = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);margin-left:${(700 * this.multiples - 700) / 2}px;margin-top:${200 * (this.multiples - 1) / 2}px`
    },
    // 旋转
    rotate() {
      this.deg += 90
      if (this.deg >= 360) {
        this.deg = 0
      }
      this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);left:${this.endX}px;top:${this.endY}px`
    },
    start(e) {
      // 当点击图片时，开始拖拽
      if (e.buttons) {
        this.isDrag = true
        this.startX = e.clientX
        this.startY = e.clientY
        this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);left:${this.endX}px;top:${this.endY}px`
      }
    },
    stop() {
      this.isDrag = false
      this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);left:${this.endX}px;top:${this.endY}px`
    },
    move(e) {
      // 当鼠标拖拽图片的时候，才计算移动距离
      // 移动图片相对于父元素的位置
      if (this.isDrag) {
        // 鼠标移动的距离
        this.moveX = e.clientX
        this.moveY = e.clientY
        // 相对页面的距离
        const x = this.moveX - this.startX
        const y = this.moveY - this.startY
        const img = document.querySelector('#look-image img')
        this.endX = img.offsetLeft + x
        this.endY = img.offsetLeft + y
        this.styleObj = `left:${this.endX}px;top:${this.endY}px`
        this.styleObj = `transform: scale(${this.multiples}) rotateZ(${this.deg}deg);left:${this.endX}px;top:${this.endY}px`
        // 记录上次移动的距离
        this.startX = this.moveX
        this.startY = this.moveY
      }
    },
    close() {
      this.$emit('closeImage', false)
    },
    open() {
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.$message({
          type: 'success',
          message: '删除成功!'
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    select1() {
      console.log('ddd-', this.listQuery.option)
    },
    select2() {
      console.log('ccc', this.listQuery.option)
    },
    show1() {
      this.divshow = !this.divshow
    },
    dialog1(val, val1, id) {
      this.form.name = val
      this.form.region = val1
      this.form.date1 = id
      this.dialogFormVisible = true
    },
    mouseOver() {
      this.isbuttonmove = true
    },
    mouseLeave() {
      this.isbuttonmove = false
    },
    mouseOvers() {
      this.isbuttonmoves = true
    },
    mouseLeaves() {
      this.isbuttonmoves = false
    },
    getList() {
      const param = this.listQuery
      this.listLoading = true
      selectDcsAlarmRecord({
        page: param.page - 1,
        size: param.size,
        hostName: param.hostName,
        dcsAlarmTypeId: param.dcsAlarmTypeId,
        dcsAlarmState: param.dcsAlarmState,
        alarmLever: param.alarmLever,
        startTime: param.startTime,
        endTime: param.endTime,
        sortRule: param.sortRule,
        sortField: param.sortField
      }).then((res) => {
        if (res.data.result === 'success') {
          this.list = res.data.data.list
          this.total = res.data.data.totalNum
          this.listLoading = false
        } else {
          this.listLoading = false
        }
      })
    },
    getAlarmType() {
      selectDcsAlarmType().then((res) => {
        if (res.data.result === 'success') {
          this.alarmTypeOptions = res.data.data.dcsAlarmTypeList
        }
      })
    },
    getAlarmArea() {
      selectPlant({
        page: 0,
        size: 9999
      }).then((res) => {
        if (res.data.result === 'success') {
          const plantList = res.data.data.plantList
          plantList.forEach((item) => {
            this.alarmAreaOptions.push({
              value: item.id,
              label: item.plantName
            })
          })
        }
      })
    },
    handleFilter() {
      this.list = []
      this.total = 0
      this.listQuery.page = 1
      this.getList()
    },
    sortChange(data) {
      if (data.order === 'ascending') {
        this.listQuery.sortRule = 1
      } else {
        this.listQuery.sortRule = 2
      }
      this.listQuery.sortField = data.prop
      this.getList()
    },
    plantSelect(val) {
      this.listQuery.plantId = val
    },
    cameraSelect(val) {
      this.listQuery.cameraId = val
    },
    alarmTypeSelect(val) {
      this.listQuery.videoAlarmTypeId = val
    },
    alarmStateSelect(val) {
      this.listQuery.videoAlarmState = val
    },
    prioritySelect(val) {
      this.listQuery.priority = val
    },
    previewImg(index, row) {
      this.dialogFormVisible = true
      this.renderingImg(index, row.dcsAlarmImage)
    },
    renderingImg(index, src) {
      this.imgIndex = index
      this.imageSrc = src
    },
    beforeClose() {
      this.dialogFormVisible = false
      this.imageSrc = ''
      this.imgZoom = 1
      document.getElementsByClassName(
        'dcsAlarmImg'
      )[0].style.zoom = this.imgZoom
    },
    lastImg() {
      const index = this.imgIndex - 1
      if (index > -1) {
        const src = this.list[index].dcsAlarmImage
        this.renderingImg(index, src)
      }
    },
    nextImg() {
      const index = this.imgIndex + 1
      if (index < 9) {
        const src = this.list[index].dcsAlarmImage
        this.renderingImg(index, src)
      }
    },
    changeSize(val) {
      this.imgZoom = this.imgZoom + val
      document.getElementsByClassName(
        'dcsAlarmImg'
      )[0].style.zoom = this.imgZoom
    },
    toPercent(val) {
      if (this.lodash.isString(val) && val.indexOf('%') > -1) {
        return val
      } else if (this.lodash.isNumber(val)) {
        //
      } else if (!this.lodash.isString(val)) {
        return ''
      }
      let temp = parseInt(val.toFixed(1) * 100)
      temp = temp + '%'
      return temp
    },
    // handleDownload(row, index) {
    //   var url = 'api1/dcsAlarmRecord/dcsAlarmRecordDown?id=' + row.id
    //   const xhr = new XMLHttpRequest()
    //   const fileName = 'DCSAlarmRecord' + row.id + '.zip' // 文件名称
    //   xhr.open('GET', url, true)
    //   xhr.responseType = 'arraybuffer'
    //   // xhr.responseType = 'blob'
    //   // xhr.setRequestHeader(token, 'xxxxx') // 请求头中的验证信息等（如果有）
    //   xhr.onload = function() {
    //     if (this.status === 200) {
    //       const type = xhr.getResponseHeader('Content-Type')

    //       const blob = new Blob([this.response], { type: type })
    //       if (typeof window.navigator.msSaveBlob !== 'undefined') {
    //         /*
    //          * IE workaround for "HTML7007: One or more blob URLs were revoked by closing
    //          * the blob for which they were created. These URLs will no longer resolve as
    //          * the data backing the URL has been freed."
    //          */
    //         window.navigator.msSaveBlob(blob, fileName)
    //       } else {
    //         const URL = window.URL || window.webkitURL
    //         const objectUrl = URL.createObjectURL(blob)
    //         if (fileName) {
    //           var a = document.createElement('a')
    //           // safari doesn't support this yet
    //           if (typeof a.download === 'undefined') {
    //             window.location = objectUrl
    //           } else {
    //             a.href = objectUrl
    //             a.download = fileName
    //             document.body.appendChild(a)
    //             a.click()
    //             a.remove()
    //           }
    //         } else {
    //           window.location = objectUrl
    //         }
    //       }
    //     }
    //   }
    //   xhr.send()
    // },
    handleDelete(row) {
      this.$notify({
        title: '成功',
        message: '删除成功',
        type: 'success',
        duration: 2000
      })
      const index = this.list.indexOf(row)
      this.list.splice(index, 1)
    },
    handleExport() {
      const param = this.listQuery
      dcsAlarmRecordExport({
        hostName: param.hostName,
        dcsAlarmTypeId: param.dcsAlarmTypeId,
        dcsAlarmState: param.dcsAlarmState,
        alarmLever: param.alarmLever,
        startTime: param.startTime,
        endTime: param.endTime,
        sortRule: param.sortRule,
        sortField: param.sortField
      }).then((res) => {
        this.downLoadXls(res.data, 'dcsAlarm.xls')
      })
      // var url = '/dcsAlarmRecord/dcsAlarmRecordExport'
      // var xhr = new XMLHttpRequest()
      // xhr.open('post', url, true) // 也可以使用POST方式，根据接口
      // xhr.responseType = 'blob' // 返回类型blob
      // // 定义请求完成的处理函数，请求前也可以增加加载框/禁用下载按钮逻辑
      // xhr.onload = function () {
      //   // 请求完成
      //   if (this.status === 200) {
      //     // 返回200
      //     var blob = this.response
      //     console.log(blob)
      //     var reader = new FileReader()
      //     reader.readAsDataURL(blob) // 转换为base64，可以直接放入a表情href
      //     console.log(reader)
      //     reader.onload = function (e) {
      //       // 转换完成，创建一个a标签用于下载
      //       console.log(e)
      //       var a = document.createElement('a')
      //       a.download = 'dcsAlarm.xls'
      //       a.href = e.target.result
      //       // $('body').append(a) // 修复firefox中无法触发click
      //       a.click()
      //       // $(a).remove()
      //     }
      //   }
      // }
      // // 发送ajax请求
      // xhr.send()
    }
    // downLoadXls(data, filename) {
    //   // var blob = new Blob([data], {type: 'application/vnd.ms-excel'})接收的是blob，若接收的是文件流，需要转化一下
    //   if (typeof window.chrome !== 'undefined') {
    //     // Chrome version
    //     var link = document.createElement('a')
    //     link.href = window.URL.createObjectURL(data)
    //     link.download = filename
    //     link.click()
    //   } else if (typeof window.navigator.msSaveBlob !== 'undefined') {
    //     // IE version
    //     var blob = new Blob([data], { type: 'application/force-download' })
    //     window.navigator.msSaveBlob(blob, filename)
    //   } else {
    //     // Firefox version
    //     var file = new File([data], filename, {
    //       type: 'application/force-download'
    //     })
    //     window.open(URL.createObjectURL(file))
    //   }
    // }
  }
}
</script>
<style lang="scss" scoped>
  #look-image{
    position:fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    width: 258px;
    height: 168px;
    background-color: #fefefe;
    border-radius: 10px;
    border: 1px solid #c5c5c5;
    overflow: hidden;
    z-index: 99;
    .look-image-content {
      width: 50px;
      // width: 1460px;
      // height: 740px;
      border-bottom: 1px solid #c5c5c5;
      background-color: #c0c0c0;
      margin:0 auto ;
      display:-webkit-box;
      -webkit-box-align:center;
      -webkit-box-pack:center;
      .show-image {
        margin: 44px 148px 74px;
        height: 200px;
        width: 700px;
        position: relative;
        // overflow: auto;
        img {
          width: 100%;
          height: 100%;
          position: absolute;
          top: 0;
          left: 0;
        }
      }
    }
    .look-image-footer {
      display: flex;
      height: 40px;
      line-height: 40px;
      >div {
        width: 25%;
        position: relative;
        &::after {
          content: "";
          position: absolute;
          top: 0;
          right: 0;
          width: 1px;
          height: 50%;
          background-color: #c5c5c5;
        }
        &:last-child {
          &::after {
            display: none;
          }
        }
      }
    }
  }
  .imgicon {
    text-align: center;
    margin: 260px auto;
    font-size: 30px;
    cursor: pointer;
  }
  .el-form-item--mini.el-form-item {
    margin-bottom: 0;
  }
  .DCS_tab {
    margin-left: 1%;
    width: 98%;
    line-height: 22px;
    /* height: 550px; */
    .sco{
      color:#1890FF;
      font-family: SFProText-Regular;
      font-size: 14px;
    }
    .btncor{
      color: #096DD9;
    }
  }
  .table-lg {
    margin-left: 2%;
    margin-top: 2%;
  }
  .list {
    margin-top: 0.4%;
    margin-left: 1%;
    margin-bottom: 2%;
    margin-right: 1.5%;
    opacity: 0.85;
    font-family: PingFangSC-Medium;
    font-size: 16px;
    color:#000000;
    line-height: 24px;
  }
  .dialog-el {
    width: 85%;
    top: 8%;
    left: 8%;
  }
  .dialog-select{
    width: 85%;
    top: 20%;
    left: 8%;
  }
  .dialog-peo {
    width: 60%;
    top: 30%;
    left: 21%;
  }
  .formItem {
    width: 97%;
  }
  .selectEl {
    width: 100%;
  }
  .selectPeople {
    width: 36%;
  }
  /deep/ .el-icon-close:before {
    color:#001529 !important;
  }
</style>
