export const alarmColumns = [
  // table表格数据
  {
    label: "时间",
    value: "alarmTime",
    width: "200px"
  },
  {
    label: "报警点名称",
    value: "hostName",
    width: "200px"
  },
  {
    label: "区域",
    value: "sensorid",
    width: "160px"
  },
  {
    label: "报警类型",
    value: "dcsAlarmTypeId",
    width: "160px"
  },
  {
    label: "报警记录状态",
    value: "dcsAlarmState",
    width: "160px"
  },
  {
    label: "原因",
    value: "dcsAlarmDesc"
  },
  {
    label: "处理方式",
    value: "alarmLever",
    width: "200px"
  }
];
