<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <!-- 1.1以表单的形式展示输入框 -->
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-row :gutter="30">
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item label="开始时间:">
                <el-date-picker
                  v-model="formCondition.startTime"
                  type="date"
                  class="start-time-end"
                  placeholder="选择日期"
                  size="large"
                />
              </el-form-item>
              <el-form-item
                label="区 域:"
                size="large"
              >
                <el-select
                  v-model="formCondition.region"
                  clearable
                  placeholder="请选择"
                  class="form-item-region"
                >
                  <el-option
                    v-for="item in options"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item
                label="结束时间:"
                size="large"
              >
                <el-date-picker
                  v-model="formCondition.endTime"
                  type="date"
                  class="start-time-end"
                  placeholder="选择日期"
                />
              </el-form-item>
              <el-form-item
                label="报警类型:"
                size="large"
              >
                <el-select
                  v-model="formCondition.alarm"
                  clearable
                  placeholder="请选择"
                  class="input-form"
                >
                  <el-option
                    v-for="ala in options"
                    :key="ala.value"
                    :label="ala.label"
                    :value="ala.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :md="{ span: 8 }"
              :xs="{ span: 8 }"
            >
              <el-form-item
                label="报警点名称："
                size="large"
              >
                <el-input
                  v-model="formCondition.alarmName"
                  placeholder="请选择"
                  class="input-form"
                />
              </el-form-item>
              <el-form-item
                label="报警记录状态:"
                size="large"
              >
                <el-select
                  v-model="formCondition.alarmStatu"
                  clearable
                  placeholder="请选择"
                  class="input-form"
                >
                  <el-option
                    v-for="sta in options"
                    :key="sta.value"
                    :label="sta.label"
                    :value="sta.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col
              :span="6"
              :offset="18"
            >
              <el-button
                type="primary"
                size="mini"
                @click="handleFilter"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>

              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
                @click="handleExport"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-col>
          </el-row>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <!-- 2.此div是数据表格 -->
    <div class="table-container">
      <h3>报警记录列表</h3>
      <el-table
        v-loading="listLoading"
        :data="list"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(col, index) in dataColumns"
          :key="index"
          :label="col.label"
          :width="col.width"
          height="100px"
          sortable="custom"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="col.value == 'alarmTime'"
              class="font-color-blue"
            >
              {{
                scope.row[col.value]
              }}</span>
            <span v-if="col.value != 'alarmTime'">{{
              scope.row[col.value]
            }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="left"
          width="100px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              class="font-color-blue"
              type="text"
              icon="el-icon-edit"
              size="mini"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="pageable.page"
        :limit.sync="pageable.size"
        @pagination="getList"
      />
    </div>
    <!-- 2.ending -->
    <editDrawer
      ref="editDrawer"
      :visible="drawerVisible"
      :form-data="formData"
    />
  </div>
</template>
<script>
import { selectDcsAlarmRecord, selectDcsAlarmType } from "@/api/DCSAlarmQuery";
import Pagination from "@/components/Pagination";
import EditDrawer from "./EditDrawer";
import { alarmColumns } from "./tableList";
export default {
  name: "AlarmQuery",
  components: { Pagination, EditDrawer }, // Drawer
  data() {
    return {
      drawerVisible: false,
      activeName: "form",
      dataColumns: alarmColumns,
      pageable: {
        page: 1,
        size: 10,
      },
      formCondition: {
        // 查询列表
        hostName: "", // 报警点名称
        dcsAlarmTypeId: "", // 报警类型
        dcsAlarmState: "", // 报警记录状态
        alarmLever: "", // 处理方式
        startTime: "", // 开始时间
        endTime: "", // 结束时间
        sortRule: 2,
        sortField: "alarmTime",
        region: "", // 区域的下拉框绑定数据
        alarm: "", // 报警类型下拉框绑定数据
        alarmName: "", // 报警点名称绑定值
        alarmStatu: "", // 报警记录状态下拉框绑定数据
      },
      options: [],
      tableKey: 0, // table列表:key值
      list: null, // 报警记录列表:data值
      total: 0, // 分页总数
      listLoading: true, // 列表加载
      alarmTypeOptions: [],
      downloadLoading: false, // 导出表格加载按钮
      formData: {},
    };
  },
  mounted() {
    this.getList();
    this.getAlarmType();
    this.getQueryOptions();
  },
  methods: {
    // 下拉框获取数据
    getQueryOptions() {
      this.options.push(
        {
          value: "选项1",
          label: "区域1",
        },
        {
          value: "选项2",
          label: "区域2",
        },
        {
          value: "选项3",
          label: "区域3",
        }
      );
    },
    edit(rowData) {
      this.$refs.editDrawer.form = rowData;
      this.$refs.editDrawer.visible = true;
    },
    getList() {
      const param = this.formCondition;
      this.listLoading = true;
      selectDcsAlarmRecord({
        page: param.page - 1,
        size: param.size,
        hostName: param.hostName,
        dcsAlarmTypeId: param.dcsAlarmTypeId,
        dcsAlarmState: param.dcsAlarmState,
        alarmLever: param.alarmLever,
        startTime: param.startTime,
        endTime: param.endTime,
        sortRule: param.sortRule,
        sortField: param.sortField,
      }).then((res) => {
        if (res.data.result === "success") {
          // 可以写假数据在这里{}形式
          this.list = res.data.data.list;
          this.total = res.data.data.totalNum;
          this.listLoading = false;
        } else {
          this.listLoading = false;
        }
      });
    },
    getAlarmType() {
      selectDcsAlarmType().then((res) => {
        if (res.data.result === "success") {
          this.alarmTypeOptions = res.data.data.dcsAlarmTypeList;
        }
      });
    },
    handleFilter() {
      this.list = [];
      this.total = 0;
      this.pageable.page = 1;
      this.getList();
    },
    sortChange(data) {
      if (data.order === "ascending") {
        this.formCondition.sortRule = 1;
      } else {
        this.formCondition.sortRule = 2;
      }
      this.formCondition.sortField = data.prop;
      this.getList();
    },
    handleExport() {}, // 导出表格的方法
  },
};
</script>
<style lang="scss" scoped>
.form-item-region {
  left: 8%;
  width: 300px;
  height: 40px;
}
.query-button {
  margin-left: 15%;
}
.start-time-end {
  width: 300px;
}
</style>
