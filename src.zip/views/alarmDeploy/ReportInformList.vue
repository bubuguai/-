<template>
  <div class="app-container">
    <div class="table-container">
      <div>
        <el-col :span="20">
          <h3>报警记录填写人员列表</h3>
        </el-col>
        <el-col :span="2">
          <el-button
            type="primary"
            @click="edit()"
          >
            修改报警记录填写人员
          </el-button>
        </el-col>
      </div>
      <el-table
        v-loading="listLoading"
        :data="informList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(item, index) in dataColumns"
          :key="index"
          :label="item.label"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="item.value == 'name'"
              class="font-color-blue"
            >{{ scope.row[item.value] }}</span>
            <span v-if="item.value != 'name'">{{ scope.row[item.value] }}</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import { informColumns } from './tableList'
export default {
  name: 'ReportInformList',
  data() {
    return {
      dataColumns: informColumns,
      listLoading: true,
      downloadLoading: false,
      page: 1,
      size: 10,
      informList: null,
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    handleFilter() {},
    handleExport() {},
    edit() {},
    getList() {
      this.listLoading = true
      this.informList = [
        {
          name: '张三',
          department: '人事部',
        },
        {
          name: '王五',
          department: '项目部',
        },
      ]
      this.total = 3
      this.listLoading = false
    },
    sortChange() {},
    delect() {
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>