<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-col :span="8">
            <el-form-item label="报警类型名称：">
              <el-input
                v-model="formCondition.alarmType"
                class="input-form"
              />
            </el-form-item>
          </el-col>

          <el-col :span="8">
            <el-form-item label="报警来源:">
              <el-select
                v-model="formCondition.alarmSrc"
                class="input-form"
                clearable
              >
                <el-option
                  v-for="item in alarmSrcOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="2">
            <el-form-item>
              <el-button
                type="primary"
                size="mini"
                @click="handleFilter"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
                @click="handleExport"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-form-item>
          </el-col>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <div class="table-container">
      <div>
        <el-col :span="20">
          <h3>报警类型列表</h3>
        </el-col>
        <el-col :span="2">
          <el-button
            type="primary"
            @click="edit()"
          >
            +新增报警类型
          </el-button>
        </el-col>
      </div>
      <el-table
        v-loading="listLoading"
        :data="alarmTypeList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(item, index) in dataColumns"
          :key="index"
          :label="item.label"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="item.value == 'alarmType'"
              class="font-color-blue"
            >{{ scope.row[item.value] }}</span>
            <span v-if="item.value != 'alarmType'">{{ scope.row[item.value] }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="left"
          width="200px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
              @click="delect"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <TypeDrawer ref="typeDrawer" />
  </div>
</template>
<script>
import { typeColumns } from './tableList'
import TypeDrawer from './TypeDrawer'
export default {
  name: 'AlarmTypeList',
  components: { TypeDrawer },
  data() {
    return {
      activeName: 'form',
      formCondition: {
        alarmType: '',
        alarmSrc: '',
      },
      alarmSrcOptions: [],
      dataColumns: typeColumns,
      listLoading: true,
      downloadLoading: false,
      page: 1,
      size: 10,
      alarmTypeList: null,
    }
  },
  mounted() {
    this.getList()
    this.getAlarmSrcOptions()
  },
  methods: {
    handleFilter() {},
    handleExport() {},
    getAlarmSrcOptions() {
      this.alarmSrcOptions = [
        {
          label: '来源1',
          value: '选项1',
        },
        {
          label: '来源2',
          value: '选项2',
        },
        {
          label: '来源3',
          value: '选项3',
        },
      ]
    },
    edit(rowData) {
      if (rowData) {
        this.$refs.typeDrawer.drawerTitle = '编辑报警类型'
        this.$refs.typeDrawer.getForm(rowData)
      } else {
        this.$refs.typeDrawer.drawerTitle = '新增报警类型'
        this.$refs.typeDrawer.formData = {}
      }

      this.$refs.typeDrawer.visible = true
    },
    getList() {
      this.listLoading = true
      this.alarmTypeList = [
        {
          alarmType: '类型1',
          alarmSrc: 'src1',
          typeDes: 'zvvzxv',
        },
        {
          alarmType: '类型5',
          alarmSrc: 'src1',
          typeDes: 'vzxv',
        },
        {
          alarmType: '类型41',
          alarmSrc: 'src3',
          typeDes: 'zvdcxv',
        },
        {
          alarmType: '类型3',
          alarmSrc: 'src1',
          typeDes: 'zvv',
        },
        {
          alarmType: '类型2',
          alarmSrc: 'src2',
          typeDes: 'zvvedv',
        },
      ]
      this.total = 3
      this.listLoading = false
    },
    sortChange() {},
    delect() {
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>