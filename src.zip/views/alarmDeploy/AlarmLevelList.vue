<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-col :span="16">
            <el-form-item label="报警等级名称：">
              <el-input
                v-model="alarmLevel"
                class="input-form"
              />
            </el-form-item>
          </el-col>

          <el-col :span="2">
            <el-form-item>
              <el-button
                type="primary"
                size="mini"
                @click="handleFilter"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
                @click="handleExport"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-form-item>
          </el-col>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <div class="table-container">
      <div>
        <el-col :span="20">
          <h3>报警等级列表</h3>
        </el-col>
        <el-col :span="2">
          <el-button
            type="primary"
            @click="edit()"
          >
            +新增报警等级
          </el-button>
        </el-col>
      </div>
      <el-table
        v-loading="listLoading"
        :data="alarmLevelList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(item, index) in dataColumns"
          :key="index"
          :label="item.label"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="item.value == 'alarmLevel'"
              class="font-color-blue"
            >{{ scope.row[item.value] }}</span>
            <span v-if="item.value != 'alarmLevel'">{{ scope.row[item.value] }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="left"
          width="200px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
              @click="delect"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <LevelDrawer ref="levelDrawer" />
  </div>
</template>
<script>
import { levelColumns } from './tableList'
import LevelDrawer from './LevelDrawer'
export default {
  name: 'AlarmLevelList',
  components: { LevelDrawer },
  data() {
    return {
      activeName: 'form',
      //formCondition
      alarmLevel: '',
      dataColumns: levelColumns,
      listLoading: true,
      downloadLoading: false,
      page: 1,
      size: 10,
      alarmLevelList: null,
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    handleFilter() {},
    handleExport() {},
    edit(rowData) {
      if (rowData) {
        this.$refs.levelDrawer.drawerTitle = '编辑报警等级'
        this.$refs.levelDrawer.getForm(rowData)
      } else {
        this.$refs.levelDrawer.drawerTitle = '新增报警等级'
        this.$refs.levelDrawer.formData = {}
      }

      this.$refs.levelDrawer.visible = true
    },
    getList() {
      this.listLoading = true
      this.alarmLevelList = [
        {
          alarmLevel: 'level1',
          levelDes: 'zvvzxv',
        },
        {
          alarmLevel: 'level2',
          levelDes: '项目部',
        },
        {
          alarmLevel: 'level3',
          levelDes: 'zcvcv',
        },
        {
          alarmLevel: 'level5',
          levelDes: '人事部',
        },
      ]
      this.total = 3
      this.listLoading = false
    },
    sortChange() {},
    delect() {
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>