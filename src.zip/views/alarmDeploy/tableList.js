export const levelColumns = [
  {
    label: "报警等级名称",
    value: "alarmLevel"
  },
  {
    label: "报警等级描述",
    value: "levelDes"
  }
];
export const typeColumns = [
  {
    label: "报警类型名称",
    value: "alarmType"
  },
  {
    label: "报警来源",
    value: "alarmSrc"
  },
  {
    label: "报警类型描述",
    value: "typeDes"
  }
];
export const statusColumns = [
  {
    label: "报警记录状态名称",
    value: "alarmRecordStatus"
  },
  {
    label: "报警记录状态描述",
    value: "statusDes"
  }
];
export const informColumns = [
  {
    label: "报警记录填写人员名称",
    value: "name"
  },
  {
    label: "部门",
    value: "department"
  }
];
