<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-col :span="16">
            <el-form-item label="报警记录状态名称：">
              <el-input
                v-model="alarmRecordStatus"
                class="input-form"
              />
            </el-form-item>
          </el-col>

          <el-col :span="2">
            <el-form-item>
              <el-button
                type="primary"
                size="mini"
                @click="handleFilter"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
                @click="handleExport"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-form-item>
          </el-col>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <div class="table-container">
      <div>
        <el-col :span="20">
          <h3>报警记录状态列表</h3>
        </el-col>
        <el-col :span="2">
          <el-button
            type="primary"
            @click="edit()"
          >
            +新增报警记录状态
          </el-button>
        </el-col>
      </div>
      <el-table
        v-loading="listLoading"
        :data="alarmRecordStatusList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(item, index) in dataColumns"
          :key="index"
          :label="item.label"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="item.value == 'alarmRecordStatus'"
              class="font-color-blue"
            >{{ scope.row[item.value] }}</span>
            <span v-if="item.value != 'alarmRecordStatus'">{{ scope.row[item.value] }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="left"
          width="200px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
              @click="delect"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <RecordStatusDrawer ref="recordStatusDrawer" />
  </div>
</template>
<script>
import { statusColumns } from './tableList'
import RecordStatusDrawer from './RecordStatusDrawer'
export default {
  name: 'AlarmRecordStatusList',
  components: { RecordStatusDrawer },
  data() {
    return {
      activeName: 'form',
      //formCondition
      alarmRecordStatus: '',
      dataColumns: statusColumns,
      listLoading: true,
      downloadLoading: false,
      page: 1,
      size: 10,
      alarmRecordStatusList: null,
    }
  },
  mounted() {
    this.getList()
  },
  methods: {
    handleFilter() {},
    handleExport() {},
    edit(rowData) {
      if (rowData) {
        this.$refs.recordStatusDrawer.drawerTitle = '编辑报警记录状态'
        this.$refs.recordStatusDrawer.getForm(rowData)
      } else {
        this.$refs.recordStatusDrawer.drawerTitle = '新增报警记录状态'
        this.$refs.recordStatusDrawer.formData = {}
      }

      this.$refs.recordStatusDrawer.visible = true
    },
    getList() {
      this.listLoading = true
      this.alarmRecordStatusList = [
        {
          alarmRecordStatus: 'status1',
          statusDes: 'zaa',
        },
        {
          alarmRecordStatus: 'status2',
          statusDes: '项s部',
        },
        {
          alarmRecordStatus: 'status3',
          statusDes: 'sczccv',
        },
      ]
      this.total = 3
      this.listLoading = false
    },
    sortChange() {},
    delect() {
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>