<template>
  <el-drawer
    ref="deptDrawer"
    :title="drawerTitle"
    :before-close="handleClose"
    :visible.sync="visible"
    direction="rtl"
    size="40%"
    show-close
  >
    <el-divider class="divider" />
    <div class="drawer__content">
      <el-form label-width="auto">
        <el-form-item
          :label-width="formLabelWidth"
          label="部门名称"
        >
          <el-col :span="18">
            <el-input
              v-model="formData.deptName"
              placeholder="请输入内容"
            />
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="父级部门"
        >
          <el-col :span="18">
            <el-select v-model="formData.parentDept">
              <el-option
                v-for="item in parentDeptOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="部门描述"
        >
          <el-col :span="18">
            <el-input
              v-model="formData.deptDes"
              type="textarea"
              :rows="3"
              placeholder="请输入内容"
            />
          </el-col>
        </el-form-item>
      </el-form>
      <div
        slot="footer"
        class="drawer-footer"
      >
        <el-button @click="cancel">
          取 消
        </el-button>
        <el-button
          type="primary"
          @click="save"
        >
          保 存
        </el-button>
      </div>
    </div>
    <el-divider class="divider-foot" />
  </el-drawer>
</template>
<script>
export default {
  name: 'DeptDrawer',
  props: {
    //  parentDeptOptions: [],
  },
  data() {
    return {
      drawerTitle: '',
      visible: false,
      formData: {
        deptName: '',
        parentDept: '',
        deptDes: '',
      },
      parentDeptOptions: [],
      formLabelWidth: '150px',
    }
  },
  mounted() {
    // this.parentDeptOptions = this.$emit('getParentDeptOptions')
    // console.log('this.parentDeptOptions')
  },
  methods: {
    handleClose(done) {
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          setTimeout(() => {
            this.loading = false
            done()
          }, 300)
        })
        .catch(() => {})
    },
    getForm(rowData) {
      this.formData = rowData
    },
    save() {
      this.$confirm('确认保存此条数据？', '提示', {
        confirmButtonText: '保存',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          if (this.drawerTitle == '编辑部门') {
            this.updata()
          } else if (this.drawerTitle == '新增部门') {
            this.addData()
          }
          this.visible = false
          this.clearData()
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
        })
    },
    cancel() {
      this.$confirm('取消修改此条数据？', '提示', {
        confirmButtonText: '确认取消',
        cancelButtonText: '返回',
        type: 'warning',
      })
        .then(() => {
          this.visible = false
          this.clearData()
          this.$message({
            type: 'success',
            message: '取消成功!',
          })
        })
        .catch(() => {})
    },
    clearData() {
      this.formData = {}
    },
    addData() {
      this.$emit('addItem', this.formData)
    },
    updata() {
      // console.log('更新数据', this.formData)
      this.$emit('updataItem', this.formData)
    },
  },
}
</script>