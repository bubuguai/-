<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-row>
            <el-col :span="8">
              <el-form-item label="职位名称：">
                <el-input
                  v-model="formCondition.position"
                  class="input-form"
                />
              </el-form-item>
            </el-col>

            <el-col :span="10">
              <el-form-item label="父级职位:">
                <el-select
                  v-model="formCondition.parentPosition"
                  class="input-form"
                  clearable
                >
                  <el-option
                    v-for="item in parentPositionOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>

            <el-col :span="2">
              <el-form-item>
                <el-button
                  type="primary"
                  size="mini"
                  @click="handleFilter"
                >
                  <svg-icon icon-class="screen-l" />
                  查询
                </el-button>
              </el-form-item>
            </el-col>
            <el-col :span="2">
              <el-form-item>
                <el-button
                  class="query-button"
                  :loading="downloadLoading"
                  type="default"
                  size="mini"
                  @click="handleExport"
                >
                  <svg-icon icon-class="export" />
                  导出表格
                </el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <div class="table-container">
      <div>
        <el-col :span="20">
          <h3>职位列表</h3>
        </el-col>
        <el-col :span="2">
          <el-button
            type="primary"
            @click="edit()"
          >
            +新增职位
          </el-button>
        </el-col>
      </div>
      <el-table
        v-loading="listLoading"
        :data="positionList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(item, index) in dataColumns"
          :key="index"
          :label="item.label"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="item.value == 'position'"
              class="font-color-blue"
            >{{ scope.row[item.value] }}</span>
            <span v-if="item.value != 'position'">{{ scope.row[item.value] }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="left"
          width="200px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
              @click="delect"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="listQuery.page"
        :limit.sync="listQuery.size"
        @pagination="getList"
      /> -->
    </div>
    <PositionDrawer
      ref="positionDrawer"
      @updataItem="updataItem"
      @addItem="addItem"
    />
  </div>
</template>
<script>
// import Pagination from '@/components/Pagination'
import { positionColumns } from './tableList'
import PositionDrawer from './PositionDrawer'
export default {
  name: 'PositionList',
  components: {
    PositionDrawer,
    // Pagination,
  },
  //过滤器
  filters: {},
  data() {
    return {
      activeName: 'form',
      listLoading: false,
      downloadLoading: false,
      formCondition: {
        //职位名称
        position: '',
        //父级职位
        parentPosition: '',
      },
      parentPositionOptions: [],
      dataColumns: positionColumns,
      positionList: null,
      // total: 0,
      // page: 1,
      // size: 10,
    }
  },
  mounted() {
    //获得职位数据
    this.getList()
    //获得父级职位列表
    this.getParentPositionOptions()
  },
  methods: {
    getParentPositionOptions() {
      this.parentPositionOptions = [
        {
          label: '工程师1',
          value: '选项1',
        },
        {
          label: '工程师2',
          value: '选项2',
        },
      ]
      // console.log('获得父级职位选项', this.parentPositionOptions)
    },
    getList() {
      this.listLoading = true
      this.positionList = [
        {
          position: '工程师1',
          parentPosition: '工程师2',
          positionDes: '生产',
        },
        {
          position: '工程师2',
          parentPosition: '工程师2',
          positionDes: '设计',
        },
        {
          position: '工程师3',
          parentPosition: '工程师2',
          positionDes: '施工',
        },
      ]
      this.listLoading = false
      // console.log('获得职位数据', this.positionList)
    },
    handleFilter() {
      // console.log(
      //   '开始查询',
      //   this.formCondition.position,
      //   this.formCondition.parentPosition
      // )
      this.listLoading = true
      //查询接口
      // param：formCondition
      // return:List
      this.listLoading = false
      this.clearFormCondition()
    },
    clearFormCondition() {
      this.formCondition = {
        position: '',
        parentPosition: '',
      }
    },
    handleExport() {
      // console.log('开始导出表格', this.positionList)
      this.downloadLoading = true
      //导出表格接口
      //param：deptList
      this.downloadLoading = false
    },
    sortChange() {
      // console.log('表格排序')
    },
    edit(rowData) {
      // console.log('进入编辑', rowData)
      if (rowData) {
        this.$refs.positionDrawer.drawerTitle = '编辑职位'
        this.$refs.positionDrawer.getForm(rowData)
      } else {
        this.$refs.positionDrawer.drawerTitle = '新增职位'
        this.$refs.positionDrawer.formData = {}
      }

      this.$refs.positionDrawer.visible = true
    },
    // addItem(data) {
    //   // console.log('新增数据', data)
    //   //新增接口
    //   // param：data
    //   // return:res=>
    //   //message
    //   //success
    //   //failed
    // },
    // updataItem(data) {
    //   // console.log('更新数据', data)
    //   //更新接口
    //   // param：data
    //   // return:res=>
    //   //message
    //   //success
    //   //failed
    // },
    delect() {
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>