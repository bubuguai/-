<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-row>
            <el-col :span="8">
              <el-form-item label="部门名称：">
                <el-input
                  v-model="formCondition.deptName"
                  class="input-form"
                />
              </el-form-item>
            </el-col>

            <el-col :span="10">
              <el-form-item label="父级部门:">
                <el-select
                  v-model="formCondition.parentDept"
                  class="input-form"
                  clearable
                >
                  <el-option
                    v-for="item in parentDeptOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>

            <el-col :span="2">
              <el-form-item>
                <el-button
                  type="primary"
                  size="mini"
                  @click="handleFilter"
                >
                  <svg-icon icon-class="screen-l" />
                  查询
                </el-button>
              </el-form-item>
            </el-col>
            <el-col :span="2">
              <el-form-item>
                <el-button
                  class="query-button"
                  :loading="downloadLoading"
                  type="default"
                  size="mini"
                  @click="handleExport"
                >
                  <svg-icon icon-class="export" />
                  导出表格
                </el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <div class="table-container">
      <div>
        <el-col :span="20">
          <h3>部门列表</h3>
        </el-col>
        <el-col :span="2">
          <el-button
            type="primary"
            @click="edit()"
          >
            +新增部门
          </el-button>
        </el-col>
      </div>
      <el-table
        v-loading="listLoading"
        :data="deptList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(item, index) in dataColumns"
          :key="index"
          :label="item.label"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="item.value == 'deptName'"
              class="font-color-blue"
            >{{ scope.row[item.value] }}</span>
            <span v-if="item.value != 'deptName'">{{ scope.row[item.value] }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="left"
          width="200px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
              @click="delect(scope.row)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="listQuery.page"
        :limit.sync="listQuery.size"
        @pagination="getList"
      /> -->
    </div>
    <DeptDrawer
      ref="deptDrawer"
      @getParentDeptOptions="getParentDeptOptions"
      @updataItem="updataItem"
      @addItem="addItem"
    />
  </div>
</template>
<script>
// import Pagination from '@/components/Pagination'
import { deptColumns } from './tableList'
import DeptDrawer from './DeptDrawer'
export default {
  name: 'DeptList',
  components: {
    DeptDrawer,
    // Pagination,
  },
  //过滤器
  filters: {},
  data() {
    return {
      activeName: 'form',
      listLoading: false,
      downloadLoading: false,
      formCondition: {
        //部门名称
        deptName: '',
        //父级部门
        parentDept: '',
      },
      parentDeptOptions: [],
      dataColumns: deptColumns,
      deptList: null,
      // total: 0,
      // page: 1,
      // size: 10,
    }
  },
  mounted() {
    //获得部门数据
    this.getList()
    //获得父级部门选项
    this.getParentDeptOptions()
  },
  methods: {
    getParentDeptOptions() {
      this.parentDeptOptions = [
        {
          label: '人事部',
          value: '选项1',
        },
        {
          label: '项目部',
          value: '选项2',
        },
      ]
      // console.log('获得父级部门选项', this.parentDeptOptions)
    },
    getList() {
      this.listLoading = true
      this.deptList = [
        {
          deptName: '人事部',
          parentDept: '项目部',
          deptDes: '生产',
        },
        {
          deptName: '施工部',
          parentDept: '项目部',
          deptDes: '销售',
        },
        {
          deptName: '设计部',
          parentDept: '人事部',
          deptDes: '财务',
        },
      ]
      this.listLoading = false
      // console.log('获得部门数据', this.deptList)
    },
    handleFilter() {
      // console.log(
      //   '开始查询',
      //   this.formCondition.deptName,
      //   this.formCondition.parentDept
      // )
      this.listLoading = true
      //查询接口
      // param：formCondition
      // return:List
      this.listLoading = false
      this.clearFormCondition()
    },
    clearFormCondition() {
      this.formCondition = {
        deptName: '',
        parentDept: '',
      }
    },
    handleExport() {
      // console.log('开始导出表格', this.deptList)
      this.downloadLoading = true
      //导出表格接口
      //param：deptList
      this.downloadLoading = false
    },
    sortChange() {
      // console.log('表格排序')
    },
    edit(rowData) {
      // console.log('进入编辑', rowData)
      if (rowData) {
        this.$refs.deptDrawer.drawerTitle = '编辑部门'
        this.$refs.deptDrawer.getForm(rowData)
      } else {
        this.$refs.deptDrawer.drawerTitle = '新增部门'
        this.$refs.deptDrawer.formData = {}
      }

      this.$refs.deptDrawer.visible = true
    },
    // addItem(data) {
    //   // console.log('新增数据', data)
    //   //新增接口
    //   // param：data
    //   // return:res=>
    //   //message
    //   //success
    //   //failed
    // },
    // updataItem(data) {
    //   // console.log('更新数据', data)
    //   //更新接口
    //   // param：data
    //   // return:res=>
    //   //message
    //   //success
    //   //failed
    // },
    // delectData(data) {
    //   // console.log('删除数据', data)
    //   //删除接口
    //   // param：data
    //   // return:res=>
    //   //message
    //   //success
    //   //failed
    // },
    delect(rowData) {
      // console.log(rowData.deptName)
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.delectData(rowData)
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>