<template>
  <el-drawer
    ref="positionDrawer"
    :title="drawerTitle"
    :before-close="handleClose"
    :visible.sync="visible"
    direction="rtl"
    size="40%"
    show-close
  >
    <el-divider class="divider" />
    <div class="drawer__content">
      <el-form label-width="auto">
        <el-form-item
          :label-width="formLabelWidth"
          label="职位名称"
        >
          <el-col :span="18">
            <el-input
              v-model="formData.position"
              placeholder="请输入内容"
            />
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="父级职位"
        >
          <el-col :span="18">
            <el-select v-model="formData.position">
              <el-option
                v-for="item in parentPositionOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="职位描述"
        >
          <el-col :span="18">
            <el-input
              v-model="formData.des"
              type="textarea"
              :rows="3"
              placeholder="请输入内容"
            />
          </el-col>
        </el-form-item>
      </el-form>
      <div
        slot="footer"
        class="drawer-footer"
      >
        <el-button @click="cancel">
          取 消
        </el-button>
        <el-button
          type="primary"
          @click="save"
        >
          保 存
        </el-button>
      </div>
    </div>
    <el-divider class="divider-foot" />
  </el-drawer>
</template>
<script>
export default {
  name: 'PositionDrawer',
  props: {
    //  parentPositionOptions: [],
  },
  data() {
    return {
      drawerTitle: '',
      visible: false,
      formData: {
        position: '',
        parentPosition: '',
        des: '',
      },
      parentPositionOptions: [],

      formLabelWidth: '150px',
    }
  },
  mounted() {},
  methods: {
    handleClose(done) {
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          setTimeout(() => {
            this.loading = false
            done()
          }, 300)
        })
        .catch(() => {})
    },
    getForm(rowData) {
      this.formData = rowData
    },
    save() {
      this.$confirm('确认保存此条数据？', '提示', {
        confirmButtonText: '保存',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          if (this.drawerTitle == '编辑职位') {
            this.updata()
          } else if (this.drawerTitle == '新增职位') {
            this.addData()
          }
          this.visible = false
          this.clearData()
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
        })
    },
    cancel() {
      this.$confirm('取消修改此条数据？', '提示', {
        confirmButtonText: '确认取消',
        cancelButtonText: '返回',
        type: 'warning',
      })
        .then(() => {
          this.visible = false
          this.clearData()
          this.$message({
            type: 'success',
            message: '取消成功!',
          })
        })
        .catch(() => {})
    },
    clearData() {
      this.formData = {}
    },
    addData() {
      this.$emit('addItem', this.formData)
    },
    updata() {
      // console.log('更新数据', this.formData)
      this.$emit('updataItem', this.formData)
    },
  },
}
</script>