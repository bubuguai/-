<template>
  <el-drawer
    ref="staffDrawer"
    :title="drawerTitle"
    :before-close="handleClose"
    :visible.sync="visible"
    direction="rtl"
    size="40%"
    show-close
  >
    <el-divider class="divider" />
    <div class="drawer__content">
      <el-form label-width="auto">
        <el-form-item
          :label-width="formLabelWidth"
          label="人员名称"
        >
          <el-col :span="18">
            <el-input
              v-model="formData.name"
              placeholder="请输入内容"
            />
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="职位名称"
        >
          <el-col :span="18">
            <el-select v-model="formData.position">
              <el-option
                v-for="item in positionOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="部门名称"
        >
          <el-col :span="18">
            <el-select v-model="formData.department">
              <el-option
                v-for="item in departmentOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="手机号"
        >
          <el-col :span="18">
            <el-input
              v-model="formData.phoneNumber"
              placeholder="请输入内容"
            />
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="电子邮箱"
        >
          <el-col :span="18">
            <el-input
              v-model="formData.email"
              placeholder="请输入内容"
            />
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="微信号"
        >
          <el-col :span="18">
            <el-input
              v-model="formData.weChat"
              placeholder="请输入内容"
            />
          </el-col>
        </el-form-item>

        <el-form-item
          :label-width="formLabelWidth"
          label="照片"
        >
          <el-upload
            class="upload-pic"
            drag
            action="https://jsonplaceholder.typicode.com/posts/"
            multiple
          >
            <i class="el-icon-upload" />
            <div class="el-upload__text">
              将文件拖到此处，或<em>点击上传</em>
            </div>
            <div
              slot="tip"
              class="el-upload__tip"
            >
              只能上传jpg/png文件，且不超过500kb
            </div>
          </el-upload>
        </el-form-item>
      </el-form>
      <div
        slot="footer"
        class="drawer-footer"
      >
        <el-button @click="cancel">
          取 消
        </el-button>
        <el-button
          type="primary"
          @click="save"
        >
          保 存
        </el-button>
      </div>
    </div>
    <el-divider class="divider-foot" />
  </el-drawer>
</template>
<script>
export default {
  name: 'StaffDrawer',
  props: {
    // departmentOptions: [],
    // positionOptions: [],
  },
  data() {
    return {
      drawerTitle: '',
      visible: false,
      formData: {
        name: '',
        position: '',
        department: '',
        phoneNumber: '',
        email: '',
        weChat: '',
        picture: '',
      },
      departmentOptions: [],
      positionOptions: [],
      formLabelWidth: '150px',
    }
  },
  mounted() {},
  methods: {
    handleClose(done) {
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          setTimeout(() => {
            this.loading = false
            done()
          }, 300)
        })
        .catch(() => {})
    },
    getForm(rowData) {
      this.formData = rowData
    },
    save() {
      this.$confirm('确认保存此条数据？', '提示', {
        confirmButtonText: '保存',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          if (this.drawerTitle == '编辑人员') {
            this.updata()
          } else if (this.drawerTitle == '新增人员') {
            this.addData()
          }
          this.visible = false
          this.clearData()
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
        })
    },
    cancel() {
      this.$confirm('取消修改此条数据？', '提示', {
        confirmButtonText: '确认取消',
        cancelButtonText: '返回',
        type: 'warning',
      })
        .then(() => {
          this.visible = false
          this.clearData()
          this.$message({
            type: 'success',
            message: '取消成功!',
          })
        })
        .catch(() => {})
    },
    clearData() {
      this.formData = {}
    },
    addData() {
      this.$emit('addItem', this.formData)
    },
    updata() {
      // console.log('更新数据', this.formData)
      this.$emit('updataItem', this.formData)
    },
  },
}
</script>