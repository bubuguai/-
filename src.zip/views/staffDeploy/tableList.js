export const deptColumns = [
  {
    label: "部门名称",
    value: "deptName"
  },
  {
    label: "父级部门名称",
    value: "parentDept"
  },
  {
    label: "部门描述",
    value: "deptDes"
  }
];
export const positionColumns = [
  {
    label: "职位名称",
    value: "position"
  },
  {
    label: "父级职位名称",
    value: "parentPosition"
  },
  {
    label: "职位描述",
    value: "positionDes"
  }
];

export const staffColumns = [
  {
    label: "人员名称",
    value: "name"
  },
  {
    label: "部门名称",
    value: "department"
  },
  {
    label: "职位名称",
    value: "position"
  },
  {
    label: "手机号",
    value: "phoneNumber"
  },
  {
    label: "电子邮箱",
    value: "email"
  },
  {
    label: "微信号",
    value: "weChat"
  }
];
