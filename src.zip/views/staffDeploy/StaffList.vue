<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-row>
            <el-col :span="8">
              <el-form-item label="人员名称：">
                <el-input
                  v-model="formCondition.name"
                  class="input-form"
                />
              </el-form-item>
            </el-col>

            <el-col :span="8">
              <el-form-item label="部门名称:">
                <el-select
                  v-model="formCondition.department"
                  class="input-form"
                  clearable
                >
                  <el-option
                    v-for="item in departmentOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="职位名称:">
                <el-select
                  v-model="formCondition.position"
                  class="input-form"
                  clearable
                >
                  <el-option
                    v-for="item in positionOptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col
              :span="2"
              :offset="18"
            >
              <el-form-item>
                <el-button
                  type="primary"
                  size="mini"
                  @click="handleFilter"
                >
                  <svg-icon icon-class="screen-l" />
                  查询
                </el-button>
              </el-form-item>
            </el-col>
            <el-col :span="2">
              <el-form-item>
                <el-button
                  class="query-button"
                  :loading="downloadLoading"
                  type="default"
                  size="mini"
                  @click="handleExport"
                >
                  <svg-icon icon-class="export" />
                  导出表格
                </el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <div class="table-container">
      <div>
        <el-col :span="20">
          <h3>人员列表</h3>
        </el-col>
        <el-col :span="2">
          <el-button
            type="primary"
            @click="edit()"
          >
            +新增人员
          </el-button>
        </el-col>
      </div>
      <el-table
        v-loading="listLoading"
        :data="staffList"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(item, index) in dataColumns"
          :key="index"
          :label="item.label"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <span
              v-if="item.value == 'name'"
              class="font-color-blue"
            >{{ scope.row[item.value] }}</span>
            <span v-if="item.value != 'name'">{{ scope.row[item.value] }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="left"
          width="200px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
              @click="delect"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="listQuery.page"
        :limit.sync="listQuery.size"
        @pagination="getList"
      /> -->
    </div>
    <StaffDrawer
      ref="staffDrawer"
      @updataItem="updataItem"
      @addItem="addItem"
    />
  </div>
</template>
<script>
// import Pagination from '@/components/Pagination'
import { staffColumns } from './tableList'
import StaffDrawer from './StaffDrawer'
export default {
  name: 'StaffList',
  components: {
    StaffDrawer,
    // Pagination,
  },
  //过滤器
  filters: {},
  data() {
    return {
      activeName: 'form',
      listLoading: false,
      downloadLoading: false,
      formCondition: {
        //人员名称
        name: '',
        //部门区域
        department: '',
        //职位
        position: '',
      },
      departmentOptions: [],
      positionOptions: [],
      dataColumns: staffColumns,
      staffList: null,
      total: 0,
      page: 1,
      size: 10,
    }
  },
  mounted() {
    //获得部门选项
    this.getDeptOptions()
    //获得职位选项
    this.getPositionOptions()
    //获得人员数据
    this.getList()
  },
  methods: {
    getDeptOptions() {
      this.departmentOptions = [
        {
          label: '人事部',
          value: '选项1',
        },
        {
          label: '设计部',
          value: '选项2',
        },
        {
          label: '项目部',
          value: '选项3',
        },
      ]
      // console.log('获得部门选项', this.departmentOptions)
    },
    getPositionOptions() {
      this.positionOptions = [
        {
          label: '工程师1',
          value: '选项1',
        },
        {
          label: '工程师2',
          value: '选项2',
        },
        {
          label: '工程师3',
          value: '选项3',
        },
      ]
      // console.log('获得职位选项', this.positionOptions)
    },
    getList() {
      this.listLoading = true
      this.staffList = [
        {
          name: '张三',
          department: '项目部',
          position: '工程师1',
          phoneNumber: '123',
          email: '111',
          weChat: 'aaa',
        },
        {
          name: '李四',
          department: '项目部',
          position: '工程师2',
          phoneNumber: '234',
          email: '222',
          weChat: 'bbb',
        },
        {
          name: '王五',
          department: '人事部',
          position: '工程师3',
          phoneNumber: '345',
          email: '333',
          weChat: 'ccc',
        },
      ]
      this.total = 3
      // console.log('获得人员数据', this.staffList)
      this.listLoading = false
    },
    handleFilter() {
      // console.log(
      //   '开始查询',
      //   this.formCondition.name,
      //   this.formCondition.department,
      //   this.formCondition.position
      // )
      this.listLoading = true
      //查询接口
      // param：formCondition
      // return:List
      this.listLoading = false
      this.clearFormCondition()
    },
    clearFormCondition() {
      this.formCondition = {
        name: '',
        department: '',
        position: '',
      }
    },
    handleExport() {
      // console.log('开始导出表格', this.staffList)
      this.downloadLoading = true
      //导出表格接口
      //param：deptList
      this.downloadLoading = false
    },
    sortChange() {
      // console.log('表格排序')
    },
    edit(rowData) {
      // console.log('进入编辑', rowData)
      if (rowData) {
        this.$refs.staffDrawer.drawerTitle = '编辑人员'
        this.$refs.staffDrawer.getForm(rowData)
      } else {
        this.$refs.staffDrawer.drawerTitle = '新增人员'
        this.$refs.staffDrawer.formData = {}
      }

      this.$refs.staffDrawer.visible = true
    },
    // addItem(data) {
    //   // console.log('新增数据', data)
    //   //新增接口
    //   // param：data
    //   // return:res=>
    //   //message
    //   //success
    //   //failed
    // },
    // updataItem(data) {
    //   // console.log('更新数据', data)
    //   //更新接口
    //   // param：data
    //   // return:res=>
    //   //message
    //   //success
    //   //failed
    // },
    delect() {
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },
  },
}
</script>