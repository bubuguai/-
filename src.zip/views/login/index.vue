<template>
  <div class="login-container">
    <div class="login-element">
      <div class="edit">
        <div style="padding: 4% 4%">
          <el-row>
            <el-col :md="{ span: 12 }" :xs="{ span: 24 }">
              <div class="title-container">
                <div class="title">安全生产监测平台</div>
                <el-form
                  ref="loginForm"
                  :model="loginForm"
                  :rules="loginRules"
                  class="login-form"
                  autocomplete="on"
                  lable-position="left"
                >
                  <el-form-item prop="username">
                    <span class="svg-container">
                      <svg-icon class="iconn" icon-class="users" />
                    </span>
                    <el-input
                      ref="username"
                      v-model="loginForm.username"
                      class="inputBox"
                      placeholder="账号"
                      tabindex="1"
                      name="username"
                      type="text"
                      clearable
                    />
                  </el-form-item>

                  <el-tooltip
                    v-model="capsTooltip"
                    content="Caps lock is On"
                    placement="right"
                    manual
                  >
                    <el-form-item prop="password">
                      <span class="svg-container">
                        <svg-icon class="iconnPwd" icon-class="pwd" />
                      </span>
                      <!-- <el-input v-model="loginForm.password" placeholder="请输入内容"></el-input> -->
                      <el-input
                        :key="passwordType"
                        ref="password"
                        v-model="loginForm.password"
                        tabindex="2"
                        :type="passwordType"
                        placeholder="密码"
                        name="password"
                        clearable
                        @keyup.native="checkCapslock"
                        @blur="capsTooltip = false"
                      />
                      <span class="show-pwd" @click="showPwd">
                        <svg-icon
                          :icon-class="
                            passwordType === 'password' ? 'eye' : 'eye-open'
                          "
                        />
                      </span>
                    </el-form-item>
                  </el-tooltip>
                  <el-row>
                    <el-col :md="{ span: 14 }" :xs="{ span: 14 }">
                      <el-form-item>
                        <span class="svg-container" prop="verificationCode">
                          <svg-icon class="iconnCode" icon-class="vcode" />
                        </span>
                        <!-- <el-input
                          class="inputCode"
                          ref="verificationCode"
                          v-model="loginForm.verificationCode"
                          tabindex="3"
                          placeholder="验证码"
                          name="verificationCode"
                          type="text"
                          @keyup.enter.native="handleLogin"
                        /> -->
                        <el-input
                          ref="verificationCode"
                          v-model="loginForm.verificationCode"
                          tabindex="3"
                          placeholder="验证码"
                          name="verificationCode"
                          type="text"
                          @keyup.enter.native="handleLogin"
                        />
                      </el-form-item>
                    </el-col>
                    <el-col
                      style="text-align: center"
                      :md="{ span: 7 }"
                      :xs="{ span: 7 }"
                    />
                    <el-col :md="{ span: 10 }" :xs="{ span: 10 }">
                      <div class="imgCode">
                        <img
                          class="verification-code"
                          :src="imgSrc"
                          @click="getVerifys()"
                        >
                      </div>
                      <!-- <el-button
                        size="mini"
                        type="text"
                        @click="getVerifys()"
                      >点击更换验证码</el-button> -->
                    </el-col>
                  </el-row>
                  <el-checkbox
                    v-model="rememberPwd"
                    class="remPassword"
                  >记住密码</el-checkbox>
                  <!-- <el-button class="forgetPasswd" type="text">忘记密码？</el-button> -->
                  <span class="forgetPasswd">
                    <el-link
                      v-model="forgetPwd"
                      style="color:#52AAFF , font-size: 16px; "
                      type="primary"
                    >忘记密码？</el-link>
                  </span>
                  <el-button
                    class="butt"
                    :loading="loading"
                    type="primary"
                    style="width: 100%; margin-top: 30px"
                    @click.native.prevent="handleLogin"
                  >立即登录</el-button>
                </el-form>
              </div>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { getVerify } from '@/api/user'
import Cookies from 'js-cookie'
export default {
  name: 'Login',
  data() {
    const validateUsername = (rule, value, callback) => {
      if (!value) {
        callback(new Error('请输入用户名'))
      } else {
        callback()
      }
    }
    const validatePassword = (rule, value, callback) => {
      if (value.length < 6) {
        callback(new Error('密码不能少于8位'))
      } else if (value.length > 16) {
        callback(new Error('密码不能超过16位'))
      } else {
        callback()
      }
    }
    const validateVerificationCode = (rule, value, callback) => {
      const code = this.code.toLowerCase()
      const input = value.toLowerCase()
      if (!value) {
        callback(new Error('请输入验证码'))
      } else if (code !== input) {
        callback(new Error('验证码输入错误'))
      } else {
        callback()
      }
    }
    return {
      loginForm: {
        username: '',
        password: '',
        verificationCode: ''
      },
      loginRules: {
        username: [
          { required: true, trigger: 'change', validator: validateUsername }
        ],
        password: [
          { required: true, trigger: 'blur', validator: validatePassword }
        ],
        verificationCode: [
          {
            required: true,
            trigger: 'blur',
            validator: validateVerificationCode
          }
        ]
      },
      passwordRem: '',
      passwordType: 'password',
      capsTooltip: false,
      loading: false,
      showDialog: false,
      redirect: undefined,
      otherQuery: {},
      code: '',
      rememberPwd: false,
      forgetPwd: '',
      imgSrc: '',
      dataImg: []
    }
  },
  watch: {
    $route: {
      handler: function(route) {
        const query = route.query
        if (query) {
          this.redirect = query.redirect
          this.otherQuery = this.getOtherQuery(query)
        }
      },
      immediate: true
    }
  },
  created() {
    console.log(this.loginForm.password)
    // window.addEventListener('storage', this.afterQRScan)
    this.getVerifys()
  },
  mounted() {
    if (this.loginForm.username === '') {
      this.$refs.username.focus()
    } else if (this.loginForm.password === '') {
      this.$refs.password.focus()
    }
    this.getCookie()
  },
  destroyed() {
    window.removeEventListener('storage', this.afterQRScan)
  },
  methods: {
    getVerifys() {
      getVerify().then((res) => {
        this.imgSrc =
          'data:image/png;base64,' +
          btoa(
            new Uint8Array(res.data).reduce(
              (data, byte) => data + String.fromCharCode(byte),
              ''
            )
          )
        this.code = Cookies.get().RANDOMVALIDATECODEKEY
        console.log('验证码--->', Cookies.get().RANDOMVALIDATECODEKEY)
      })
    },
    checkCapslock({ shiftKey, key } = {}) {
      if (key && key.length === 1) {
        if (
          (shiftKey && key >= 'a' && key <= 'z') ||
          (!shiftKey && key >= 'A' && key <= 'Z')
        ) {
          this.capsTooltip = true
        } else {
          this.capsTooltip = false
        }
      }
      if (key === 'CapsLock' && this.capsTooltip === true) {
        this.capsTooltip = false
      }
    },
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    },
    handleLogin() {
      console.log('handleLogin')
      var password = ''
      if (this.loginForm.password === '********') {
        password = this.passwordRem
      } else {
        var sha1 = require('js-sha1')
        password = sha1(this.loginForm.password)
      }
      var sha1 = require('js-sha1')
      password = sha1(this.loginForm.password)
      this.$refs.loginForm.validate((valid) => {
        console.log('validate', valid)
        if (valid) {
          this.loading = true
          this.$store
            .dispatch('user/Login', {
              userName: this.loginForm.username,
              passWord: password,
              remember: this.rememberPwd
            })
            .then(res => {
              console.log('Login res = ', res)
              if (res.data.result === 'success') {
                // const data = res.data.data
                console.log('this.$router.push', this.redirect || '/')
                this.$router.push({
                  path: this.redirect || '/',
                  query: this.otherQuery
                })
                this.setCookie(
                  this.loginForm.username,
                  password,
                  7,
                  this.rememberPwd
                )
                this.loading = false
              } else {
                this.getVerifys()
                this.loading = false
                this.$message.error(res.data.message)
              }
            })
            .catch((e) => {
              console.log('catch  ', e)
              this.loading = false
            })
            .finally(() => {
              this.loading = false
            })
        } else {
          this.getVerifys()
          return false
        }

        // if (valid) {
        //   this.loading = true
        //   console.log('111111111111111,进来了')
        //   this.$router.push({ path: '/firstList', query: {
        //     userName: this.loginForm.username,
        //     passWord: password,
        //     remember: this.rememberPwd
        //   }})
        //   this.$router.push({ name: 'FirstList' })
        //   console.log('111111111111111,出来了')
        // }
      })
    },
    getOtherQuery(query) {
      return Object.keys(query).reduce((acc, cur) => {
        if (cur !== 'redirect') {
          acc[cur] = query[cur]
        }
        return acc
      }, {})
    },
    // 设置cookie
    setCookie(c_name, c_pwd, exdays, remeberFlag) {
      var exdate = new Date() // 获取时间
      exdate.setTime(exdate.getTime() + 24 * 60 * 60 * 1000 * exdays) // 保存的天数
      // 字符串拼接cookie
      window.document.cookie =
        'userName' + '=' + c_name + ';path=/;expires=' + exdate.toGMTString()
      window.document.cookie =
        'userPwd' + '=' + c_pwd + ';path=/;expires=' + exdate.toGMTString()
      window.document.cookie =
        'remeberFlag' +
        '=' +
        remeberFlag +
        ';path=/;expires=' +
        exdate.toGMTString()
    },

    // 读取cookie
    getCookie() {
      if (document.cookie.length > 0) {
        var arr = document.cookie.split('; ') // 这里显示的格式需要切割一下自己可输出看下
        for (var i = 0; i < arr.length; i++) {
          var arr2 = arr[i].split('=') // 再次切割
          // 判断查找相对应的值
          if (arr2[0] === 'userName') {
            this.loginForm.username = arr2[1] // 保存到保存数据的地方
          } else if (arr2[0] === 'userPwd') {
            this.passwordRem = arr2[1]
            this.loginForm.password = '********'
          }
        }
      }
    }
  }
}
</script>
<style lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg: #fff;
$light_gray: #272727;
$cursor: #4f4f4f;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-container .el-input input {
    color: $cursor;
  }
}

/* reset element-ui css */
.login-container .el-input input:-webkit-autofill {
  -webkit-text-fill-color: #3c3c3c !important;
}
.login-container {
  background-image: url('../../assets/images/login.png');
  .el-input {
    //display: inline-block;
    height: 37px;
    width: 50%;
    font-size: 20px;

    input {
      background: transparent;
      border: 0px;
      height: 68px;
    //   width: 559px;
      -webkit-appearance: none;
      border-radius: 0px;
      vertical-align: middle;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }

  .el-form-item {
    border: 1px solid #979797;
    margin-bottom: 4vh;
    // background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    //width: 559px;
    height: 68px;
    // color: #454545;
  }
}
</style>
<style lang="scss" scoped>
$bg: #fff;

.verification-code {
  width: 209px;
  height: 68px;
  cursor: pointer;
  margin-left: 15px;
}
.carousel_img {
  width: 100%;
  height: 100%;
}
.login-container {
  min-height: 100%;
  overflow: hidden;
  background-size: 100% 100%;

  .login-element {
    margin: auto;
    width: 85%;
    // height: 700px;
    border-radius: 15px;
    margin: 5% auto;

    // .edit {
    //     border: #096dd9;
    //     width: 1350px;
    // }
  }
  .login-form {
    position: relative;
    max-width: 100%;
    padding: 8% 10%;
    // overflow: hidden;
    // background-color: #fff;

    .remPassword {
      font-family: PingFangSC-Regular;
      color: #52aaff 50%;
      font-size: 16px;
      line-height: 22px;
      size: 'medium';
    }

    .forgetPasswd {
      font-family: PingFangSC-Regular;
      color: #52aaff 100%;
      font-size: 16px;
      line-height: 22px;
      padding-left: 8%;
    }

    .butt {
      background: #096dd9;
      border-radius: 5px;
      border-radius: 5px;
      width: 559px;
      height: 68px;
      font-family: PingFangSC-Regular;
      font-size: 24px;
      color: #ffffff;
    }

    // .inputBox {
    //   border: 1px solid #979797;
    //   border-radius: 5px;
    //   border-radius: 5px;
    //   width: 559px;
    // }
  }

  .tips {
    font-size: 14px;
    // color: #fff;
    margin-bottom: 10px;

    span {
      &:first-of-type {
        margin-right: 16px;
      }
    }
  }

  .inputCode{
    vertical-align: middle;
    margin-top: -30px;
    width: 100px;
    height: 68px;
  }

  // .imgCode{
  //   border: 1px solid #979797;
  //   border-radius: 5px;
  //   width: 209px;
  //   height: 68px;
  // }

  .svg-container {
    padding: 0% 2%;
    vertical-align: middle;
    width: 30px;
    margin-top: -5px;
    //height: 100px;
    display: inline-block;

    .iconn {
      height: 28px;
      width: 23px;
      vertical-align: middle;
    }

    .iconnPwd {
      height: 28px;
      width: 23px;
      vertical-align: middle;
    }

    .iconnCode {
      height: 28px;
      width: 23px;
      vertical-align: middle;
    }
  }

  .login-cont {
    padding: 2% 0;
  }

  .title-container {
    position: relative;
    padding: 0% 4% 4%;

    .title {
      font-size: 40px;
      color: #7f7f7f;
      font-family: PingFangSC-Semibold;
      //font-weight: bold;
      // margin: 0px auto 0px auto;
      text-align: center;
    }

    .set-language {
      // color: #fff;
      position: absolute;
      top: 3px;
      font-size: 18px;
      right: 0px;
      cursor: pointer;
    }
  }

  .show-pwd {
    position: absolute;
    right: 10px;
    top: 7px;
    font-size: 16px;
    cursor: pointer;
    user-select: none;
  }

  .thirdparty-button {
    position: absolute;
    right: 0;
    bottom: 6px;
  }

  @media only screen and (max-width: 470px) {
    .thirdparty-button {
      display: none;
    }
  }
}
</style>
