<template>
  <el-drawer
    ref="informDrawer"
    title="选择通知人员"
    :before-close="handleClose"
    :visible.sync="visible"
    direction="ltr"
    size="40%"
    show-close
  >
    <div style="text-align: center">
      <el-divider class="divider" />
      <!-- 如果希望某些数据项在初始化时就被勾选，可以使用 left-default-checked 和 right-default-checked 属性
       :left-default-checked="[2, 3]"
        :right-default-checked="[1]" -->
      <el-transfer
        v-model="item"
        style="text-align: left; display: inline-block"
        filterable
        :titles="['人员列表', '已选择人员']"
        :button-texts="['移除选中', '选择人员']"
        :props="{
          key: 'name',
          label: 'department'
        }"
        :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}'
        }"
        :data="list"
      >
        <span slot-scope="{ option }">{{ option.department }} {{ option.name }}</span>
      </el-transfer>

      <div
        slot="footer"
        class="drawer-footer"
      >
        <el-button @click="cancel">
          取 消
        </el-button>
        <el-button
          type="primary"
          @click="save"
        >
          保 存
        </el-button>
      </div>
    </div>
    <el-divider class="divider-foot" />
  </el-drawer>
</template>
<script>
export default {
  name: 'InformDrawer',
  data() {
    return {
      //信息列表
      list: [],
      //选择的数据
      item: [],
      visible: false,
    }
  },
  mounted() {
    this.getStaff()
  },
  methods: {
    handleClose(done) {
      this.$confirm('确定要提交表单吗？')
        .then(() => {
          this.loading = true
          setTimeout(() => {
            this.loading = false
            done()
          }, 300)
        })
        .catch(() => {})
    },
    cancel() {
      this.$confirm('取消修改此条数据？', '提示', {
        confirmButtonText: '确认取消',
        cancelButtonText: '返回',
        type: 'warning',
      })
        .then(() => {
          this.visible = false
          this.clearData()
          this.$message({
            type: 'success',
            message: '取消成功!',
          })
        })
        .catch(() => {})
    },
    save() {
      this.$confirm('确认保存此条数据？', '提示', {
        confirmButtonText: '保存',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.visible = false
          this.clearData()
          this.$message({
            type: 'success',
            message: '保存成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消保存',
          })
        })
    },
    getStaff() {
      this.list = [
        { name: '张三', department: '项目部', position: '工程师1' },
        { name: '李四', department: '设计部', position: '工程师2' },
        { name: '王五', department: '人事部', position: '工程师2' },
        { name: '赵六', department: '施工部', position: '工程师3' },
      ]
    },
  },
}
</script>
<style lang="scss" scoped>
</style>