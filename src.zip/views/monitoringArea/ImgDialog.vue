<template>
  <el-dialog
    ref="imgDialog"
    :before-close="handleClose"
    :visible.sync="visible"
    show-close
    class="dialog-el"
    title="查看图片"
    width="50%"
    center
  >
    <img
      style="width:700px;height:400px"
      src="../../assets/404_images/404.png"
    >
    <span slot="footer">
      <el-button
        type="primary"
        @click="close"
      >确 定</el-button>
    </span>
  </el-dialog>
</template>
<script>
export default {
  name: 'ImgDialog',
  components: {},
  data() {
    return {
      visible: false,
      img: '',
    }
  },
  methods: {
    handleClose() {},
    close() {
      this.visible = false
    },
  },
}
</script>
<style lang="scss" scoped>
.dialog-el {
  width: 80%;
  top: 20%;
  left: 10%;
}
</style>