export const columns = [
  {
    label: "监控区域名称",
    value: "name"
  },
  {
    label: "父级区域名称",
    value: "region"
  }
];
export const options = [
  {
    value: "选项1",
    label: "工厂1"
  },
  {
    value: "选项2",
    label: "工厂2"
  },
  {
    value: "选项3",
    label: "工厂3"
  }
];

export const options2 = [
  {
    value: "选项1",
    label: "区域1"
  },
  {
    value: "选项2",
    label: "区域2"
  },
  {
    value: "选项3",
    label: "区域3"
  }
];
