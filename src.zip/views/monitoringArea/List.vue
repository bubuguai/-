<template>
  <div class="app-container">
    <el-collapse
      v-model="activeName"
      accordion
    >
      <el-collapse-item name="form">
        <el-form
          :inline="true"
          class="form-layout"
        >
          <el-col :span="8">
            <el-form-item label="监控名称：">
              <el-input
                v-model="formCondition.monitoringName"
                class="input-form"
              />
            </el-form-item>
          </el-col>

          <el-col :span="10">
            <el-form-item label="父级区域:">
              <el-select
                v-model="formCondition.monitoringRegion"
                class="input-form"
                clearable
              >
                <el-option
                  v-for="item in regionOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                type="primary"
                size="mini"
                @click="handleFilter"
              >
                <svg-icon icon-class="screen-l" />
                查询
              </el-button>
            </el-form-item>
          </el-col>
          <el-col :span="2">
            <el-form-item>
              <el-button
                class="query-button"
                :loading="downloadLoading"
                type="default"
                size="mini"
                @click="handleExport"
              >
                <svg-icon icon-class="export" />
                导出表格
              </el-button>
            </el-form-item>
          </el-col>
        </el-form>
      </el-collapse-item>
    </el-collapse>
    <div class="table-container">
      <div>
        <el-col :span="20">
          <h3>监控区域列表</h3>
        </el-col>
        <el-col :span="2">
          <el-button
            type="primary"
            @click="edit()"
          >
            +新增监控区域
          </el-button>
        </el-col>
      </div>
      <el-table
        v-loading="listLoading"
        :data="list"
        :header-cell-style="{ background: '#F7F7F7' }"
        fit
        highlight-current-row
        max-height="800px"
        @sort-change="sortChange"
      >
        <el-table-column
          v-for="(item, index) in dataColumns"
          :key="index"
          :label="item.label"
          align="left"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <!-- <span
              v-if="col.value == 'monitoringName'"
              class="table-column"
            >{{ scope.row.sensorid}}</span>
            <span v-if="col.value != 'monitoringName'">{{ scope.row.sensorid}}</span> -->
            <span
              v-if="item.value == 'name'"
              class="font-color-blue"
            >{{ scope.row[item.value] }}</span>
            <span v-if="item.value != 'name'">{{ scope.row[item.value] }}</span>
          </template>
        </el-table-column>

        <el-table-column
          label="查看图片"
          align="left"
          width="400px"
          show-overflow-tooltip
        >
          <!-- slot-scope="scope" -->
          <template>
            <!-- <span v-if="scope.row.dcsAlarmImage === null">暂无图片</span> -->
            <el-button
              type="primary"
              plain
              @click="openImg"
            >
              查看
            </el-button>
            <!-- v-else -->
            <!-- <el-image
              style="border:none;width:100px;height:60px;"
              :src="scope.row.dcsAlarmImage"
              alt
              @click.native="previewImg(scope.$index,scope.row)"
            /> -->
          </template>
        </el-table-column>
        <el-table-column
          label="操作"
          align="left"
          width="200px"
          class-name="small-padding fixed-width"
        >
          <template slot-scope="scope">
            <el-button
              type="text"
              icon="el-icon-edit"
              size="mini"
              class="btncor"
              @click="edit(scope.row)"
            >
              编辑
            </el-button>
            <el-button
              type="text"
              icon="el-icon-delete"
              size="mini"
              @click="delect"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <pagination
        v-show="total > 0"
        :total="total"
        :page.sync="page"
        :limit.sync="size"
        @pagination="getList"
      />
    </div>

    <EditDrawer
      ref="editDrawer"
      @selectInform="selectInform"
    />
    <InformDrawer ref="informDrawer" />
    <ImgDialog ref="imgDialog" />
  </div>
</template>
<script>
// import {
//   selectArea,
//   addArea,
//   deleteArea,
//   allArea,
//   partArea,
//   treeArea,
// } from '@/api/area'
import Pagination from '@/components/Pagination'
import EditDrawer from './EditDrawer'
import InformDrawer from './InformDrawer'
import ImgDialog from './ImgDialog'
import { columns, options } from './tableList'
export default {
  name: 'MonitoringArea',
  components: {
    Pagination,
    EditDrawer,
    InformDrawer,
    ImgDialog,
  },
  filters: {},
  data() {
    return {
      activeName: 'form',
      //查询列表
      formCondition: {
        //0监控名称
        monitoringName: '',
        //0父级区域
        monitoringRegion: '',
      },
      dataColumns: columns,
      regionOptions: options,
      //regionOptions: [],
      page: 1,
      size: 10,
      list: [],
      //数据数量
      total: 0,
      //数据是否下载完成
      listLoading: true,
      downloadLoading: false,
      form: {
        name: '',
        region: '',
        coordinateHeight: '',
        coordinateWidth: '',
        coordinateX: '',
        coordinateY: '',
        inform: '',
        imageSrc: '',
      },
      //input style
      formLabelWidth: '100px',
      formLabelWidth2: '20px',
    }
  },
  mounted() {
    this.getList()
    this.getQueryOptions()
  },
  methods: {
    handleFilter() {},
    edit(rowData) {
      if (rowData) {
        this.$refs.editDrawer.drawerTitle = '编辑监控区域'
        this.$refs.editDrawer.getForm(rowData)
      } else {
        this.$refs.editDrawer.drawerTitle = '新增监控区域'
        this.$refs.editDrawer.formData = {}
      }

      this.$refs.editDrawer.visible = true
    },
    delect() {
      this.$confirm('确认删除此条数据？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!',
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除',
          })
        })
    },

    getList() {
      this.listLoading = true
      this.list = [
        {
          name: 'C16-2F-3G',
          region: 'C16-2F',
          coordinateHeight: '12',
          coordinateWidth: '12',
          coordinateX: '23',
          coordinateY: '12',
          inform: '张三',
          imageSrc: 'dwde',
        },
        {
          name: 'C16-2F-4G',
          region: 'C16-2F',
          coordinateHeight: '5',
          coordinateWidth: '3',
          coordinateX: '23',
          coordinateY: '25',
          inform: '李四',
          imageSrc: 'dwqd',
        },
        {
          name: 'C16-3F-1G',
          region: 'C16-1F',
          coordinateHeight: '3',
          coordinateWidth: '2',
          coordinateX: '21',
          coordinateY: '4',
          inform: '王五',
          imageSrc: 'wd',
        },
      ]
      this.total = 3
      this.listLoading = false
    },

    //column排序
    sortChange() {
      // if (data.order === 'ascending') {
      //   this.listQuery.sortRule = 1
      // } else {
      //   this.listQuery.sortRule = 2
      // }
      // this.listQuery.sortField = data.prop
      // this.getList()
    },

    beforeClose() {
      this.dialogFormVisible = false
      this.imageSrc = ''
      this.imgZoom = 1
      document.getElementsByClassName(
        'dcsAlarmImg'
      )[0].style.zoom = this.imgZoom
    },

    handleDelete(row) {
      this.$notify({
        title: '成功',
        message: '删除成功',
        type: 'success',
        duration: 2000,
      })
      const index = this.list.indexOf(row)
      this.list.splice(index, 1)
    },
    handleExport() {},
    //得到父级部门选项
    getQueryOptions() {
      //this.regionOptions
    },
    visible() {
      this.drawerVisible = true
    },
    openImg() {
      this.$refs.imgDialog.visible = true
    },
    selectInform() {
      this.$refs.informDrawer.visible = true
    },
  },
}
</script>
<style lang="scss" scoped>
.imgicon {
  text-align: center;
  margin: 260px auto;
  font-size: 30px;
  cursor: pointer;
}

.sco {
  color: #1890ff;
  font-family: SFProText-Regular;
  font-size: 14px;
}

.dialog-peo {
  width: 60%;
  top: 30%;
  left: 21%;
}
.font-color-blue {
  color: #4faaff;
}
</style>
