<template>
  <el-dialog
    ref="informDialog"
    title="选择通知人员"
    :visible.sync="visible"
    width="35%"
    :before-close="handleClose"
  >
    <div style="text-align: center">
      <el-divider class="divider" />
      <!-- 如果希望某些数据项在初始化时就被勾选，可以使用 left-default-checked 和 right-default-checked 属性
       :left-default-checked="[2, 3]"
        :right-default-checked="[1]" -->
      <!-- :props="{
      key: 'name',
      label: 'department'
    }" -->
      <el-transfer
        v-model="item"
        style="text-align: left; display: inline-block"
        filterable
        :titles="['人员列表', '已选择人员']"
        :button-texts="['选择人员', '移除选中']"
        :format="{
          noChecked: '${total}',
          hasChecked: '${checked}/${total}'
        }"
        :data="list"
      >
        <!-- <span slot-scope="{ option }">{{ option.key }} - {{ option.label }}</span> -->
      </el-transfer>
    </div>
    <div
      slot="footer"
      class="drawer-footer"
    >
      <el-button @click="cancel">
        取 消
      </el-button>
      <el-button
        type="primary"
        @click="save"
      >
        保 存
      </el-button>
    </div>
    <el-divider class="divider-foot" />
  </el-dialog>
</template>
<script>
export default {
  name: 'InformDialog',
  data() {
    return {
      //信息列表
      list: [],
      //选择的数据
      item: [],
      visible: true,
    }
  },
  mounted() {},
  methods: {
    getStaff() {
      // this.list = [
      //   { name: '张三', department: '项目部', position: '工程师1' },
      //   { name: '李四', department: '设计部', position: '工程师2' },
      //   { name: '王五', department: '人事部', position: '工程师2' },
      //   { name: '赵六', department: '施工部', position: '工程师3' },
      // ]
      this.list = [
        { key: '张三', label: '项目部', position: '工程师1' },
        { key: '李四', label: '设计部', position: '工程师2' },
        { key: '王五', label: '人事部', position: '工程师2' },
        { key: '赵六', label: '施工部', position: '工程师3' },
      ]
    },
  },
}
</script>