package com.xdl.test;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.xdl.bean.XdlEtQuestion;
import com.xdl.mapper.XdlEtAdminDAO;
import com.xdl.service.XdlEtQuetionService;


public class XdlAccountBankTest {

	public static void main(String[] args) {
		
	ApplicationContext app = 
			new ClassPathXmlApplicationContext("applicationContext.xml");
	XdlEtQuetionService  se = app.getBean("questionService", XdlEtQuetionService.class);
	
	//se.questionAdd(new XdlEtQuestion("1*1",1,1,2,4,new Timestamp(System.currentTimeMillis()),"",new Timestamp(System.currentTimeMillis()),"12",1,1,1,1.1,"as","asd","a","asd"));
	
	Map<Integer,Integer> map = new HashMap<Integer,Integer>();
	map.put(1, 2);
	map.put(4, 2);
	
	List<XdlEtQuestion> questionList = se.questionList(map);
	for(XdlEtQuestion question:questionList) {
		System.out.println(question);
	}
	
	}
}
