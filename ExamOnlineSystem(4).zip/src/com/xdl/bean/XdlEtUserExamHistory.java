package com.xdl.bean;

import java.sql.Timestamp;

public class XdlEtUserExamHistory {
	private int id;
	private int user_id;
	private int exam_paper_id;
	private String content;
	private Timestamp create_time;
	private String answer_sheet;
	private int duration;
	private float point_get;
	private Timestamp submit_time;
	//private String paperName;
	private String name;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	/*
	 * public String getPaperName() { return paperName; } public void
	 * setPaperName(String paperName) { this.paperName = paperName; }
	 */
	public XdlEtUserExamHistory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public XdlEtUserExamHistory(int id, int user_id, int exam_paper_id, String content, Timestamp create_time,
			String answer_sheet, int duration, float point_get, Timestamp submit_time) {
		super();
		this.id = id;
		this.user_id = user_id;
		this.exam_paper_id = exam_paper_id;
		this.content = content;
		this.create_time = create_time;
		this.answer_sheet = answer_sheet;
		this.duration = duration;
		this.point_get = point_get;
		this.submit_time = submit_time;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getExam_paper_id() {
		return exam_paper_id;
	}
	public void setExam_paper_id(int exam_paper_id) {
		this.exam_paper_id = exam_paper_id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Timestamp getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Timestamp create_time) {
		this.create_time = create_time;
	}
	public String getAnswer_sheet() {
		return answer_sheet;
	}
	public void setAnswer_sheet(String answer_sheet) {
		this.answer_sheet = answer_sheet;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public float getPoint_get() {
		return point_get;
	}
	public void setPoint_get(float point_get) {
		this.point_get = point_get;
	}
	public Timestamp getSubmit_time() {
		return submit_time;
	}
	public void setSubmit_time(Timestamp submit_time) {
		this.submit_time = submit_time;
	}
	@Override
	public String toString() {
		return "XdlEtUserExamHistory [id=" + id + ", user_id=" + user_id + ", exam_paper_id=" + exam_paper_id
				+ ", content=" + content + ", create_time=" + create_time + ", answer_sheet=" + answer_sheet
				+ ", duration=" + duration + ", point_get=" + point_get + ", submit_time=" + submit_time
				+ ", name=" + name + "]";
	}
	
}
