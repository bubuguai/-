package com.xdl.bean;

import java.io.Serializable;
import java.sql.Timestamp;

public class XdlEtUser implements Serializable{
	 
	private static final long serialVersionUID = 1L;
	private int id;	
	private String username;	
	private String truename;
	private String password;
	private String email;
	private String phone;
	private Timestamp add_date;
	private Timestamp expire_date;
	private int add_by;
	private int enabled;
	private int field_id;
	private Timestamp last_login_time;
	private Timestamp login_time;
	private String province;
	private String company;
	private String department;
	private int classID;
	
	
	private String fieldName;
	private String className;
	
	
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public XdlEtUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	public XdlEtUser(int id, String username, String truename, String password, String email, String phone,
			Timestamp add_date, Timestamp expire_date, int add_by, int enabled, int field_id, Timestamp last_login_time,
			Timestamp login_time, String province, String company, String department, int classID) {
		super();
		this.id = id;
		this.username = username;
		this.truename = truename;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.add_date = add_date;
		this.expire_date = expire_date;
		this.add_by = add_by;
		this.enabled = enabled;
		this.field_id = field_id;
		this.last_login_time = last_login_time;
		this.login_time = login_time;
		this.province = province;
		this.company = company;
		this.department = department;
		this.classID = classID;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTruename() {
		return truename;
	}
	public void setTruename(String truename) {
		this.truename = truename;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Timestamp getAdd_date() {
		return add_date;
	}
	public void setAdd_date(Timestamp add_date) {
		this.add_date = add_date;
	}
	public Timestamp getExpire_date() {
		return expire_date;
	}
	public void setExpire_date(Timestamp expire_date) {
		this.expire_date = expire_date;
	}
	public int getAdd_by() {
		return add_by;
	}
	public void setAdd_by(int add_by) {
		this.add_by = add_by;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	public int getField_id() {
		return field_id;
	}
	public void setField_id(int field_id) {
		this.field_id = field_id;
	}
	public Timestamp getLast_login_time() {
		return last_login_time;
	}
	public void setLast_login_time(Timestamp last_login_time) {
		this.last_login_time = last_login_time;
	}
	public Timestamp getLogin_time() {
		return login_time;
	}
	public void setLogin_time(Timestamp login_time) {
		this.login_time = login_time;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public int getClassID() {
		return classID;
	}
	public void setClassID(int classID) {
		this.classID = classID;
	}
	@Override
	public String toString() {
		return "XdlEtUser [id=" + id + ", username=" + username + ", truename=" + truename + ", password=" + password
				+ ", email=" + email + ", phone=" + phone + ", add_date=" + add_date + ", expire_date=" + expire_date
				+ ", add_by=" + add_by + ", enabled=" + enabled + ", field_id=" + field_id + ", last_login_time="
				+ last_login_time + ", login_time=" + login_time + ", province=" + province + ", company=" + company
				+ ", department=" + department + ", classID=" + classID + ", fieldName=" + fieldName + ", className="
				+ className + "]";
	}
	
	
}
