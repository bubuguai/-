package com.xdl.bean;

import java.io.Serializable;

public class XdlEtUserExamHistoryDetail implements Serializable{

	private static final long serialVersionUID = 1L;
	private int user_question_hist_d_id;
	private int user_id	;
	private int Paper_id;
	private int Question_id;
	private String User_answer;
	
	public XdlEtUserExamHistoryDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public XdlEtUserExamHistoryDetail(int user_question_hist_d_id, int user_id, int paper_id, int question_id,
			String user_answer) {
		super();
		this.user_question_hist_d_id = user_question_hist_d_id;
		this.user_id = user_id;
		Paper_id = paper_id;
		Question_id = question_id;
		User_answer = user_answer;
	}
	public int getUser_question_hist_d_id() {
		return user_question_hist_d_id;
	}
	public void setUser_question_hist_d_id(int user_question_hist_d_id) {
		this.user_question_hist_d_id = user_question_hist_d_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getPaper_id() {
		return Paper_id;
	}
	public void setPaper_id(int paper_id) {
		Paper_id = paper_id;
	}
	public int getQuestion_id() {
		return Question_id;
	}
	public void setQuestion_id(int question_id) {
		Question_id = question_id;
	}
	public String getUser_answer() {
		return User_answer;
	}
	public void setUser_answer(String user_answer) {
		User_answer = user_answer;
	}
	@Override
	public String toString() {
		return "XdlEtUserExamHistoryDetail [user_question_hist_d_id=" + user_question_hist_d_id + ", user_id=" + user_id
				+ ", Paper_id=" + Paper_id + ", Question_id=" + Question_id + ", User_answer=" + User_answer + "]";
	}
	
	
}
