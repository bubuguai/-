package com.xdl.bean;

public class XdlEtPaperQuestion {
	private int paper_2_question_id;
	private int paper_id;
	private int question_id;
	private int order_num;
	private double question_score;
	public XdlEtPaperQuestion() {
		super();
		// TODO Auto-generated constructor stub
	}
	public XdlEtPaperQuestion(int paper_2_question_id, int paper_id, int question_id, int order_num,
			double question_score) {
		super();
		this.paper_2_question_id = paper_2_question_id;
		this.paper_id = paper_id;
		this.question_id = question_id;
		this.order_num = order_num;
		this.question_score = question_score;
	}
	public int getPaper_2_question_id() {
		return paper_2_question_id;
	}
	public void setPaper_2_question_id(int paper_2_question_id) {
		this.paper_2_question_id = paper_2_question_id;
	}
	public int getPaper_id() {
		return paper_id;
	}
	public void setPaper_id(int paper_id) {
		this.paper_id = paper_id;
	}
	public int getQuestion_id() {
		return question_id;
	}
	public void setQuestion_id(int question_id) {
		this.question_id = question_id;
	}
	public int getOrder_num() {
		return order_num;
	}
	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}
	public double getQuestion_score() {
		return question_score;
	}
	public void setQuestion_score(double question_score) {
		this.question_score = question_score;
	}
	@Override
	public String toString() {
		return "EtPaperQuestion [paper_2_question_id=" + paper_2_question_id + ", paper_id=" + paper_id
				+ ", question_id=" + question_id + ", order_num=" + order_num + ", question_score=" + question_score
				+ "]";
	}

}
