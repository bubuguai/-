package com.xdl.bean;

public class XdlEtClassNum {

	private int classID;
	private String className;
	private int dr;
	public XdlEtClassNum() {
		super();
		// TODO Auto-generated constructor stub
	}
	public XdlEtClassNum(int classID, String className, int dr) {
		super();
		this.classID = classID;
		this.className = className;
		this.dr = dr;
	}
	public int getClassID() {
		return classID;
	}
	public void setClassID(int classID) {
		this.classID = classID;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public int getDr() {
		return dr;
	}
	public void setDr(int dr) {
		this.dr = dr;
	}
	@Override
	public String toString() {
		return "XdlEtClassNum [classID=" + classID + ", className=" + className + ", dr=" + dr + "]";
	}
	
	
}
