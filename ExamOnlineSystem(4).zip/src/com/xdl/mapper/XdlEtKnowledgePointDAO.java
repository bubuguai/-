package com.xdl.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xdl.bean.XdlEtAdmin;
import com.xdl.bean.XdlEtKnowledgePoint;

public interface XdlEtKnowledgePointDAO {
	/**
	    *  ��ȡ����֪ʶ��
	 * @param name
	 * @param password
	 * @return XdlEtAdmin����
	 */
	List<XdlEtKnowledgePoint> findAllKnowledgePoint();
	
	/**
	    *     ����֪ʶ��
	 * @param knowledgePoint
	 * @return
	 */
	int insertKnowledgePoint(XdlEtKnowledgePoint knowledgePoint);


}
