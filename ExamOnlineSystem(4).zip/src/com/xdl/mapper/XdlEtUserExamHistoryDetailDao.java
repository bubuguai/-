package com.xdl.mapper;

import com.xdl.bean.XdlEtUserExamHistoryDetail;

public interface XdlEtUserExamHistoryDetailDao {

	int insertEtUserExamHistoryDetail(XdlEtUserExamHistoryDetail etUserExamHistoryDetail);

}
