package com.xdl.mapper;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xdl.bean.XdlEtUserExamHistory;


public interface XdlEtUserExamHistoryDao {

	int intsertEtUserExamHistory(XdlEtUserExamHistory etUserExamHistory);
	
	//��ȡ�ύʱ��
	//XdlEtUserExamHistory getSubmitTime(@Param("submit_time") Timestamp submit_time);

	List<XdlEtUserExamHistory> findEtUserExamHistoryByUserId(@Param("user_id") int user_id);
}
