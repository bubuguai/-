package com.xdl.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.xdl.bean.XdlEtAdmin;
import com.xdl.bean.XdlEtKnowledgePoint;
import com.xdl.bean.XdlEtQuestion;
import com.xdl.bean.XdlEtQuestionOption;
import com.xdl.bean.XdlEtUser;

public interface XdlEtQuestionDAO {
	
	int insertQuestion(XdlEtQuestion question);
	
	int insertQuestionPoint(@Param("question_id")int question_id,@Param("point_id")int point_id);
	
	int insertQuestionOption(XdlEtQuestionOption questionOption);
	
	//int ��ʾ��������ɹ������� 
	int insertQuestionOptions(@Param("options")List<XdlEtQuestionOption> options);
	
	//�������������#{question_type_id}�� ��������� #{question_num} �����ȡ��Ӧ�������б� 
	List<XdlEtQuestion> getQuestionListByQuestionTypeId(@Param("question_type_id")int question_type_id,@Param("question_num")int question_num);

	int updateExposeTimes(@Param("expose_times")int expose_times,@Param("id")int id);
	
	int updateRightTimes(@Param("right_times")int right_times,@Param("id")int id);
	
	int updateWrongTimes(@Param("wrong_times")int wrong_times,@Param("id")int id);
}
