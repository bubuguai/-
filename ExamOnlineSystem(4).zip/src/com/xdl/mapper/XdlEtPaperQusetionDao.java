package com.xdl.mapper;

import org.apache.ibatis.annotations.Param;

import com.xdl.bean.XdlEtPaperQuestion;

public interface XdlEtPaperQusetionDao {

	XdlEtPaperQuestion findEtPaperQuestionByPaperIdAndQuestionId(@Param("paper_id") int paper_id,@Param("question_id") int question_id);

}
