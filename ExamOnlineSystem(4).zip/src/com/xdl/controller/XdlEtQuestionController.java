package com.xdl.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xdl.bean.XdlEtQuestion;
import com.xdl.service.XdlEtQuetionService;

@Controller
public class XdlEtQuestionController {
	@Autowired
	private XdlEtQuetionService questionService;
	
	@RequestMapping(value = "/admin/questionAdd",method=RequestMethod.POST)
	@ResponseBody
	public Map<String , String> addQuestion(@RequestBody XdlEtQuestion question){
		System.out.println(question);
		Map<String , String> message = new HashMap<String, String>();
		try {
			questionService.questionAdd(question);
			message.put("result", "success");
		} catch (Exception e) {
			message.put("result", "false");
			e.printStackTrace();	
		}
		return message;
	}
}
