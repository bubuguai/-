package com.xdl.controller;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xdl.bean.XdlEtAdmin;
import com.xdl.bean.XdlEtExamPaper;
import com.xdl.bean.XdlEtKnowledgePoint;
import com.xdl.bean.XdlEtQuestion;
import com.xdl.bean.XdlEtUser;
import com.xdl.bean.XdlEtUserExamHistory;
import com.xdl.bean.XdlEtUserExamHistoryDetail;
import com.xdl.service.XdlEtAdminService;
import com.xdl.service.XdlEtExamPaperService;
import com.xdl.service.XdlEtKnoeledgePointService;
import com.xdl.service.XdlEtPaperScoreSetvice;
import com.xdl.service.XdlEtUserExamHistoryDetailService;
import com.xdl.service.XdlEtUserExamHistoryService;
import com.xdl.service.XdlEtUserService;
import com.xdl.util.Md5Util;

@Controller
@RequestMapping("/user")
public class XdlEtUserController {
	@Autowired
	private XdlEtUserService userService;
	
	@Autowired
	private  XdlEtExamPaperService   paperService;
	
	@Autowired
	private XdlEtUserExamHistoryDetailService etUserExamHistoryDetailService;
	
	@Autowired
	private XdlEtPaperScoreSetvice etPaperScoreSetvice;
	
	@Autowired
	private XdlEtUserExamHistoryService etUserExamHistoryService;

	@RequestMapping("/toLogin.do")
	public String toLogin() {
		return "user/login";
	}
	
	@RequestMapping("/login")
	public String login(String username ,String password,HttpServletRequest request) {
		XdlEtUser etUser = userService.findUserByNameAndPad(username, password);
		if(etUser==null) {
			request.setAttribute("msg", "��¼ʧ��");
			return "user/login";
		}else {
			//List<XdlEtKnowledgePoint> knowlegePoints = knowledgePointService.getKnowledgePoint();
			request.getSession().setAttribute("etUser", etUser);
			//request.setAttribute("knowlegePoints", knowlegePoints);
			return "user/usercenter";
		}
	}
	
	/* ��ת��������� */
	@RequestMapping("/toStartExam")
	public String toStartExam(HttpServletRequest request) {
		
		List<XdlEtExamPaper> practicepaper = paperService.getAllPaperInfo();
		request.setAttribute("practicepaper", practicepaper);

		return "user/start-exam";
	}
	/**
	    *     ͨ���Ծ�id��ѯ���й������� ����ʾ��ҳ��
	 * @param id
	 * @param request
	 * @return
	 */
	@RequestMapping("/toExaming/{id}")
	public String toExaming(@PathVariable int id,HttpServletRequest request) {
		//System.out.println(id);
		XdlEtExamPaper paper = paperService.findEtPaperQuestionById(id);
		request.getSession().setAttribute("paper", paper);
		return "user/examing";
	}
	
	/**
	    *    �ύ�����Ծ� ���û��Ĵ� ���ӵ����ݿ�  ���о�
	 * @return message
	 */
	@RequestMapping(value = "/practice-finished",method = RequestMethod.POST)
	@ResponseBody
	public Map<String,String> practiceFinished(@RequestBody String[] data ,HttpSession session) {
	//	for(int i = 0;i<data.length;i++) {
	//		System.out.println(data[i]);
	//	}
		int flag = 0;
		int flag2 = 0;
		// ��ȡ��ǰ���ڴ�����û�
		XdlEtUser etUser = (XdlEtUser) session.getAttribute("etUser");
		// ��ȡ�û����ڴ���Ծ�
		XdlEtExamPaper etPaper= (XdlEtExamPaper) session.getAttribute("paper");
		//��ȡ�Ծ�����������
		List<XdlEtQuestion> questions = etPaper.getQuestions();
		/*
		      * �����о�����,
		      * �û��Ĵ𰸺ͱ�׼�𰸶Ա�,
		      * ѡ����ֱ�ӶԱ�ѡ��,���������AI�о� 
		      * �����о���Service
		 */
		//��ȡ�û��ķ���
		float[] examInfo = etPaperScoreSetvice.EtPaperScore(etPaper, questions, data);
		//��ȷ����
		int right = (int) examInfo[1];
		session.setAttribute("right", right);
		//�������
		int wrong = (int) examInfo[2];
		session.setAttribute("wrong", wrong);
		//������
		int total = questions.size();
		session.setAttribute("total", total);
		//�ύʱ��
		Timestamp timestamp = new Timestamp(new Date().getTime());
		session.setAttribute("timestamp", timestamp);
		// ���û��Ĵ𰸴��뵽���ݿ�
		for(int i = 0;i<questions.size();i++) {
			flag = etUserExamHistoryDetailService.insertEtUserExamHistoryDetail(
					new XdlEtUserExamHistoryDetail(0,etUser.getId(),
							etPaper.getId(),questions.get(i).getId(),data[i]));
		}
		// ���������Ϣ�������
			flag2 = etUserExamHistoryService.intsertEtUserExamHistory(new XdlEtUserExamHistory(0,
				etUser.getId(), etPaper.getId(), questions.toString(),
				etPaper.getCreate_time(), "��ȷ����:"+right+",�������:"+wrong, etPaper.getDuration()- new Random().nextInt(30), 
				examInfo[0], timestamp));
		
		Map<String,String> message = new HashMap<String, String>();
		if(flag !=0 && flag2 !=0) {
			message.put("result", "success");
		}else {
			message.put("result", "failed");	
		}
		return message;
	}
	
	/**
	 * ��������ת����ҳ��
	 * @return
	 */
	@RequestMapping("/finish-exam")
	public String finishExam(HttpSession session) {
		
		Timestamp timestamp = (Timestamp) session.getAttribute("timestamp");
		//XdlEtUserExamHistory examHistorySubmitTime = etUserExamHistoryService.getSubmitTime(timestamp);
		session.setAttribute("create_time", timestamp);
		return "user/exam-finished";
	}
	
	@RequestMapping("/usercenter")
	public String toUserCenter() {
		return "user/usercenter";
	}

	/**
	    * ������ʷ
	 */
	@RequestMapping("/exam-history")
	public String toExamHistory(HttpSession session) {
		XdlEtUser etUser = (XdlEtUser) session.getAttribute("etUser");
		int userId = etUser.getId();
		List<XdlEtUserExamHistory> examHistory = etUserExamHistoryService.findEtUserExamHistoryByUserId(userId);
		/*
		 * XdlEtExamPaper etPaper = (XdlEtExamPaper) session.getAttribute("paper");
		 * for(XdlEtUserExamHistory eh:examHistory) {
		 * eh.setPaperName(etPaper.getName()); }
		 */
		session.setAttribute("hisList", examHistory);
		return "user/exam-history";
	}
	
	@RequestMapping("/analysis")
	public String toAnalysis() {
		return "user/analysis";
	}
	
	@RequestMapping("/toHome")
	public String toHome() {
		return "user/home";
	}
	
	
	
	/**
	 * ����Ԥ��
	 */
	
	public String yulan(@PathVariable("id")int id,HttpSession session) {
		etUserExamHistoryService.findEtUserExamHistoryByUserId(id);
		
		
		return null;
		
	}
//	@RequestMapping("user/yulan/{id}")
//	public String yuLan(@PathVariable int id,HttpSession session) {
//		EtUserExamHistory etUserExamHistory = etUserExamHistoryService.findEtUserExamHistoryById(id);
//		EtPaper paper = etPaperService.findEtPaper(etUserExamHistory.getExam_paper_id());
//		String answer_sheet = etUserExamHistory.getAnswer_sheet();
//		String[] split = answer_sheet.split(",");
//		int right = Integer.parseInt(split[0]);
//		int wrong = Integer.parseInt(split[1]);
//		int total = right + wrong;
//		session.setAttribute("paper", paper);
//		session.setAttribute("create_time", etUserExamHistory.getSubmit_time());
//		session.setAttribute("point_get", etUserExamHistory.getPoint_get());
//		session.setAttribute("total", total);
//		session.setAttribute("right", right);
//		session.setAttribute("wrong", wrong);
//		return "user/exam-finished";
//	}
}
