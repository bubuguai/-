package com.xdl.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xdl.bean.XdlEtAdmin;
import com.xdl.bean.XdlEtClassNum;
import com.xdl.bean.XdlEtKnowledgePoint;
import com.xdl.bean.XdlEtUser;
import com.xdl.service.XdlEtAdminService;
import com.xdl.service.XdlEtKnoeledgePointService;
import com.xdl.util.Md5Util;

@Controller
@RequestMapping("/admin")
public class XdlEtAdminController {
	@Autowired
	private XdlEtAdminService adminService;
	@Autowired
	private XdlEtKnoeledgePointService  knowledgePointService;
	
	@RequestMapping("/toLogin.do")
	public String toLogin() {
		return "admin/login";
	}
	
	@RequestMapping("/login.do")
	public String login(String name ,String password,HttpServletRequest request) {
		XdlEtAdmin etAdmin = adminService.toLogin(name,Md5Util.md5StrAndSalt(password, name) );
		if(etAdmin==null) {
			request.setAttribute("msg", "��¼ʧ��");
			return "admin/login";
		}else {
			List<XdlEtKnowledgePoint> knowlegePoints = knowledgePointService.getKnowledgePoint();
			request.getSession().setAttribute("etAdmin", etAdmin);
			request.setAttribute("knowlegePoints", knowlegePoints);
			return "admin/question-add";
		}
	}
	@RequestMapping("/toAddUser")
	public String userAdd(HttpServletRequest request) {
		//�Ѱ༶�������ӵ�����
		List<XdlEtClassNum> classList = adminService.getAllClass();
		request.setAttribute("classList", classList);
		return "admin/add-user";
	}
	
	/**
	 * �����Ա
	 * @param 
	 * @return
	 */
	@RequestMapping(value = "add-user" ,method = RequestMethod.POST)
	@ResponseBody
	public Map<String,String> adddUser(@RequestBody XdlEtUser data) {
		//System.out.println(data);
		
		Map<String,String> message = new HashMap<String, String>();
		try {
			adminService.insertUser(data);
			message.put("result", "success");
		} catch (Exception e) {
			e.printStackTrace();
			message.put("result","failed");
		}
		return message;
		
	}
	
	@RequestMapping("/toUserList")
	public String showUserList(HttpServletRequest request) {
		//���û���Ա���ӵ�����
		List<XdlEtUser> userList = adminService.getAllUser();
		request.setAttribute("userList", userList);
		return "admin/user-list";
	}
	/**
	 * �޸Ļ�Ա״̬Ϊ ����/����
	 */
	@RequestMapping(value = "enable-user/{id}" ,method = RequestMethod.GET)
	@ResponseBody
	public Map<String,String> updateEnabledOn(@PathVariable int id) {
		//System.out.println(id);
		
		Map<String,String> message = new HashMap<String, String>();
		try {
			adminService.updateUserEnabledOn(id);
			message.put("result", "success");
		} catch (Exception e) {
			e.printStackTrace();
			message.put("result","failed");
		}
		return message;
		
	}
	
	/**
	 * �޸Ļ�Ա״̬Ϊ ����/δ����
	 */
	@RequestMapping(value = "disable-user/{id}" ,method = RequestMethod.GET)
	@ResponseBody
	public Map<String,String> updateEnabledOff(@PathVariable int id) {
		//System.out.println(id);
		
		Map<String,String> message = new HashMap<String, String>();
		try {
			adminService.updateUserEnabledOff(id);
			message.put("result", "success");
		} catch (Exception e) {
			e.printStackTrace();
			message.put("result","failed");
		}
		return message;
		
	}
	
	/**
	    * ֪ʶ���б�
	 */
	@RequestMapping("/toPointList")
	public String showKnowLeageList(HttpServletRequest request) {
		//���û���Ա���ӵ�����
		//List<XdlEtUser> userList = adminService.getAllUser();
		//request.setAttribute("userList", userList);
		List<XdlEtKnowledgePoint> knowledgePoint = knowledgePointService.getKnowledgePoint();
		request.setAttribute("knowledgepoints", knowledgePoint);
		return "admin/point-list";
	}
	
	/**
	    * ����֪ʶ��ҳ��
	 */
	@RequestMapping("/toAddKnowLeage")
	public String addKnowLeage(HttpServletRequest request) {
		return "admin/add-point";
	}
	/**
	    * ����֪ʶ��
	 * @param 
	 * @return
	 */
	@RequestMapping(value = "addPoint" ,method = RequestMethod.POST)
	@ResponseBody
	public Map<String,String> addKnowLeagePoint(@RequestBody XdlEtKnowledgePoint data) {
		System.out.println(data);
		
		Map<String,String> message = new HashMap<String, String>();
		try {
			knowledgePointService.insertKnowledgePoint(data);
			message.put("result", "success");
		} catch (Exception e) {
			e.printStackTrace();
			message.put("result","failed");
		}
		return message;
		
	}
	
}
