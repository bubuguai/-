package com.xdl.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xdl.bean.XdlEtExamPaper;
import com.xdl.bean.XdlEtKnowledgePoint;
import com.xdl.bean.XdlEtQuestion;
import com.xdl.service.XdlEtExamPaperService;
import com.xdl.service.XdlEtKnoeledgePointService;
import com.xdl.service.XdlEtQuetionService;
@Controller
public class XdlEtExamPaperController {
	@Autowired
	private XdlEtKnoeledgePointService  knowledgePointService;
	
	@Autowired
	private XdlEtQuetionService quetionService;
	
	@Autowired
	private  XdlEtExamPaperService   paperService;
	
	@RequestMapping("admin/toExamPaper")
	public String toExamPaper(HttpServletRequest request) {
		List<XdlEtKnowledgePoint> knowlegePoints = knowledgePointService.getKnowledgePoint();
		request.setAttribute("knowlegePoints", knowlegePoints);
		return "admin/exampaper-add";
	}
	
	@RequestMapping(value = "admin/examPaperAdd" ,method = RequestMethod.POST)
	@ResponseBody
	public Map<String,String> addExamPaper(@RequestBody XdlEtExamPaper question) {
		//System.out.println(question);
		// ��ȡ�Ծ���Ӧ�������б� 
		List<XdlEtQuestion> questions = 
				quetionService.questionList(question.getQuestionTypeNum());
		question.setQuestions(questions);
		// ����service ���Ӧ�ķ���  ���Ծ���Ϣ �������ݿ� 
		Map<String,String> message = new HashMap<String, String>();
		try {
			paperService.paperAdd(question);
			message.put("result","success");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			message.put("result","failed");
		}
		return message;
	}
	/**
	    *     �Ծ��б�
	 * @param request
	 * @return
	 */
	@RequestMapping("admin/exampaperList")
	public String toExamPaperList(HttpServletRequest request) {
		List<XdlEtExamPaper> allPaperInfo = paperService.getAllPaperInfo();
		request.setAttribute("papers", allPaperInfo);
		return "admin/exampaper-list";
	}
	/**
	    * �޸�״̬Ϊ����
	 * @param paper_id
	 * @return
	 */
	@RequestMapping(value = "admin/paper-publish" ,method = RequestMethod.POST)
	@ResponseBody
	public Map<String,String> updatePaperStatusOnline(@RequestBody String paper_id) {
		//System.out.println(paper_id);
		//int id = Integer.parseInt(paper_id);
		//System.out.println(id);
		Map<String,String> message = new HashMap<String, String>();
		try {
			paperService.updatePaperStateOnLine(paper_id);
			message.put("result", "success");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			message.put("result","failed");
		}
		return message;
		
	}
	
	/**
	    * �޸�״̬Ϊ����
	 * @param paper_id
	 * @return
	 */
	@RequestMapping(value = "admin/paper-offline" ,method = RequestMethod.POST)
	@ResponseBody
	public Map<String,String> updatePaperStatusOutLine(@RequestBody String paper_id) {
		System.out.println(paper_id);
		//int id = Integer.parseInt(paper_id);
		//System.out.println(id);
		Map<String,String> message = new HashMap<String, String>();
		try {
			paperService.updatePaperStateOutLine(paper_id);
			message.put("result", "success");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			message.put("result","failed");
		}
		return message;
		
	}
	
	/**
	    * ɾ���Ծ�
	 * @param paper_id
	 * @return
	 */
	@RequestMapping(value = "admin/paper-delete" ,method = RequestMethod.POST)
	@ResponseBody
	public Map<String,String> deletePaperBypaperId(@RequestBody String paper_id) {
		System.out.println(paper_id);
		//int id = Integer.parseInt(paper_id);
		//System.out.println(id);
		Map<String,String> message = new HashMap<String, String>();
		try {
			paperService.deletePaper(paper_id);
			message.put("result", "success");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			message.put("result","failed");
		}
		return message;
		
	}
	
	/**
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping("/admin/exampaper-edit")
	public String toExampaperEdit(HttpServletRequest request) {
		//List<XdlEtExamPaper> allPaperInfo = paperService.getAllPaperInfo();
		//request.setAttribute("papers", allPaperInfo);
		return "admin/exampaper-edit";
	}
}
