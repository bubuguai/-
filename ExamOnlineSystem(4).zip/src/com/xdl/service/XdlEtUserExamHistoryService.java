package com.xdl.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xdl.bean.XdlEtUserExamHistory;
import com.xdl.mapper.XdlEtUserExamHistoryDao;

@Service
public class XdlEtUserExamHistoryService {
	@Autowired
	private XdlEtUserExamHistoryDao etUserExamHistoryDao;
	
	public int intsertEtUserExamHistory(XdlEtUserExamHistory etUserExamHistory) {
		return etUserExamHistoryDao.intsertEtUserExamHistory(etUserExamHistory);
	}
	
	//��ȡ�ύʱ��
	/*
	 * public XdlEtUserExamHistory getSubmitTime(Timestamp submit_time) { return
	 * etUserExamHistoryDao.getSubmitTime(submit_time); }
	 */
	
	public List<XdlEtUserExamHistory> findEtUserExamHistoryByUserId(int user_id) {
		return etUserExamHistoryDao.findEtUserExamHistoryByUserId(user_id);
		
	}

}
