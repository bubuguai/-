package com.xdl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xdl.bean.XdlEtAdmin;
import com.xdl.bean.XdlEtKnowledgePoint;
import com.xdl.mapper.XdlEtAdminDAO;
import com.xdl.mapper.XdlEtKnowledgePointDAO;

@Service("knowledgePointDAO")
public class XdlEtKnoeledgePointService {
	
	@Autowired
	private XdlEtKnowledgePointDAO knowledgePointDAO;
	
	/**
	 * ��ѯ����֪ʶ��
	 * @return
	 */
	public List<XdlEtKnowledgePoint> getKnowledgePoint(){
		return knowledgePointDAO.findAllKnowledgePoint();
	}
	
	/**
	 * ����֪ʶ��
	 * @param knowledgePoint
	 * @return
	 */
	public int insertKnowledgePoint(XdlEtKnowledgePoint knowledgePoint) {
		return knowledgePointDAO.insertKnowledgePoint(knowledgePoint);
	}
}

