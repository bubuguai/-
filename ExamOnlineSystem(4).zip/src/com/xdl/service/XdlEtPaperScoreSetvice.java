package com.xdl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xdl.bean.XdlEtExamPaper;
import com.xdl.bean.XdlEtQuestion;
import com.xdl.mapper.XdlEtQuestionDAO;
import com.xdl.util.BaiDuAutoPapger;

@Service
public class XdlEtPaperScoreSetvice {
	@Autowired
	private XdlEtPaperQuestioService etPaperQuestioService;
	@Autowired
	private XdlEtQuestionDAO etQuestionDao;
	public float[] EtPaperScore(XdlEtExamPaper etPaper,List<XdlEtQuestion> questions,String[] data) {
		//设置总成绩变量
		float num = 0;
		float[] examInfo = new float[3];
		float trueNum = 0;
		float wrongNum = 0;
			//获取问题的类型
			for(int i = 0; i < questions.size(); i++) {
				int times = questions.get(i).getExpose_times();
				etQuestionDao.updateExposeTimes(times++,questions.get(i).getId());
				if(questions.get(i).getQuestion_type_id() == 1) {
					//选择题
					boolean xz = questions.get(i).getAnswer().equals(data[i]);
						//获取当前试卷当前题的分数
					double score = etPaperQuestioService.findEtPaperQuestionByPaperIdAndQuestionId(etPaper.getId(), questions.get(i).getId()).getQuestion_score();
						if(xz) {
							trueNum++;
							num = (float) (num + score);
							int right_times = questions.get(i).getRight_times();
							etQuestionDao.updateRightTimes(right_times+1, questions.get(i).getId());
						}else {
							wrongNum++;
							int wrong_times = questions.get(i).getWrong_times();
							etQuestionDao.updateWrongTimes(wrong_times++, questions.get(i).getId());
						}
					}else {
						//简答题
						double score = BaiDuAutoPapger.AutoPaper(questions.get(i).getAnswer(), data[i]);
						if(score > 60) {
							trueNum++;
							int right_times = questions.get(i).getRight_times();
							etQuestionDao.updateRightTimes(right_times+1, questions.get(i).getId());
						}else {
							wrongNum++;
							int wrong_times = questions.get(i).getWrong_times();
							etQuestionDao.updateWrongTimes(wrong_times++, questions.get(i).getId());
						}
						num = (float) (num + score);
					}
				}
			examInfo[0] = num;
			examInfo[1] = trueNum;
			examInfo[2] = wrongNum;
		return examInfo;
	}
}
