package com.xdl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xdl.bean.XdlEtAdmin;
import com.xdl.bean.XdlEtUser;
import com.xdl.bean.XdlEtUserExamHistoryDetail;
import com.xdl.mapper.XdlEtAdminDAO;
import com.xdl.mapper.XdlEtUserDAO;

@Service("userService")
public class XdlEtUserService {
	@Autowired
	private XdlEtUserDAO userDao;
	
	public XdlEtUser findUserByNameAndPad(String username,String password) {
		return userDao.findUserByNameAndPad(username, password);
	}
	
	/**
	 * ����Ա������Ϣ�����û����Լ�¼���������
	 * @param answerDetail
	 * @return
	 */
	/*
	 * public int insertUserAnswer(XdlEtUserExamHistoryDetail answerDetail) { return
	 * userDao.insertUserAnswer(answerDetail); }
	 */
}

