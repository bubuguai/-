package com.xdl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xdl.bean.XdlEtAdmin;
import com.xdl.bean.XdlEtClassNum;
import com.xdl.bean.XdlEtUser;
import com.xdl.mapper.XdlEtAdminDAO;

@Service("adminService")
public class XdlEtAdminService {
	@Autowired
	private XdlEtAdminDAO adminDao;
	/**
	   * ����Ա��½
	 * @param name
	 * @param password
	 * @return
	 */
	public XdlEtAdmin toLogin(String name,String password) {
		return adminDao.findAdminByNameAndPassword(name, password);
	}
	
	/**
	    * ����Ա�б�
	 * @return List<XdlEtAdmin>
	 */
	public List<XdlEtAdmin> findAllAdmin(){
		return adminDao.findAllAdmin();
	}
	
	/**
	   * ���ӹ���Ա
	 * @param etAdmin
	 * @return
	 */
	public int insertAdmin(XdlEtAdmin etAdmin) {
		return adminDao.insertAdmin(etAdmin);
	}
	
	/**
	   * ������Ա
	 * @param user
	 * @return
	 */
	public int insertUser(XdlEtUser user) {
		return adminDao.insertUser(user);
	}
	/**
	 * ��ѯ���а༶
	 */
	public List<XdlEtClassNum> getAllClass(){
		return adminDao.getAllClassName();
	}
	
	/**
	 * ��ѯ���л�Ա
	 */
	public List<XdlEtUser> getAllUser(){
		return adminDao.getAllUser();
	}
	
	/**
	 * �޸Ļ�Ա״̬Ϊ ����/����
	 */
	public void updateUserEnabledOn(int id) {
		adminDao.updateUserEnabledOn(id);
	}
	
	/**
	 * �޸Ļ�Ա״̬Ϊ ����/ע��
	 */
	public void updateUserEnabledOff(int id){
		adminDao.updateUserEnabledOff(id);
	}
}

