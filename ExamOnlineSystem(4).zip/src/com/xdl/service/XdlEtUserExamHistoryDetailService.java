package com.xdl.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xdl.bean.XdlEtUserExamHistoryDetail;
import com.xdl.mapper.XdlEtUserExamHistoryDetailDao;
import com.xdl.util.Md5Util;

@Service
public class XdlEtUserExamHistoryDetailService {
	@Autowired
	private XdlEtUserExamHistoryDetailDao etUserExamHistoryDetailDao;
	
	public int insertEtUserExamHistoryDetail(XdlEtUserExamHistoryDetail etUserExamHistoryDetail) {
		return etUserExamHistoryDetailDao.insertEtUserExamHistoryDetail(etUserExamHistoryDetail);
	}
}
