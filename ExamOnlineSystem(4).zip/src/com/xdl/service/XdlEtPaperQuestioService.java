package com.xdl.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xdl.bean.XdlEtPaperQuestion;
import com.xdl.mapper.XdlEtPaperQusetionDao;

@Service
public class XdlEtPaperQuestioService {
	
	@Autowired
	private XdlEtPaperQusetionDao etPaperQusetionDao;
	
	public XdlEtPaperQuestion findEtPaperQuestionByPaperIdAndQuestionId(int paper_id,int question_id) {
		return etPaperQusetionDao.findEtPaperQuestionByPaperIdAndQuestionId(paper_id, question_id);
	}
}
