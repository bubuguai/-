package com.xdl.util;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.baidu.aip.nlp.AipNlp;

public class BaiDuAutoPapger {
	private static final String APP_ID = "15212762";
	private static final String API_KEY = "IK58kWh54CyNwHxoeDYGdolU";
	private static final String SECRET_KEY = "obKcA2M2IB7DYdxUhn18md8DKIqiAl6V";
	public static double AutoPaper(String answer,String userAnswer) {
	    AipNlp client = new AipNlp(APP_ID, API_KEY, SECRET_KEY);
		 // 传入可选参数调用接口
	    HashMap<String, Object> options = new HashMap<String, Object>();
	    options.put("model", "CNN");
	    // 短文本相似度
	    JSONObject res = client.simnet(answer, userAnswer, options);
	   // return (double) res.get("score")*100;
	    try {
			 double score = Double.parseDouble(res.getString("score").toString());
			 return score;
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0.0;
		}
	}
}
