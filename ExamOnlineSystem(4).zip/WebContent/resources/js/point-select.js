$(function(){
	var point_div = $("#point-select-result");
	var btn = $("#btn-point-add");
	var innerHtml = point_div.html();
	btn.click(function(){
		
	});
});