package cn.xdl.sms.aliyun;

import java.util.HashMap;

import com.aliyuncs.CommonRequest;
import com.aliyuncs.CommonResponse;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.exceptions.ServerException;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.google.gson.Gson;

public class SmsUtil {

	public static boolean sendSms2(String phone,String code,String couPhone) {
		DefaultProfile profile = DefaultProfile.getProfile("default", "LTAIz8V5Pf2tQBg7", "w2PuVJ02e4Rz1Vzan8OlV4Qxg4aYfV");
        IAcsClient client = new DefaultAcsClient(profile);

        CommonRequest request = new CommonRequest();
        request.setMethod(MethodType.POST);
        request.setDomain("dysmsapi.aliyuncs.com");
        request.setVersion("2017-05-25");
        request.setAction("SendSms");
        request.putQueryParameter("RegionId", "default");
        request.putQueryParameter("PhoneNumbers", phone);
        request.putQueryParameter("SignName", "��������վ");
        request.putQueryParameter("TemplateCode", "SMS_173340264");
        //	�ַ����Ķ�����ʽ	String s = "��\""+"��"+"��"; 		"{\"code\":\""+code+"\"}"
        //	�ַ����ı�����ʽ	��"����		{"code":"ֵ"}
        request.putQueryParameter("TemplateParam", "{\"code\":\""+code+"\",\"couphone\":\""+couPhone+"\"}");
        try {
            CommonResponse response = client.getCommonResponse(request);
            //{"Message":"OK","RequestId":"40554642-83C5-4996-A1F1-BAC21C3EB14F","BizId":"429315566955617973^0","Code":"OK"}
            String json = response.getData();
            Gson g = new Gson();
            HashMap<String , Object> data = g.fromJson(json, HashMap.class);
            if("OK".equals(data.get("Message"))) {
            	return true;
            }
        } catch (ServerException e) {
            e.printStackTrace();
        } catch (ClientException e) {
            e.printStackTrace();
        }
        return false;
	}
}
