package cn.xdl.util;

import java.text.SimpleDateFormat;

public class DateFormatUtil {

	/**
	 * yyyy-MM-dd HH:mm:ss
	 */
	public static SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
}
