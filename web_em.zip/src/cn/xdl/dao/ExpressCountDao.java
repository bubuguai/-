package cn.xdl.dao;

import java.util.List;

import cn.xdl.bean.Express;

public interface ExpressCountDao {
	/**
	 * ��ѯδȡ���Ŀ��
	 * @return
	 */
	List<Express> findAllWaitExpress();
}
