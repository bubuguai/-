package cn.xdl.dao.user;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import cn.xdl.bean.user.User;
import cn.xdl.service.user.UserService;

public class UserDaoTest {
	/**
	 * ���Բ����û��Ƿ�ɹ�
	 * @throws Exception
	 */
	@Test
	public void insert() throws Exception {
		UserService.insert(new User("�����", "15698991361", "111111"));
	}
	
	
	/**
	 * �����޸��û���Ϣ�Ƿ�ɹ�
	 * @throws Exception
	 */
	@Test
	public void update() throws Exception {
		UserService.updateByIdOrUserPhone("13842055669", -1, new User("�ƻ�", "13998997677", "123456"));
	}
	
	
	/**
	 * ����ɾ���û���Ϣ�Ƿ�ɹ�
	 * @throws Exception
	 */
	@Test
	public void delete() throws Exception {
		UserService.deleteByIdOrUserPhone("13998997677", -1);
	}
	
	
	/**
	 * ���Բ���ȫ���û��Ƿ�ɹ�չʾ
	 * @throws Exception
	 */
	@Test
	public void find() throws Exception {
		List<User> us = UserService.findAll();
		System.out.println(us);
	}
	
	
	
	@Test
	public void find2() throws Exception {
		User uu = UserService.findByUserPhone("15698991361");
		System.out.println(uu);
	}
}





























