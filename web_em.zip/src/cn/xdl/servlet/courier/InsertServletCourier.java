package cn.xdl.servlet.courier;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Message;
import cn.xdl.bean.courier.Courier;
import cn.xdl.service.courier.CourierService;

/**
 * Servlet implementation class InsertServletCourier
 */
@WebServlet("/courier/insert.do")
public class InsertServletCourier extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/json;charset=utf-8");
		//"couName="+couName+"&couPhone="+couPhone+"&couPassword="+couPassword;
		//1.���ղ���
		String couName = request.getParameter("couName");
		String couPhone = request.getParameter("couPhone");
		String couPassword = request.getParameter("couPassword");
		//2.����service
		boolean flag = CourierService.insert(new Courier(couName, couPhone, couPassword));
		Message msg = null;
		if(flag) {
			msg = new Message(7,"���Ա���ӳɹ�");
		}else {
			msg = new Message(-1,"���Ա����ʧ��");
		}
		//3.��Ӧ
		//{"status":7,"msg":"����ɹ�����ʧ��"}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
