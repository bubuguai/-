package cn.xdl.servlet.courier;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Message;
import cn.xdl.service.courier.CourierService;

/**
 * Servlet implementation class DeleteServletCourier
 */
@WebServlet("/courier/delete.do")
public class DeleteServletCourier extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//���ñ������
		response.setContentType("text/json;charset=utf-8");
		//���ջ�ȡidֵ
		String idstr = request.getParameter("id");
		int id = -1;
		try {
			//��idת����Integer����
			id = Integer.parseInt(idstr);
		} catch (NumberFormatException e) {
		}
		//�жϰ���id��ɾ���Ľ��
		boolean flag = CourierService.deleteByIdOrCouPhone(null, id);
		Message msg = null;
		if(flag) {
			//���flagΪ��,�򷵻���Ϣ1,��ɾ���ɹ�
			msg = new Message(1,"ɾ���ɹ�");
		}else {
			//���򷵻�-1,ɾ��ʧ��
			msg = new Message(-1,"ɾ��ʧ��");
		}
		//{"status":1,"msg":"ɾ���ɹ�����ʧ��"}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
