package cn.xdl.servlet.courier;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Express;
import cn.xdl.bean.Message;
import cn.xdl.bean.courier.Courier;
import cn.xdl.service.ExpressService;
import cn.xdl.service.courier.CourierService;

/**
 * Servlet implementation class UpdateServletCourier
 */
@WebServlet("/courier/update.do")
public class UpdateServletCourier extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/json;charset=utf-8");
		//"oldCouPhone="+oldCouPhone+"&couName="+couName+
		//"&newCouPhone="+newCouPhone+"&couPassword="+couPassword;
		//1.	�������󴫵ݵĲ���
		String oldCouPhone = request.getParameter("oldCouPhone");
		String couName = request.getParameter("couName");
		String newCouPhone = request.getParameter("newCouPhone");
		String couPassword = request.getParameter("couPassword");
		//2.	����service
		boolean flag = CourierService.updateByIdOrCouPhone(oldCouPhone, -1, new Courier(couName, newCouPhone, couPassword));
		//3.	����serviceִ�еĽ��,��Ӧmessage
		Message msg = null;
		if(flag) {
			//�޸ĳɹ���	
			msg = new Message(1, "�޸ĳɹ�");
		}else {
			//�޸�ʧ����
			msg = new Message(-1, "�޸�ʧ��");
		}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
