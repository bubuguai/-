package cn.xdl.servlet.login;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.xdl.bean.Message;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//���ñ��뼯
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		//���ղ���username��password
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		//�浽session��
		HttpSession session = request.getSession();
		session.setAttribute("username", username);
		Message msg = null;
		if("mengshiqi".equals(username)&&"110923".equals(password)) {
			//�˺ź�����һ��,�ſ��Ե�½
			session.setAttribute("userflag", 1);
			msg = new Message(1,"��¼�ɹ�");
			//response.getWriter().append(msg.toJSON());
		}else {
			//��½ʧ��
			session.setAttribute("userflag", -1);
			msg = new Message(2,"��½ʧ��");
		}
		//30hang yu 36 hang  zhongfu
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
