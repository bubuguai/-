package cn.xdl.servlet.express;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Express;
import cn.xdl.bean.Message;
import cn.xdl.service.ExpressService;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/express/update.do")
public class UpdateServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/json;charset=utf-8");
		//"oldENumber="+oldENumber+"&newENumber="+newENumber+"&company="
		//+company+"&username="+username+"&userphone="+userphone;
		//1.	�������󴫵ݵĲ���
		String oldENumber = request.getParameter("oldENumber");
		String newENumber = request.getParameter("newENumber");
		String company = request.getParameter("company");
		String username = request.getParameter("username");
		String userphone = request.getParameter("userphone");
		//2.	����service
		
		boolean flag = ExpressService.updateByIdOrENumber(oldENumber, -1, new Express(company, newENumber, username, userphone, "18516955565"));
		//3.	����serviceִ�еĽ��,��Ӧmessage
		Message msg = null;
		if(flag) {
			//�޸ĳɹ���	
			msg = new Message(1, "�޸ĳɹ�");
		}else {
			//�޸�ʧ����
			msg = new Message(-1, "�޸�ʧ��");
		}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
