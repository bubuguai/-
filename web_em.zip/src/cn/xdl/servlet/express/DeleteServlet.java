package cn.xdl.servlet.express;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Message;
import cn.xdl.service.ExpressService;

/**
 * Servlet implementation class DeleteServlet
 */
@WebServlet("/express/delete.do")
public class DeleteServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//���ñ��뼯
		response.setContentType("text/json;charset=utf-8");
		//���ղ���id
		String idStr = request.getParameter("id");
		int id = -1;
		try {
			//��idת����Integer����
			id = Integer.parseInt(idStr);
		} catch (NumberFormatException e) {
		}
		boolean flag = ExpressService.deleteByIdOrENumber(null, id);
		Message msg = null;
		if(flag) {
			msg = new Message(1, "ɾ���ɹ�");
		}else {
			msg = new Message(-1, "ɾ��ʧ��");
		}
		//{"status":1,"msg":"ɾ���ɹ�"}
		response.getWriter().append(msg.toJSON());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
