package cn.xdl.servlet.express;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Express;
import cn.xdl.bean.Message;
import cn.xdl.service.ExpressService;

/**
 * Servlet implementation class FindServlet
 */
@WebServlet("/express/find.do")
public class FindServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/json;charset=utf-8");
		//1.	��ȡ����
		String eNumber = request.getParameter("eNumber");
		//2.	����service����
		Express e = ExpressService.findByENumber(eNumber);
		//3.	����ѯ�Ľ�� ��Ӧ
		Message msg = null;
		if(e == null) {
			//���Ų�ѯʧ��
			msg = new Message(-1, "��ѯʧ��, ���鵥���Ƿ���ȷ");
		}else {
			//��ѯ�ɹ�
			msg = new Message(1, "��ѯ�ɹ�",e);
			//{"status":1,"msg":"��ѯ�ɹ�","data":{"id":xx,"eNumber":xxx...}}
		}
		response.getWriter().append(msg.toJSON());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
