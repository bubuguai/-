package cn.xdl.servlet.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Express;
import cn.xdl.bean.Message;
import cn.xdl.bean.user.User;
import cn.xdl.service.ExpressService;
import cn.xdl.service.user.UserService;

/**
 * Servlet implementation class UpdateServletUser
 */
@WebServlet("/user/update.do")
public class UpdateServletUser extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/json;charset=utf-8");
		//"oldUserPhone="+oldUserPhone+"&userName="+userName+"&newUserPhone="+newUserPhone+"&userPassword="+userPassword;
		//1.	�������󴫵ݵĲ���
		String oldUserPhone = request.getParameter("oldUserPhone");
		String userName = request.getParameter("userName");
		String newUserPhone = request.getParameter("newUserPhone");
		String userPassword = request.getParameter("userPassword");
		//2.	����service
		boolean flag = UserService.updateByIdOrUserPhone(oldUserPhone, -1, new User(userName, newUserPhone, userPassword));
		//3.	����serviceִ�еĽ��,��Ӧmessage
		Message msg = null;
		if(flag) {
			//�޸ĳɹ���	
			msg = new Message(1, "�޸ĳɹ�");
		}else {
			//�޸�ʧ����
			msg = new Message(-1, "�޸�ʧ��");
		}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
