package cn.xdl.servlet.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Message;
import cn.xdl.bean.courier.Courier;
import cn.xdl.bean.user.User;
import cn.xdl.service.courier.CourierService;
import cn.xdl.service.user.UserService;

/**
 * Servlet implementation class InsertServletUser
 */
@WebServlet("/user/insert.do")
public class InsertServletUser extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/json;charset=utf-8");
		//"userName="+userName+"&userPhone="+userPhone+"&userPassword="+userPassword;
		//1.���ղ���
		String userName = request.getParameter("userName");
		String userPhone = request.getParameter("userPhone");
		String userPassword = request.getParameter("userPassword");
		//2.����service
		boolean flag = UserService.insert(new User(userName, userPhone, userPassword));
		Message msg = null;
		if(flag) {
			msg = new Message(7,"�û����ӳɹ�");
		}else {
			msg = new Message(-1,"�û�����ʧ��");
		}
		//3.��Ӧ
		//{"status":7,"msg":"����ɹ�����ʧ��"}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
