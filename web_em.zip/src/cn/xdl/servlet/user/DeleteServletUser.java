package cn.xdl.servlet.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.xdl.bean.Message;
import cn.xdl.service.courier.CourierService;
import cn.xdl.service.user.UserService;

/**
 * Servlet implementation class DeleteServletUser
 */
@WebServlet("/user/delete.do")
public class DeleteServletUser extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//���ñ��뼯
		response.setContentType("text/json;charset=utf-8");
		//���ղ���id
		String idstr = request.getParameter("id");
		int id = -1;
		try {
			//��idת����Integer����
			id = Integer.parseInt(idstr);
		} catch (NumberFormatException e) {
		}
		//�жϰ���id��ɾ��
		boolean flag = UserService.deleteByIdOrUserPhone(null, id);
		Message msg = null;
		if(flag) {
			msg = new Message(1,"ɾ���ɹ�");
		}else {
			msg = new Message(-1,"ɾ��ʧ��");
		}
		//{"status":1,"msg":"ɾ���ɹ�����ʧ��"}
		response.getWriter().append(msg.toJSON());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
