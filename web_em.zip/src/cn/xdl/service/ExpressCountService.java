package cn.xdl.service;

import java.util.List;

import cn.xdl.bean.Express;
import cn.xdl.dao.ExpressCountDao;
import cn.xdl.dao.imp.ExpressCountDaoImp;

public class ExpressCountService {
	private static ExpressCountDao ecd = new ExpressCountDaoImp();

	/**
	 * ��ѯδȡ�����, �б�չʾ
	 * 
	 * @return  list����
	 */
	
	public static List<Express> findAllWaitExpress(){
		return ecd.findAllWaitExpress();
	}
}
